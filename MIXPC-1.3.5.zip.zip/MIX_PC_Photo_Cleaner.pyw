
from __future__ import annotations

import base64
import csv
import io
import json
import os
import shutil
import zipfile
import hashlib
import subprocess
import tempfile
import ctypes
from ctypes import wintypes
import sys
import threading
import time
import traceback
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from tkinter import (
    Tk, Toplevel, StringVar, BooleanVar, DoubleVar, IntVar, Listbox,
    END, filedialog, messagebox, Menu, LEFT, RIGHT, BOTH, X, Y, VERTICAL)
from tkinter import ttk

import requests
import certifi
import re
from PIL import Image, ImageChops, ImageTk, ImageDraw, ImageFilter

# =========================================================
# TLS / CERTIFI HOTFIX v1.3.4
# =========================================================
def configure_tls_certificates():
    """Use only a CA bundle path that actually exists."""
    candidates = []

    try:
        candidates.append(Path(certifi.where()))
    except Exception:
        pass

    if getattr(sys, "frozen", False):
        try:
            base = Path(getattr(sys, "_MEIPASS", ""))
            if str(base):
                candidates.extend([
                    base / "certifi" / "cacert.pem",
                    base / "_internal" / "certifi" / "cacert.pem",
                ])
        except Exception:
            pass

        try:
            exe_dir = Path(sys.executable).resolve().parent
            candidates.extend([
                exe_dir / "_internal" / "certifi" / "cacert.pem",
                exe_dir / "certifi" / "cacert.pem",
            ])
        except Exception:
            pass

    cert_path = next((p for p in candidates if p and p.exists()), None)

    if cert_path:
        os.environ["SSL_CERT_FILE"] = str(cert_path)
        os.environ["REQUESTS_CA_BUNDLE"] = str(cert_path)
        return str(cert_path)

    os.environ.pop("SSL_CERT_FILE", None)
    os.environ.pop("REQUESTS_CA_BUNDLE", None)
    return None


TLS_CA_PATH = configure_tls_certificates()

API = "https://api.moysklad.ru/api/remap/1.2"


# =========================================================
# IMAGE PROCESSING
# =========================================================

def _mixpc_logo_color_mask(rgb: Image.Image):
    """
    Маска фирменных сине-бирюзовых цветов старого логотипа MIX PC.
    Возвращает список координат цветных пикселей в переданном фрагменте.
    """
    pixels = rgb.load()
    w, h = rgb.size
    coords = []

    for y in range(h):
        for x in range(w):
            r, g, b = pixels[x, y]

            # Синий / голубой / бирюзовый.
            # Специально не цепляем красный, оранжевый, серый и чёрный товар.
            blue = (
                b >= 135
                and b - r >= 35
                and b >= g - 25
                and max(r, g, b) - min(r, g, b) >= 55
            )
            cyan = (
                g >= 125
                and b >= 110
                and g - r >= 45
                and b - r >= 25
                and max(r, g, b) - min(r, g, b) >= 55
            )

            if blue or cyan:
                coords.append((x, y))

    return coords


def detect_old_logo(im: Image.Image, box_ratio: float = 0.20):
    """
    STEP 4.1 — геометрический детектор старого логотипа MIX PC.

    Почему он надёжнее старого:
    - смотрим ТОЛЬКО небольшой левый верхний угол;
    - центральные/нижние синие товары вообще не участвуют в анализе;
    - ищем не просто "синий цвет", а компактный почти квадратный
      компонент, похожий на кольцо логотипа;
    - крупные синие упаковки и детали товара, которые тянутся к краям ROI,
      отбрасываются.

    Возвращает:
        (found: bool, erase_box: tuple|None)
    """
    rgb = im.convert("RGB")
    w, h = rgb.size
    min_side = min(w, h)

    # Логотип на ваших карточках занимает примерно 14–18% стороны.
    # ROI 24% достаточно, но не захватывает основной товар ниже/правее.
    roi_side = max(48, int(min_side * 0.24))
    roi_side = min(roi_side, w, h)

    region = rgb.crop((0, 0, roi_side, roi_side))

    # Для скорости приводим ROI максимум к 180x180.
    detect_side = min(180, roi_side)
    if roi_side > detect_side:
        small = region.resize(
            (detect_side, detect_side),
            Image.Resampling.BILINEAR
        )
    else:
        small = region

    sw, sh = small.size
    coords = _mixpc_logo_color_mask(small)
    if not coords:
        return False, None

    # Бинарная карта фирменных сине-бирюзовых пикселей.
    mask = [[False] * sw for _ in range(sh)]
    for x, y in coords:
        if 0 <= x < sw and 0 <= y < sh:
            mask[y][x] = True

    # Ищем связные компоненты (8 соседей).
    # Кольцо логотипа обычно является самым характерным компактным компонентом.
    visited = [[False] * sw for _ in range(sh)]
    components = []

    for sy in range(sh):
        for sx in range(sw):
            if not mask[sy][sx] or visited[sy][sx]:
                continue

            stack = [(sx, sy)]
            visited[sy][sx] = True

            count = 0
            x1 = x2 = sx
            y1 = y2 = sy

            while stack:
                x, y = stack.pop()
                count += 1
                x1 = min(x1, x)
                x2 = max(x2, x)
                y1 = min(y1, y)
                y2 = max(y2, y)

                for ny in range(max(0, y - 1), min(sh, y + 2)):
                    for nx in range(max(0, x - 1), min(sw, x + 2)):
                        if nx == x and ny == y:
                            continue
                        if mask[ny][nx] and not visited[ny][nx]:
                            visited[ny][nx] = True
                            stack.append((nx, ny))

            components.append({
                "count": count,
                "x1": x1,
                "x2": x2,
                "y1": y1,
                "y2": y2,
            })

    if not components:
        return False, None

    candidates = []

    for c in components:
        bw = c["x2"] - c["x1"] + 1
        bh = c["y2"] - c["y1"] + 1
        area = bw * bh
        aspect = bw / max(1, bh)
        fill = c["count"] / max(1, area)

        # Кольцо может быть не очень "плотным", поэтому fill широкий.
        enough_pixels = c["count"] >= max(20, int(sw * sh * 0.0035))
        big_enough = (
            bw >= max(18, int(sw * 0.28))
            and bh >= max(18, int(sh * 0.28))
        )
        square_like = 0.72 <= aspect <= 1.38

        # Лого начинается близко к левому верхнему краю,
        # но не обязано касаться самого края.
        upper_left = (
            c["x1"] <= int(sw * 0.22)
            and c["y1"] <= int(sh * 0.22)
        )

        # Синие товары/упаковки часто уходят к правому или нижнему краю ROI.
        # Логотип, наоборот, целиком помещается внутри ROI.
        safely_inside = (
            c["x2"] < int(sw * 0.90)
            and c["y2"] < int(sh * 0.90)
        )

        plausible_fill = 0.015 <= fill <= 0.55

        if (
            enough_pixels
            and big_enough
            and square_like
            and upper_left
            and safely_inside
            and plausible_fill
        ):
            # Приоритет: крупный почти квадратный компонент ближе к углу.
            score = (
                c["count"]
                + min(bw, bh) * 4
                - (c["x1"] + c["y1"]) * 2
                - abs(bw - bh) * 3
            )
            candidates.append((score, c))

    if not candidates:
        return False, None

    candidates.sort(key=lambda x: x[0], reverse=True)
    c = candidates[0][1]

    # Для кольца берём bbox компонента и расширяем его так,
    # чтобы захватить внутренние буквы MIX PC и антиалиасинг.
    scale_x = roi_side / max(1, sw)
    scale_y = roi_side / max(1, sh)

    x1 = int(c["x1"] * scale_x)
    x2 = int((c["x2"] + 1) * scale_x)
    y1 = int(c["y1"] * scale_y)
    y2 = int((c["y2"] + 1) * scale_y)

    # Запас вокруг кольца. Размер берём от самого найденного логотипа,
    # а не от всей фотографии.
    logo_size = max(x2 - x1, y2 - y1)
    pad = max(6, int(logo_size * 0.12))

    ex1 = max(0, x1 - pad)
    ey1 = max(0, y1 - pad)
    ex2 = min(w, x2 + pad)
    ey2 = min(h, y2 + pad)

    return True, (ex1, ey1, ex2, ey2)


def remove_old_logo(im: Image.Image, box_ratio: float = 0.20, fill=(255, 255, 255)):
    """
    Удаляет логотип мягкой эллиптической маской, а не белым квадратом.
    Маска чуть расширяется и имеет мягкий край, чтобы не оставлять дугу/ореол.
    """
    if im.mode not in ("RGB", "RGBA"):
        im = im.convert("RGBA" if "A" in im.getbands() else "RGB")

    found, erase_box = detect_old_logo(im, box_ratio)
    if not found or not erase_box:
        return im.copy(), False, None

    out = im.copy()
    x1, y1, x2, y2 = erase_box
    bw = max(1, x2 - x1)
    bh = max(1, y2 - y1)

    # Ещё небольшой запас вокруг найденной зоны.
    extra = max(3, int(min(im.size) * 0.008))
    x1 = max(0, x1 - extra)
    y1 = max(0, y1 - extra)
    x2 = min(im.width, x2 + extra)
    y2 = min(im.height, y2 + extra)
    bw = x2 - x1
    bh = y2 - y1

    # Маска эллипса с лёгким feather.
    mask = Image.new("L", (bw, bh), 0)
    draw = ImageDraw.Draw(mask)
    inset = max(1, int(min(bw, bh) * 0.015))
    draw.ellipse(
        (inset, inset, bw - inset - 1, bh - inset - 1),
        fill=255
    )
    feather = max(1.0, min(bw, bh) * 0.018)
    mask = mask.filter(ImageFilter.GaussianBlur(radius=feather))

    if out.mode == "RGBA":
        white_patch = Image.new("RGBA", (bw, bh), (*fill, 255))
    else:
        white_patch = Image.new("RGB", (bw, bh), fill)

    crop = out.crop((x1, y1, x2, y2))
    blended = Image.composite(white_patch, crop, mask)
    out.paste(blended, (x1, y1))

    return out, True, (x1, y1, x2, y2)


def get_object_bbox(im: Image.Image, threshold: int = 20, ignore_box=None):
    rgb = im.convert("RGB")

    if ignore_box:
        rgb = rgb.copy()
        x1, y1, x2, y2 = ignore_box
        rgb.paste((255, 255, 255), (x1, y1, x2, y2))

    white = Image.new("RGB", rgb.size, (255, 255, 255))
    diff = ImageChops.difference(rgb, white).convert("L")
    mask = diff.point(lambda p: 255 if p > threshold else 0)
    return mask.getbbox()


def center_object_smart(
    im: Image.Image,
    threshold: int = 20,
    ignore_box=None,
    tolerance_ratio: float = 0.035
):
    """
    Центрирует только если товар реально смещён.

    tolerance_ratio=0.035 означает:
    если центр товара отличается от центра холста меньше чем примерно на 3.5%
    по каждой оси, фото считается уже отцентрированным и не двигается.

    Возвращает:
      image, centered(bool), dx, dy
    """
    bbox = get_object_bbox(im, threshold, ignore_box=ignore_box)
    if not bbox:
        return im.copy(), False, 0, 0

    x1, y1, x2, y2 = bbox
    obj_w, obj_h = x2 - x1, y2 - y1
    w, h = im.size

    if obj_w >= w * 0.98 or obj_h >= h * 0.98:
        return im.copy(), False, 0, 0

    target_x = round((w - obj_w) / 2)
    target_y = round((h - obj_h) / 2)
    dx = target_x - x1
    dy = target_y - y1

    tol_x = max(4, round(w * tolerance_ratio))
    tol_y = max(4, round(h * tolerance_ratio))

    # Уже достаточно по центру — не трогаем.
    if abs(dx) <= tol_x and abs(dy) <= tol_y:
        return im.copy(), False, 0, 0

    if im.mode == "RGBA":
        canvas = Image.new("RGBA", im.size, (255, 255, 255, 255))
        canvas.alpha_composite(im, (dx, dy))
    else:
        canvas = Image.new("RGB", im.size, (255, 255, 255))
        canvas.paste(im, (dx, dy))

    return canvas, True, dx, dy


def center_object(im: Image.Image, threshold: int = 20, ignore_box=None) -> Image.Image:
    # Совместимость со старым кодом.
    out, _, _, _ = center_object_smart(
        im,
        threshold=threshold,
        ignore_box=ignore_box
    )
    return out


def process_pil_with_info(
    im: Image.Image,
    box_ratio: float,
    do_center: bool,
    threshold: int
):
    """
    Умная обработка v1.2 STEP 3.

    ЖЁСТКОЕ ПРАВИЛО:
    логотип не найден -> changed=False -> фото не обрабатываем и не перезаписываем.

    Если логотип найден:
    - удаляем его мягкой эллиптической маской;
    - центрируем только если товар действительно смещён.
    """
    out, logo_found, erase_box = remove_old_logo(im, box_ratio)

    if not logo_found:
        return im.copy(), {
            "changed": False,
            "logo_found": False,
            "centered": False,
            "shift_x": 0,
            "shift_y": 0,
            "erase_box": None,
        }

    centered = False
    dx = 0
    dy = 0

    if do_center:
        out, centered, dx, dy = center_object_smart(
            out,
            threshold=threshold,
            ignore_box=erase_box,
            tolerance_ratio=0.035
        )

    return out, {
        "changed": True,
        "logo_found": True,
        "centered": centered,
        "shift_x": dx,
        "shift_y": dy,
        "erase_box": erase_box,
    }


def process_pil(im: Image.Image, box_ratio: float, do_center: bool, threshold: int) -> Image.Image:
    out, _ = process_pil_with_info(
        im, box_ratio, do_center, threshold
    )
    return out


def encode_image(im: Image.Image, filename: str) -> bytes:
    ext = Path(filename).suffix.lower()
    out = io.BytesIO()

    if ext in (".jpg", ".jpeg"):
        im.convert("RGB").save(out, format="JPEG", quality=95, optimize=True)
    elif ext == ".webp":
        im.save(out, format="WEBP", quality=95, method=6)
    else:
        im.save(out, format="PNG", optimize=True)

    return out.getvalue()


# =========================================================
# MOYSKLAD
# =========================================================

class MoySkladClient:
    """
    Клиент с ограничением частоты запросов и автоматическим повтором при 429.
    """
    def __init__(self, token: str):
        token = token.strip()
        if not token:
            raise RuntimeError("Токен пуст.")

        self.s = requests.Session()
        if TLS_CA_PATH:
            self.s.verify = TLS_CA_PATH

        self.s.headers.update({
            "Authorization": f"Bearer {token}",
            "Accept": "application/json;charset=utf-8",
            "Content-Type": "application/json;charset=utf-8",
            "Accept-Encoding": "gzip, deflate",
            "User-Agent": "MIX-PC-Photo-Cleaner/1.3.5",
            "X-Lognex-Remap-Beta-Feature": "assortmentWithoutStock",
        })

        # Консервативный лимит: около 4 запросов/сек от этой программы.
        self.min_interval = 0.30
        self.max_retries = 8
        self._lock = threading.Lock()
        self._last_request_ts = 0.0
        self.status_callback = None

    def set_status_callback(self, callback):
        self.status_callback = callback

    def _status(self, text):
        if self.status_callback:
            try:
                self.status_callback(text)
            except Exception:
                pass

    @staticmethod
    def _api_error(r):
        if r.status_code == 401:
            return RuntimeError("МойСклад не принял токен (401).")
        if r.status_code == 403:
            return RuntimeError("Недостаточно прав для операции (403).")

        detail = ""
        try:
            data = r.json()
            errors = data.get("errors") or []
            if errors:
                detail = errors[0].get("error", "")
        except Exception:
            pass

        msg = f"{r.status_code} {r.reason}"
        if detail:
            msg += "\n" + detail
        return RuntimeError(msg)

    def _wait_for_slot(self):
        with self._lock:
            now = time.monotonic()
            wait = self.min_interval - (now - self._last_request_ts)
            if wait > 0:
                time.sleep(wait)
            self._last_request_ts = time.monotonic()

    def _request(self, method: str, url: str, **kwargs):
        """
        Единая точка HTTP-запросов к МойСклад.

        Временные ошибки 429/500/502/503/504 и сетевые сбои
        автоматически повторяются. Это особенно важно при массовом
        прогоне категорий: краткий 503 больше не обрывает всю операцию.
        """
        transient_statuses = {429, 500, 502, 503, 504}
        retry_delays = [2, 5, 10, 20, 30]

        last_response = None
        last_exception = None
        total_attempts = len(retry_delays) + 1

        for attempt in range(total_attempts):
            self._wait_for_slot()

            try:
                response = self.s.request(method, url, **kwargs)
                last_response = response
                last_exception = None
            except requests.RequestException as e:
                response = None
                last_exception = e

            # Успешный или постоянный HTTP-код — отдаём вызывающему коду.
            if response is not None and response.status_code not in transient_statuses:
                return response

            # Последняя попытка — прекращаем retry.
            if attempt >= len(retry_delays):
                break

            # Retry-After у МойСклад имеет приоритет для 429/503.
            delay = None
            status_code = None

            if response is not None:
                status_code = response.status_code
                retry_after = response.headers.get("Retry-After")
                if retry_after:
                    try:
                        delay = float(retry_after)
                    except Exception:
                        delay = None

            if delay is None:
                delay = retry_delays[attempt]

            short_url = str(url)
            if len(short_url) > 140:
                short_url = short_url[:137] + "..."

            if response is not None:
                status_text = f"HTTP {response.status_code}"
            else:
                status_text = type(last_exception).__name__

            self._status(
                f"МойСклад временно недоступен ({status_text}). "
                f"Запрос: {method.upper()} {short_url}. "
                f"Повтор {attempt + 2}/{total_attempts} через {delay:g} сек…"
            )

            time.sleep(delay)

        if last_response is not None:
            return last_response

        if last_exception is not None:
            raise RuntimeError(
                f"Ошибка сети при обращении к МойСклад: {last_exception}"
            )

        raise RuntimeError(
            "Не удалось выполнить запрос к МойСклад после повторных попыток."
        )

    def get_json(self, path_or_url: str, params=None):
        url = path_or_url if path_or_url.startswith("http") else API + path_or_url
        r = self._request("GET", url, params=params, timeout=60)
        if not r.ok:
            raise self._api_error(r)
        return r.json()

    def get_bytes(self, url: str) -> bytes:
        r = self._request("GET", url, timeout=90)
        if not r.ok:
            raise self._api_error(r)
        return r.content

    def post_json(self, path_or_url: str, payload):
        url = path_or_url if path_or_url.startswith("http") else API + path_or_url
        r = self._request("POST", url, json=payload, timeout=180)
        if not r.ok:
            raise self._api_error(r)
        if not r.content:
            return None
        try:
            return r.json()
        except Exception:
            return None

    def put_json(self, path_or_url: str, payload):
        url = path_or_url if path_or_url.startswith("http") else API + path_or_url
        r = self._request("PUT", url, json=payload, timeout=180)
        if not r.ok:
            raise self._api_error(r)
        if not r.content:
            return None
        try:
            return r.json()
        except Exception:
            return None

    def product_attribute_metadata(self):
        data = self.get_json("/entity/product/metadata")
        result = {}
        for attr in data.get("attributes") or []:
            attr_id = attr.get("id")
            name = attr.get("name")
            if attr_id and name:
                result[attr_id] = name
        return result

    def variants_for_product(self, product_id: str):
        rows = []
        offset = 0
        while True:
            data = self.get_json(
                "/entity/variant",
                {
                    "filter": f"productid={product_id}",
                    "expand": "images",
                    "limit": 100,
                    "offset": offset,
                }
            )
            batch = data.get("rows", [])
            rows.extend(batch)
            if len(batch) < 100:
                break
            offset += 100
        return rows

    def get_variant(self, variant_id: str):
        return self.get_json(f"/entity/variant/{variant_id}", {"expand": "images"})

    def replace_variant_images(self, variant_id: str, payload: list[dict]):
        return self.put_json(f"/entity/variant/{variant_id}", {"images": payload})

    def replace_main_variant_image(self, variant_id: str, new_filename: str, new_bytes: bytes, current_images: list[dict]):
        payload = [{
            "filename": new_filename,
            "content": base64.b64encode(new_bytes).decode("ascii")
        }]
        for image in current_images[1:]:
            meta = image.get("meta")
            if meta:
                payload.append({"meta": meta})
        return self.replace_variant_images(variant_id, payload)

    def test(self):
        return self.get_json("/entity/productfolder", {"limit": 1})

    def all_products(self, batch_limit=1000):
        rows = []
        offset = 0
        while True:
            data = self.get_json("/entity/product", {"limit": batch_limit, "offset": offset})
            batch = data.get("rows", [])
            rows.extend(batch)
            if len(batch) < batch_limit:
                break
            offset += batch_limit
        return rows

    def update_product_name(self, product_id: str, new_name: str):
        return self.put_json(f"/entity/product/{product_id}", {"name": new_name})

    def product_metadata(self):
        return self.get_json("/entity/product/metadata")

    def product_attribute_metadata(self):
        """
        В актуальном МойСклад /entity/product/metadata часто возвращает:
        "attributes": {
            "meta": {
                "href": ".../entity/product/metadata/attributes",
                ...
            }
        }

        То есть сами дополнительные поля НЕ лежат внутри product/metadata —
        там только ссылка на отдельную коллекцию. Её и нужно запрашивать.
        """
        metadata = self.product_metadata()
        if not isinstance(metadata, dict):
            raise RuntimeError(
                f"/entity/product/metadata вернул {type(metadata).__name__}, ожидался object."
            )

        attrs = metadata.get("attributes")

        # Иногда API может вернуть сам список напрямую.
        if isinstance(attrs, list):
            return [x for x in attrs if isinstance(x, dict)]

        if isinstance(attrs, dict):
            # Редкий случай: rows уже развёрнуты.
            rows = attrs.get("rows")
            if isinstance(rows, list):
                return [x for x in rows if isinstance(x, dict)]

            # Нормальный для вашего аккаунта случай:
            # attributes = {"meta": {"href": ".../metadata/attributes"}}
            meta = attrs.get("meta")
            if isinstance(meta, dict):
                href = meta.get("href")
            elif isinstance(meta, str):
                href = meta
            else:
                href = None

            if href:
                data = self.get_json(href)

                if isinstance(data, list):
                    return [x for x in data if isinstance(x, dict)]

                if isinstance(data, dict):
                    rows = data.get("rows")
                    if isinstance(rows, list):
                        return [x for x in rows if isinstance(x, dict)]

                    # На случай одиночного объекта.
                    if data.get("id") and data.get("name"):
                        return [data]

                raise RuntimeError(
                    "Коллекция metadata/attributes вернула неожиданный формат."
                )

        # Последний безопасный fallback — прямой endpoint.
        data = self.get_json("/entity/product/metadata/attributes")
        if isinstance(data, list):
            return [x for x in data if isinstance(x, dict)]
        if isinstance(data, dict):
            rows = data.get("rows")
            if isinstance(rows, list):
                return [x for x in rows if isinstance(x, dict)]

        raise RuntimeError(
            "Не удалось получить метаданные дополнительных полей товара."
        )

    def custom_entity_rows(self, metadata_href: str):
        """
        Загружает элементы пользовательского справочника.

        customEntityMeta у МойСклад может быть в двух форматах:

        1) /context/companysettings/metadata/customEntities/<UUID>
        2) /entity/customentity/<UUID>/metadata

        Сам список значений всегда читаем через:
        /entity/customentity/<UUID>
        """
        href = str(metadata_href or "").strip()

        patterns = [
            r"/context/companysettings/metadata/customEntities/([^/?]+)",
            r"/companysettings/metadata/customEntities/([^/?]+)",
            r"/entity/customentity/([^/?]+)(?:/metadata)?",
        ]

        dictionary_id = None
        for pattern in patterns:
            m = re.search(pattern, href, flags=re.IGNORECASE)
            if m:
                dictionary_id = m.group(1)
                break

        if not dictionary_id:
            raise RuntimeError(
                "Не удалось определить ID пользовательского справочника "
                f"из customEntityMeta: {href}"
            )

        rows = []
        offset = 0

        while True:
            data = self.get_json(
                f"/entity/customentity/{dictionary_id}",
                {"limit": 1000, "offset": offset}
            )

            if isinstance(data, list):
                batch = data
            elif isinstance(data, dict):
                batch = data.get("rows") or []
            else:
                raise RuntimeError(
                    f"Справочник вернул неожиданный тип: {type(data).__name__}"
                )

            if not isinstance(batch, list):
                raise RuntimeError(
                    f"rows справочника имеет тип {type(batch).__name__}, ожидался list."
                )

            rows.extend(batch)

            if len(batch) < 1000:
                break

            offset += 1000

        return rows


    def update_product_custom_attribute(
        self,
        product_id: str,
        attribute_meta: dict,
        value_meta: dict
    ):
        payload = {
            "attributes": [
                {
                    "meta": attribute_meta,
                    "value": {
                        "meta": value_meta
                    }
                }
            ]
        }
        return self.put_json(
            f"/entity/product/{product_id}",
            payload
        )

    def product_folders(self):
        rows = []
        offset = 0
        while True:
            data = self.get_json("/entity/productfolder", {"limit": 1000, "offset": offset})
            batch = data.get("rows", [])
            rows.extend(batch)
            if len(batch) < 1000:
                break
            offset += 1000
        return rows

    def products_in_folder(self, folder_href: str, batch_limit=100):
        offset = 0
        while True:
            params = {
                "filter": f"productFolder={folder_href};type=product;withSubFolders=false",
                "expand": "images",
                "limit": batch_limit,
                "offset": offset,
            }
            data = self.get_json("/entity/assortment", params)
            rows = data.get("rows", [])
            yield from rows
            if len(rows) < batch_limit:
                break
            offset += batch_limit

    def count_products_in_folder(self, folder_href: str) -> int:
        params = {
            "filter": f"productFolder={folder_href};type=product;withSubFolders=false",
            "limit": 1,
            "offset": 0,
        }
        data = self.get_json("/entity/assortment", params)
        return int((data.get("meta") or {}).get("size") or 0)

    def replace_product_images(self, product_id: str, payload: list[dict]):
        return self.post_json(f"/entity/product/{product_id}/images", payload)


    def replace_main_product_image(self, product_id: str, new_filename: str, new_bytes: bytes, current_images: list[dict]):
        """
        Заменяет только главное (первое) фото товара.
        Остальные изображения сохраняются в прежнем порядке через их meta.
        """
        payload = [{
            "filename": new_filename,
            "content": base64.b64encode(new_bytes).decode("ascii")
        }]

        # Все изображения, кроме первого, оставляем без перезагрузки.
        for image in current_images[1:]:
            meta = image.get("meta")
            if meta:
                payload.append({"meta": meta})

        return self.replace_product_images(product_id, payload)


# =========================================================
# DATA
# =========================================================

@dataclass
class FolderNode:
    id: str
    name: str
    href: str
    parent_href: str | None = None
    children: list["FolderNode"] = field(default_factory=list)
    direct_products: int | None = None
    total_products: int | None = None


@dataclass
class PreviewItem:
    product_name: str
    folder_name: str
    filename: str
    image_no: int
    image_total: int
    original: Image.Image
    processed: Image.Image


@dataclass
class PreparedImage:
    filename: str
    original_bytes: bytes
    processed_bytes: bytes
    changed: bool = True
    meta: dict | None = None
    centered: bool = False
    shift_x: int = 0
    shift_y: int = 0


@dataclass
class PreparedProduct:
    product_id: str
    product_name: str
    folder_name: str
    images: list[PreparedImage]
    selected: bool = True
    status: str = "Готов"


@dataclass
class RestoreProduct:
    product_id: str
    product_name: str
    category: str
    product_dir: Path
    images: list[dict]
    selected: bool = True
    status: str = "Готов к восстановлению"
    entity_type: str = "product"


@dataclass
class ModelMatchItem:
    product_id: str
    product_name: str
    current_model: str = ""
    proposed_model: str = ""
    proposed_meta: dict | None = None
    confidence: int = 0
    status: str = ""
    selected: bool = False


@dataclass
class RenameItem:
    product_id: str
    old_name: str
    new_name: str
    selected: bool = True
    status: str = "Готов"

@dataclass
class MainPhotoMatch:
    folder_name: str
    folder_path: Path
    local_image: Path
    key: str
    color: str | None = None
    parent_color: str | None = None
    matched_product_id: str | None = None
    matched_product_name: str | None = None
    matched_category: str | None = None
    match_status: str = "Не найдено"
    confidence: int = 0
    candidates: list[dict] = field(default_factory=list)
    variants: list[dict] = field(default_factory=list)
    selected: bool = False
    upload_status: str = ""


# =========================================================
# PREVIEW
# =========================================================

class PreviewWindow:
    def __init__(self, master, items: list[PreviewItem]):
        self.win = Toplevel(master)
        self.win.title("Предпросмотр — До / После")
        self.win.geometry("1040x720")
        self.win.minsize(900, 620)

        self.items = items
        self.index = 0
        self.tk_before = None
        self.tk_after = None

        main = ttk.Frame(self.win, padding=16)
        main.pack(fill=BOTH, expand=True)

        self.title_var = StringVar()
        ttk.Label(main, textvariable=self.title_var, font=("Segoe UI", 15, "bold")).pack(anchor="w")

        self.info_var = StringVar()
        ttk.Label(main, textvariable=self.info_var).pack(anchor="w", pady=(3, 12))

        images = ttk.Frame(main)
        images.pack(fill=BOTH, expand=True)

        left = ttk.LabelFrame(images, text="ДО", padding=10)
        right = ttk.LabelFrame(images, text="ПОСЛЕ", padding=10)
        left.pack(side=LEFT, fill=BOTH, expand=True, padx=(0, 7))
        right.pack(side=RIGHT, fill=BOTH, expand=True, padx=(7, 0))

        self.before_label = ttk.Label(left, anchor="center")
        self.after_label = ttk.Label(right, anchor="center")
        self.before_label.pack(fill=BOTH, expand=True)
        self.after_label.pack(fill=BOTH, expand=True)

        nav = ttk.Frame(main)
        nav.pack(fill=X, pady=(12, 0))

        self.prev_btn = ttk.Button(nav, text="← Назад", command=self.prev)
        self.prev_btn.pack(side=LEFT)

        self.counter_var = StringVar()
        ttk.Label(nav, textvariable=self.counter_var, font=("Segoe UI", 11, "bold")).pack(side=LEFT, padx=16)

        self.next_btn = ttk.Button(nav, text="Вперёд →", command=self.next)
        self.next_btn.pack(side=LEFT)

        ttk.Button(nav, text="Закрыть", command=self.win.destroy).pack(side=RIGHT)
        self.show()

    @staticmethod
    def fit(im, max_w=460, max_h=500):
        img = im.copy().convert("RGB")
        img.thumbnail((max_w, max_h), Image.Resampling.LANCZOS)
        return img

    def show(self):
        item = self.items[self.index]
        self.tk_before = ImageTk.PhotoImage(self.fit(item.original))
        self.tk_after = ImageTk.PhotoImage(self.fit(item.processed))
        self.before_label.configure(image=self.tk_before)
        self.after_label.configure(image=self.tk_after)

        self.title_var.set(item.product_name)
        self.info_var.set(
            f"{item.folder_name}  •  Фото {item.image_no}/{item.image_total}  •  {item.filename}"
        )
        self.counter_var.set(f"{self.index + 1} / {len(self.items)}")
        self.prev_btn.config(state="normal" if self.index > 0 else "disabled")
        self.next_btn.config(state="normal" if self.index < len(self.items) - 1 else "disabled")

    def prev(self):
        if self.index > 0:
            self.index -= 1
            self.show()

    def next(self):
        if self.index < len(self.items) - 1:
            self.index += 1
            self.show()


# =========================================================
# APP
# =========================================================

class App:
    def __init__(self, root):
        self.root = root

        # TLS/CA bundle for packaged Windows build.
        # PyInstaller bundles certifi into _internal/certifi/cacert.pem.
        # Explicitly point Requests/OpenSSL to the bundled certificate file.
        try:
            ca_bundle = certifi.where()
            if ca_bundle and Path(ca_bundle).exists():
                os.environ["SSL_CERT_FILE"] = ca_bundle
                os.environ["REQUESTS_CA_BUNDLE"] = ca_bundle
        except Exception:
            pass
        self.root.title("MIX PC Photo Cleaner")
        self.root.geometry("1100x760")
        self.root.minsize(940, 660)

        self.client = None
        self.folder_by_item = {}
        self.node_by_href = {}

        # Память обработанных категорий.
        # Храним стабильные ID категорий МойСклад, а не их названия.
        self.processed_category_ids = set()
        self.current_process_category_ids = set()

        self.token_var = StringVar()
        self.show_token = BooleanVar(value=False)
        self.connection_var = StringVar(value="Не подключено")

        self.box_ratio = DoubleVar(value=0.20)
        self.center_var = BooleanVar(value=True)
        self.threshold_var = IntVar(value=20)
        self.preview_count = IntVar(value=5)

        self.backup_root_var = StringVar()
        self.prepared_products: list[PreparedProduct] = []
        self.prepared_by_item = {}
        self.upload_errors = []

        # Привязка моделей товаров
        self.model_items: list[ModelMatchItem] = []
        self.model_by_item = {}
        self.model_attribute = None
        self.model_values = []
        self.model_values_by_name = {}
        self.model_sort_reverse = {}
        self.model_category_name = StringVar(value="Процессоры")
        self.model_only_empty = BooleanVar(value=True)
        self.model_status_var = StringVar(
            value="Подключитесь к МойСклад и загрузите модели."
        )

        self.restore_session_var = StringVar()
        self.restore_products: list[RestoreProduct] = []
        self.restore_by_item = {}

        self.main_root_var = StringVar()
        self.main_backup_var = StringVar()
        self.main_matches: list[MainPhotoMatch] = []
        self.main_by_item = {}
        self.main_products_cache: list[dict] = []
        self.main_ignored_folders = set()
        self.rename_items: list[RenameItem] = []
        self.rename_by_item = {}
        self.rename_backup_dir = StringVar()

        # Главное фото: целевой вес и размер.
        self.main_target_kb = IntVar(value=100)
        self.main_max_side = IntVar(value=1200)

        # Управление процессом "Главное фото"
        self.main_pause_event = threading.Event()
        self.main_pause_event.set()
        self.main_process_active = False
        self.main_timer_accumulated = 0.0
        self.main_timer_segment_started = None
        self.main_elapsed_var = StringVar(value="Время: 00:00:00")

        # Таймер обычной обработки фото (вкладка 2)
        self.process_timer_started = None
        self.process_timer_active = False
        self.process_elapsed_var = StringVar(value="Время: 00:00:00")

        # Журнал действий
        self.log_dir = self._init_log_dir()
        self.log_file = self.log_dir / f"MIXPC_{datetime.now().strftime('%Y-%m-%d')}.log"

        # Постоянные данные пользователя. Хранятся отдельно от программы.
        self.app_data_dir = self._init_app_data_dir()
        self.settings_file = self.app_data_dir / "settings.json"
        self.token_file = self.app_data_dir / "moysklad_token.dat"

        # Кэш проверки фотографий.
        # Хранится отдельно от программы и переживает обновления/переустановки.
        self.photo_scan_cache_file = self.app_data_dir / "photo_scan_cache.json"
        self.photo_scan_cache_lock = threading.Lock()
        self.photo_scan_cache = self._load_photo_scan_cache()
        self.photo_cache_status_var = StringVar(
            value=f"Кэш проверки: {len(self.photo_scan_cache.get('images', {}))} фото"
        )

        # Обновления
        self.app_version = "1.3.5"
        self.update_manifest_url = StringVar(
            value="https://mixpcshop.ru/mixpc-cleaner/update/version.json"
        )
        self.update_status_var = StringVar(value="Обновления: не проверялись")
        self.update_info = None

        self.auto_connect_enabled = True
        self._auto_connect_started = False

        # Единый мягкий СТОП для длительных операций.
        self.global_stop_event = threading.Event()
        self.current_operation_name = ""
        self.current_operation_status_var = None

        # Общий прогресс / ETA для длительных операций.
        self.global_progress_started = None
        self.global_progress_total = 0
        self.global_progress_done = 0
        self.global_progress_var = DoubleVar(value=0.0)
        self.global_progress_text = StringVar(value="Готово к работе")

        self._load_persistent_settings()
        self._load_saved_token()

        self._setup_style()
        self._build()
        self.root.protocol("WM_DELETE_WINDOW", self._on_app_close)

        # Автоподключение по сохранённому токену.
        self.root.after(700, self._auto_connect_if_possible)

        # Автопроверка обновлений после запуска.
        self.root.after(
            2000,
            lambda: self.check_for_updates(silent=True)
        )

    def _init_app_data_dir(self):
        base = Path(os.environ.get("LOCALAPPDATA") or Path.home())
        p = base / "MIX PC Photo Cleaner"
        p.mkdir(parents=True, exist_ok=True)
        return p

    @staticmethod
    def _dpapi_encrypt(text: str) -> bytes:
        if os.name != "nt":
            return text.encode("utf-8")

        class DATA_BLOB(ctypes.Structure):
            _fields_ = [
                ("cbData", wintypes.DWORD),
                ("pbData", ctypes.POINTER(ctypes.c_byte)),
            ]

        raw = text.encode("utf-8")
        buf = ctypes.create_string_buffer(raw)
        in_blob = DATA_BLOB(
            len(raw),
            ctypes.cast(buf, ctypes.POINTER(ctypes.c_byte))
        )
        out_blob = DATA_BLOB()

        ok = ctypes.windll.crypt32.CryptProtectData(
            ctypes.byref(in_blob),
            "MIX PC Photo Cleaner",
            None, None, None, 0,
            ctypes.byref(out_blob)
        )
        if not ok:
            raise ctypes.WinError()

        try:
            return ctypes.string_at(out_blob.pbData, out_blob.cbData)
        finally:
            ctypes.windll.kernel32.LocalFree(out_blob.pbData)

    @staticmethod
    def _dpapi_decrypt(data: bytes) -> str:
        if os.name != "nt":
            return data.decode("utf-8")

        class DATA_BLOB(ctypes.Structure):
            _fields_ = [
                ("cbData", wintypes.DWORD),
                ("pbData", ctypes.POINTER(ctypes.c_byte)),
            ]

        buf = ctypes.create_string_buffer(data)
        in_blob = DATA_BLOB(
            len(data),
            ctypes.cast(buf, ctypes.POINTER(ctypes.c_byte))
        )
        out_blob = DATA_BLOB()

        ok = ctypes.windll.crypt32.CryptUnprotectData(
            ctypes.byref(in_blob),
            None, None, None, None, 0,
            ctypes.byref(out_blob)
        )
        if not ok:
            raise ctypes.WinError()

        try:
            return ctypes.string_at(out_blob.pbData, out_blob.cbData).decode("utf-8")
        finally:
            ctypes.windll.kernel32.LocalFree(out_blob.pbData)

    def _load_saved_token(self):
        try:
            if self.token_file.exists():
                token = self._dpapi_decrypt(self.token_file.read_bytes()).strip()
                if token:
                    self.token_var.set(token)
                    self.log_action("Токен МойСклад загружен из защищённого хранилища")
        except Exception as e:
            self.log_action(f"Не удалось загрузить сохранённый токен: {e}", "WARN")

    def _save_token(self, token: str):
        token = token.strip()
        if not token:
            return
        try:
            self.token_file.write_bytes(self._dpapi_encrypt(token))
            self.log_action("Токен МойСклад сохранён в защищённое хранилище")
        except Exception as e:
            self.log_action(f"Не удалось сохранить токен: {e}", "WARN")

    def _load_persistent_settings(self):
        try:
            if not self.settings_file.exists():
                return

            data = json.loads(self.settings_file.read_text(encoding="utf-8"))

            if data.get("backup_root"):
                self.backup_root_var.set(data["backup_root"])
            if data.get("main_backup_root"):
                self.main_backup_var.set(data["main_backup_root"])
            if data.get("rename_backup_root"):
                self.rename_backup_dir.set(data["rename_backup_root"])
            if data.get("main_root"):
                self.main_root_var.set(data["main_root"])

            if "box_ratio" in data:
                self.box_ratio.set(float(data["box_ratio"]))
            if "center" in data:
                self.center_var.set(bool(data["center"]))
            if "threshold" in data:
                self.threshold_var.set(int(data["threshold"]))
            if "main_target_kb" in data:
                self.main_target_kb.set(int(data["main_target_kb"]))
            if "main_max_side" in data:
                self.main_max_side.set(int(data["main_max_side"]))
            if data.get("update_manifest_url"):
                self.update_manifest_url.set(data["update_manifest_url"])

            if "auto_connect_enabled" in data:
                self.auto_connect_enabled = bool(data["auto_connect_enabled"])

            saved_categories = data.get("processed_category_ids") or []
            self.processed_category_ids = set(str(x) for x in saved_categories if x)

        except Exception:
            pass

    def _save_persistent_settings(self):
        try:
            data = {
                "backup_root": self.backup_root_var.get().strip(),
                "main_backup_root": self.main_backup_var.get().strip(),
                "rename_backup_root": self.rename_backup_dir.get().strip(),
                "main_root": self.main_root_var.get().strip(),
                "box_ratio": float(self.box_ratio.get()),
                "center": bool(self.center_var.get()),
                "threshold": int(self.threshold_var.get()),
                "main_target_kb": int(self.main_target_kb.get()),
                "main_max_side": int(self.main_max_side.get()),
                "update_manifest_url": self.update_manifest_url.get().strip(),
                "auto_connect_enabled": bool(self.auto_connect_enabled),
                "processed_category_ids": sorted(self.processed_category_ids),
            }
            self.settings_file.write_text(
                json.dumps(data, ensure_ascii=False, indent=2),
                encoding="utf-8"
            )
        except Exception as e:
            self.log_action(f"Не удалось сохранить настройки: {e}", "WARN")

    def _on_app_close(self):
        self._save_persistent_settings()
        self.root.destroy()

    def _init_log_dir(self):
        base = Path(os.environ.get("LOCALAPPDATA") or Path.home())
        p = base / "MIX PC Photo Cleaner" / "Logs"
        p.mkdir(parents=True, exist_ok=True)
        return p

    def log_action(self, message: str, level: str = "INFO"):
        stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        line = f"[{stamp}] [{level}] {message}"
        try:
            with self.log_file.open("a", encoding="utf-8") as f:
                f.write(line + "\n")
        except Exception:
            pass

        if hasattr(self, "journal_text"):
            try:
                self.journal_text.insert(END, line + "\n")
                self.journal_text.see(END)
            except Exception:
                pass

    @staticmethod
    def format_duration(seconds: float):
        total = max(0, int(round(seconds)))
        h, rem = divmod(total, 3600)
        m, s = divmod(rem, 60)
        return f"{h:02d}:{m:02d}:{s:02d}"

    def _start_process_timer(self):
        self.process_timer_started = time.monotonic()
        self.process_timer_active = True
        self.process_elapsed_var.set("Время: 00:00:00")
        self._update_process_timer()

    def _process_elapsed_seconds(self):
        if self.process_timer_started is None:
            return 0.0
        return time.monotonic() - self.process_timer_started

    def _update_process_timer(self):
        if self.process_timer_active:
            elapsed = self._process_elapsed_seconds()
            self.process_elapsed_var.set(
                f"Время: {self.format_duration(elapsed)}"
            )
            self.root.after(1000, self._update_process_timer)

    def _finish_process_timer(self):
        elapsed = self._process_elapsed_seconds()
        self.process_timer_active = False
        self.process_timer_started = None
        self.process_elapsed_var.set(
            f"Время: {self.format_duration(elapsed)}"
        )
        return elapsed

    def _main_elapsed_seconds(self):
        total = self.main_timer_accumulated
        if self.main_timer_segment_started is not None:
            total += time.monotonic() - self.main_timer_segment_started
        return total

    def _start_main_timer(self):
        self.main_timer_accumulated = 0.0
        self.main_timer_segment_started = time.monotonic()
        self.main_process_active = True
        self._update_main_timer()

    def _pause_main_timer(self):
        if self.main_timer_segment_started is not None:
            self.main_timer_accumulated += time.monotonic() - self.main_timer_segment_started
            self.main_timer_segment_started = None

    def _resume_main_timer(self):
        if self.main_timer_segment_started is None and self.main_process_active:
            self.main_timer_segment_started = time.monotonic()

    def _finish_main_timer(self):
        self._pause_main_timer()
        self.main_process_active = False
        self.main_elapsed_var.set(f"Время: {self.format_duration(self.main_timer_accumulated)}")
        return self.main_timer_accumulated

    def _update_main_timer(self):
        self.main_elapsed_var.set(f"Время: {self.format_duration(self._main_elapsed_seconds())}")
        if self.main_process_active:
            self.root.after(1000, self._update_main_timer)

    def _main_checkpoint(self):
        self.main_pause_event.wait()
        if self.operation_should_stop():
            raise InterruptedError("Остановлено пользователем")

    def stop_main_process(self):
        if not self.main_process_active:
            return
        self.main_pause_event.clear()
        self._pause_main_timer()
        self.log_action("Главное фото: СТОП", "WARN")
        self.main_status.set("Остановлено. Текущий запрос завершится, затем процесс будет ждать.")
        self.main_stop_btn.pack_forget()
        self.main_resume_btn.pack(side=RIGHT, padx=(8, 0))

    def resume_main_process(self):
        if not self.main_process_active:
            return
        self.main_pause_event.set()
        self._resume_main_timer()
        self.log_action("Главное фото: ВОЗОБНОВИТЬ")
        self.main_status.set("Процесс возобновлён…")
        self.main_resume_btn.pack_forget()
        self.main_stop_btn.pack(side=RIGHT, padx=(8, 0))

    def bring_app_to_front(self):
        """Поднять окно программы поверх остальных после завершения операции."""
        try:
            self.root.deiconify()
            self.root.lift()
            self.root.attributes("-topmost", True)
            self.root.focus_force()
            # Topmost нужен только для активации, потом возвращаем обычное поведение.
            self.root.after(
                1600,
                lambda: self.root.attributes("-topmost", False)
            )
        except Exception:
            pass

    def begin_cancellable_operation(self, name: str, status_var=None):
        self.global_stop_event.clear()
        self.current_operation_name = name
        self.current_operation_status_var = status_var
        self.global_stop_btn.config(state="normal")

        self.global_progress_started = time.monotonic()
        self.global_progress_total = 0
        self.global_progress_done = 0
        self.global_progress_var.set(0.0)

        try:
            self.global_progress_bar.stop()
            self.global_progress_bar.configure(mode="indeterminate")
            self.global_progress_bar.start(12)
        except Exception:
            pass

        self.global_progress_text.set(
            f"{name} • запуск… • прошло 00:00"
        )

    def set_operation_total(self, total: int, text: str | None = None):
        total = max(0, int(total or 0))
        self.global_progress_total = total
        self.global_progress_done = 0
        self.global_progress_var.set(0.0)

        if total > 0:
            try:
                self.global_progress_bar.stop()
                self.global_progress_bar.configure(
                    mode="determinate",
                    maximum=100
                )
            except Exception:
                pass

        if text:
            self.update_operation_progress(0, total, text)

    def update_operation_progress(
        self,
        done: int,
        total: int | None = None,
        detail: str | None = None
    ):
        if total is not None:
            self.global_progress_total = max(0, int(total or 0))

        self.global_progress_done = max(0, int(done or 0))
        total = self.global_progress_total

        elapsed = 0.0
        if self.global_progress_started is not None:
            elapsed = max(
                0.0,
                time.monotonic() - self.global_progress_started
            )

        elapsed_txt = self.format_duration(elapsed)
        name = self.current_operation_name or "Операция"

        if total > 0:
            done_safe = min(self.global_progress_done, total)
            pct = (done_safe / total) * 100.0
            self.global_progress_var.set(pct)

            eta_txt = "считаю…"
            if done_safe > 0 and done_safe < total and elapsed > 0:
                rate = elapsed / done_safe
                eta_seconds = rate * (total - done_safe)
                eta_txt = self.format_duration(eta_seconds)
            elif done_safe >= total:
                eta_txt = "00:00"

            text = (
                f"{name} • {done_safe}/{total} • {pct:.0f}% "
                f"• прошло {elapsed_txt} • осталось ≈ {eta_txt}"
            )
        else:
            text = f"{name} • прошло {elapsed_txt}"

        if detail:
            text += f" • {detail}"

        self.global_progress_text.set(text)

    def update_unknown_progress(self, done: int, unit: str = "элементов"):
        elapsed = 0.0
        if self.global_progress_started is not None:
            elapsed = max(
                0.0,
                time.monotonic() - self.global_progress_started
            )
        self.global_progress_text.set(
            f"{self.current_operation_name or 'Операция'} • "
            f"{done} {unit} • прошло {self.format_duration(elapsed)}"
        )

    def finish_cancellable_operation(self):
        elapsed = 0.0
        if self.global_progress_started is not None:
            elapsed = max(
                0.0,
                time.monotonic() - self.global_progress_started
            )

        try:
            self.global_progress_bar.stop()
            self.global_progress_bar.configure(mode="determinate")
        except Exception:
            pass

        if self.global_progress_total > 0 and not self.global_stop_event.is_set():
            self.global_progress_var.set(100.0)

        name = self.current_operation_name or "Операция"
        if self.global_stop_event.is_set():
            self.global_progress_text.set(
                f"{name} • остановлено • прошло {self.format_duration(elapsed)}"
            )
        else:
            self.global_progress_text.set(
                f"{name} • завершено • время {self.format_duration(elapsed)}"
            )

        self.global_stop_btn.config(state="disabled")
        self.current_operation_name = ""
        self.current_operation_status_var = None
        self.global_progress_started = None
        self.global_progress_total = 0
        self.global_progress_done = 0
        self.global_stop_event.clear()

        # После завершения автоматически показываем программу поверх других окон.
        self.bring_app_to_front()


    def request_global_stop(self):
        if not self.current_operation_name:
            return
        self.global_stop_event.set()
        msg = (
            f"Останавливаю: {self.current_operation_name}. "
            "Текущий запрос завершится, затем новые элементы запускаться не будут."
        )
        if self.current_operation_status_var is not None:
            try:
                self.current_operation_status_var.set(msg)
            except Exception:
                pass
        self.global_stop_btn.config(state="disabled")
        self.log_action(f"СТОП: {self.current_operation_name}", "WARN")

    def operation_should_stop(self):
        return self.global_stop_event.is_set()

    @staticmethod
    def _version_tuple(version: str):
        nums = re.findall(r"\d+", str(version))
        nums = [int(x) for x in nums[:4]]
        while len(nums) < 4:
            nums.append(0)
        return tuple(nums)

    def _is_newer_version(self, remote: str):
        return self._version_tuple(remote) > self._version_tuple(self.app_version)

    def check_for_updates(self, silent=False):
        url = self.update_manifest_url.get().strip()
        if not url:
            if not silent:
                messagebox.showinfo("Обновления", "URL обновлений не настроен.")
            return

        self.update_status_var.set("Обновления: проверка…")
        self.log_action(f"Обновления: проверка {url}")

        threading.Thread(
            target=self._check_update_worker,
            args=(url, silent),
            daemon=True
        ).start()

    def _check_update_worker(self, url, silent):
        try:
            r = requests.get(
                url,
                timeout=15,
                headers={"Cache-Control": "no-cache"}
            )
            r.raise_for_status()
            info = r.json()

            remote_version = str(info.get("version", "")).strip()
            package_url = str(info.get("url", "")).strip()
            sha256 = str(info.get("sha256", "")).strip().lower()
            notes = str(info.get("notes", "")).strip()

            if not remote_version or not package_url:
                raise RuntimeError(
                    "Некорректный version.json: отсутствует version или url."
                )

            info["_remote_version"] = remote_version
            info["_package_url"] = package_url
            info["_sha256"] = sha256
            info["_notes"] = notes

            self.root.after(
                0, self._update_check_done, info, silent
            )
        except Exception as e:
            self.root.after(
                0, self._update_check_error, str(e), silent
            )

    def _update_check_done(self, info, silent):
        self.update_info = info
        remote = info["_remote_version"]

        if self._is_newer_version(remote):
            self.update_status_var.set(f"Доступна версия {remote}")
            self.log_action(f"Обновления: доступна версия {remote}")
            self._show_update_offer(info)
        else:
            self.update_status_var.set(f"Актуальная версия {self.app_version}")
            self.log_action("Обновления: актуальная версия")
            if not silent:
                messagebox.showinfo(
                    "Обновления",
                    f"У вас актуальная версия: {self.app_version}"
                )

    def _update_check_error(self, msg, silent):
        self.update_status_var.set("Обновления: сервер недоступен")
        self.log_action(f"Обновления: ошибка проверки: {msg}", "WARN")
        if not silent:
            messagebox.showerror(
                "Обновления",
                f"Не удалось проверить обновления.\n\n{msg}"
            )

    def _show_update_offer(self, info):
        remote = info["_remote_version"]
        notes = info.get("_notes") or "Описание обновления не указано."

        if messagebox.askyesno(
            "Доступно обновление",
            f"Установлена версия: {self.app_version}\n"
            f"Новая версия: {remote}\n\n"
            f"{notes}\n\n"
            "Скачать и установить обновление?"
        ):
            self.download_and_install_update(info)

    def download_and_install_update(self, info=None):
        info = info or self.update_info
        if not info:
            self.check_for_updates(silent=False)
            return

        self.update_status_var.set("Обновления: скачивание…")
        self.log_action(
            f"Обновления: скачивание версии {info['_remote_version']}"
        )

        threading.Thread(
            target=self._download_update_worker,
            args=(info,),
            daemon=True
        ).start()

    def _download_update_worker(self, info):
        try:
            package_url = info["_package_url"]
            expected_hash = info.get("_sha256", "")

            r = requests.get(package_url, timeout=120, stream=True)
            r.raise_for_status()

            temp_root = Path(tempfile.mkdtemp(prefix="mixpc_update_"))
            package_file = temp_root / "update.zip"

            h = hashlib.sha256()
            with package_file.open("wb") as f:
                for chunk in r.iter_content(chunk_size=262144):
                    if not chunk:
                        continue
                    f.write(chunk)
                    h.update(chunk)

            actual_hash = h.hexdigest().lower()

            if expected_hash and actual_hash != expected_hash:
                raise RuntimeError(
                    "Контрольная сумма обновления не совпала. "
                    "Установка отменена."
                )

            extract_dir = temp_root / "payload"
            extract_dir.mkdir(parents=True, exist_ok=True)

            with zipfile.ZipFile(package_file, "r") as z:
                z.extractall(extract_dir)

            self.root.after(
                0,
                self._prepare_update_install,
                info,
                str(extract_dir)
            )

        except Exception as e:
            self.root.after(
                0, self._update_install_error, str(e)
            )

    def _prepare_update_install(self, info, extract_dir_str):
        extract_dir = Path(extract_dir_str)
        frozen = bool(getattr(sys, "frozen", False))

        if frozen:
            current_target = Path(sys.executable)
            candidates = list(
                extract_dir.rglob("MIX PC Photo Cleaner.exe")
            )
            if not candidates:
                messagebox.showerror(
                    "Обновление",
                    "В архиве обновления нет «MIX PC Photo Cleaner.exe»."
                )
                return
            new_target = candidates[0]
        else:
            current_target = Path(__file__).resolve()
            candidates = list(
                extract_dir.rglob("MIX_PC_Photo_Cleaner.pyw")
            )
            if not candidates:
                messagebox.showerror(
                    "Обновление",
                    "В архиве обновления нет MIX_PC_Photo_Cleaner.pyw."
                )
                return
            new_target = candidates[0]

        if not messagebox.askyesno(
            "Установка обновления",
            f"Версия {info['_remote_version']} скачана и проверена.\n\n"
            "Программа закроется, заменит свой файл и запустится снова.\n\n"
            "Продолжить?"
        ):
            self.update_status_var.set(
                "Обновление скачано, установка отменена"
            )
            return

        self._save_persistent_settings()

        ps1 = Path(tempfile.gettempdir()) / "mixpc_apply_update.ps1"
        current = str(current_target)
        newfile = str(new_target)
        pid = os.getpid()

        if frozen:
            restart_line = f'Start-Process -FilePath "{current}"'
        else:
            pythonw = str(Path(sys.executable).with_name("pythonw.exe"))
            if not Path(pythonw).exists():
                pythonw = sys.executable
            restart_line = (
                f'Start-Process -FilePath "{pythonw}" '
                f'-ArgumentList \'"{current}"\''
            )

        lines = [
            '$ErrorActionPreference = "Stop"',
            f'$pidToWait = {pid}',
            f'$current = "{current}"',
            f'$newfile = "{newfile}"',
            'try {',
            '    Wait-Process -Id $pidToWait -ErrorAction SilentlyContinue',
            '    Start-Sleep -Milliseconds 800',
            '    Copy-Item -LiteralPath $newfile -Destination $current -Force',
            f'    {restart_line}',
            '} catch {',
            '    $msg = $_.Exception.Message',
            '    Add-Type -AssemblyName PresentationFramework',
            '    [System.Windows.MessageBox]::Show('
            '"Не удалось установить обновление:`n`n$msg", '
            '"MIX PC Photo Cleaner")',
            '}',
        ]
        ps1.write_text(
            "\r\n".join(lines),
            encoding="utf-8-sig"
        )

        self.log_action(
            f"Обновления: установка версии {info['_remote_version']}"
        )

        subprocess.Popen(
            [
                "powershell.exe",
                "-NoProfile",
                "-ExecutionPolicy", "Bypass",
                "-File", str(ps1),
            ],
            creationflags=getattr(
                subprocess, "CREATE_NO_WINDOW", 0
            ),
        )

        self.root.after(300, self.root.destroy)

    def _update_install_error(self, msg):
        self.update_status_var.set("Обновления: ошибка")
        self.log_action(
            f"Обновления: ошибка установки: {msg}",
            "ERROR"
        )
        messagebox.showerror(
            "Обновление",
            f"Не удалось подготовить обновление.\n\n{msg}"
        )

    def _setup_style(self):
        style = ttk.Style()
        try:
            if "vista" in style.theme_names():
                style.theme_use("vista")
        except Exception:
            pass

        style.configure("Title.TLabel", font=("Segoe UI", 18, "bold"))
        style.configure("H2.TLabel", font=("Segoe UI", 11, "bold"))
        style.configure("Primary.TButton", font=("Segoe UI", 10, "bold"), padding=(14, 8))
        style.configure("Danger.TButton", font=("Segoe UI", 10, "bold"), padding=(14, 8))

    def _build(self):
        shell = ttk.Frame(self.root, padding=16)
        shell.pack(fill=BOTH, expand=True)

        header = ttk.Frame(shell)
        header.pack(fill=X)
        ttk.Label(header, text="MIX PC Photo Cleaner", style="Title.TLabel").pack(side=LEFT)
        ttk.Label(header, text="v1.3.5").pack(side=LEFT, padx=(8, 0), pady=(8, 0))

        self.update_btn = ttk.Button(
            header,
            text="Проверить обновления",
            command=lambda: self.check_for_updates(silent=False)
        )
        self.update_btn.pack(side=RIGHT)

        self.global_stop_btn = ttk.Button(
            header,
            text="СТОП",
            state="disabled",
            command=self.request_global_stop
        )
        self.global_stop_btn.pack(side=RIGHT, padx=(0, 8))

        ttk.Label(
            header,
            textvariable=self.update_status_var
        ).pack(side=RIGHT, padx=(0, 10), pady=(8, 0))

        progress_line = ttk.Frame(shell)
        progress_line.pack(fill=X, pady=(8, 0))

        ttk.Label(
            progress_line,
            textvariable=self.global_progress_text,
            anchor="w"
        ).pack(fill=X, pady=(0, 4))

        self.global_progress_bar = ttk.Progressbar(
            progress_line,
            orient="horizontal",
            mode="determinate",
            maximum=100,
            variable=self.global_progress_var
        )
        self.global_progress_bar.pack(fill=X)

        self.tabs = ttk.Notebook(shell)
        self.tabs.pack(fill=BOTH, expand=True, pady=(14, 0))

        self.catalog_tab = ttk.Frame(self.tabs, padding=14)
        self.process_tab = ttk.Frame(self.tabs, padding=14)
        self.restore_tab = ttk.Frame(self.tabs, padding=14)
        self.main_photo_tab = ttk.Frame(self.tabs, padding=14)
        self.rename_tab = ttk.Frame(self.tabs, padding=14)
        self.models_tab = ttk.Frame(self.tabs, padding=14)
        self.journal_tab = ttk.Frame(self.tabs, padding=14)

        self.tabs.add(self.catalog_tab, text="1. Категории")
        self.tabs.add(self.process_tab, text="2. Обработка")
        self.tabs.add(self.restore_tab, text="3. Восстановление")
        self.tabs.add(self.main_photo_tab, text="4. Главное фото")
        self.tabs.add(self.rename_tab, text="5. Названия Б/у")
        self.tabs.add(self.models_tab, text="6. Модели")
        self.tabs.add(self.journal_tab, text="7. Журнал")

        self._build_catalog()
        self._build_process()
        self._build_restore()
        self._build_main_photo()
        self._build_rename_tab()
        self._build_models_tab()
        self._build_journal()

        self.log_action("Программа запущена")

    # =====================================================
    # 1. CATALOG
    # =====================================================

    def _build_catalog(self):
        connect = ttk.LabelFrame(self.catalog_tab, text="Подключение к МойСклад", padding=12)
        connect.pack(fill=X)

        ttk.Label(connect, text="Токен").grid(row=0, column=0, sticky="w")
        ttk.Label(
            connect,
            text="Токен сохраняется на этом ПК; при следующем запуске подключение выполнится автоматически.",
            foreground="#666666"
        ).grid(row=0, column=1, columnspan=2, sticky="e")
        self.token_entry = ttk.Entry(connect, textvariable=self.token_var, show="•")
        self.token_entry.grid(row=1, column=0, sticky="ew", padx=(0, 8))

        ttk.Button(connect, text="Вставить", command=self.paste_token).grid(row=1, column=1, padx=(0, 8))
        ttk.Button(connect, text="Подключиться", style="Primary.TButton", command=self.connect).grid(row=1, column=2)

        ttk.Checkbutton(connect, text="Показать токен", variable=self.show_token, command=self.toggle_token).grid(
            row=2, column=0, sticky="w", pady=(5, 0)
        )
        ttk.Label(connect, textvariable=self.connection_var).grid(row=2, column=2, sticky="e", pady=(5, 0))
        connect.columnconfigure(0, weight=1)

        menu = Menu(self.root, tearoff=0)
        menu.add_command(label="Вставить", command=self.paste_token)
        menu.add_command(label="Очистить", command=lambda: self.token_var.set(""))
        self.token_entry.bind("<Button-3>", lambda e: menu.tk_popup(e.x_root, e.y_root))

        box = ttk.LabelFrame(self.catalog_tab, text="Категории", padding=10)
        box.pack(fill=BOTH, expand=True, pady=(12, 0))

        bar = ttk.Frame(box)
        bar.pack(fill=X, pady=(0, 7))
        ttk.Label(bar, text="Двойной клик — выбрать категорию").pack(side=LEFT)
        ttk.Button(bar, text="Развернуть всё", command=lambda: self.expand_all(True)).pack(side=RIGHT)
        ttk.Button(bar, text="Свернуть всё", command=lambda: self.expand_all(False)).pack(side=RIGHT, padx=(0, 6))

        cols = ("selected", "processed", "direct", "total")
        self.category_tree = ttk.Treeview(box, columns=cols, show="tree headings", selectmode="browse")
        self.category_tree.heading("#0", text="Категория")
        self.category_tree.heading("selected", text="Выбрано")
        self.category_tree.heading("processed", text="Уже обработано")
        self.category_tree.heading("direct", text="Товаров")
        self.category_tree.heading("total", text="С подпапками")

        self.category_tree.column("#0", width=540)
        self.category_tree.column("selected", width=90, anchor="center")
        self.category_tree.column("processed", width=130, anchor="center")
        self.category_tree.column("direct", width=100, anchor="center")
        self.category_tree.column("total", width=120, anchor="center")
        self.category_scroll = ttk.Scrollbar(
            box,
            orient=VERTICAL,
            command=self.category_tree.yview
        )
        self.category_tree.configure(yscrollcommand=self.category_scroll.set)
        self.category_scroll.pack(side=RIGHT, fill=Y)
        self.category_tree.pack(side=LEFT, fill=BOTH, expand=True)
        self.category_tree.bind("<Double-1>", self.toggle_category)

        footer = ttk.Frame(self.catalog_tab)
        footer.pack(fill=X, pady=(10, 0))

        self.category_summary = ttk.Label(footer, text="Категории ещё не загружены", style="H2.TLabel")
        self.category_summary.pack(side=LEFT)

        ttk.Button(
            footer,
            text="Снять отметку «обработано»",
            command=self.clear_processed_category_mark
        ).pack(side=LEFT, padx=(12, 0))

        ttk.Button(
            footer,
            text="Отметить обработанной",
            command=self.mark_focused_category_processed
        ).pack(side=LEFT, padx=(6, 0))

        ttk.Button(
            footer, text="Перейти к обработке →", style="Primary.TButton",
            command=lambda: self.tabs.select(self.process_tab)
        ).pack(side=RIGHT)

        self.catalog_status = StringVar(value="Подключитесь к МойСклад.")
        ttk.Label(self.catalog_tab, textvariable=self.catalog_status).pack(anchor="w", pady=(6, 0))

        ttk.Label(
            self.catalog_tab,
            text=(
                "✓ в колонке «Уже обработано» сохраняется между запусками. "
                "После успешной загрузки без ошибок программа ставит отметку автоматически."
            ),
            foreground="#666666"
        ).pack(anchor="w", pady=(3, 0))

    def paste_token(self):
        try:
            self.token_var.set(self.root.clipboard_get().strip())
        except Exception:
            messagebox.showerror("Буфер обмена", "В буфере обмена нет текста.")

    def toggle_token(self):
        self.token_entry.config(show="" if self.show_token.get() else "•")

    def _auto_connect_if_possible(self):
        """Автоподключение к МойСклад по сохранённому токену."""
        if self._auto_connect_started or not self.auto_connect_enabled:
            return

        token = self.token_var.get().strip()
        if not token:
            return

        self._auto_connect_started = True
        try:
            self.log_action("МойСклад: автоподключение по сохранённому токену")
            self.connect()
        except Exception as e:
            self.log_action(
                f"МойСклад: автоподключение не удалось: {e}",
                "WARN"
            )

    def connect(self):
        token = self.token_var.get().strip()
        if not token:
            messagebox.showinfo("MIX PC", "Вставьте токен МойСклад.")
            return

        self.connection_var.set("Подключение…")
        self.catalog_status.set("Загружаю категории…")
        threading.Thread(target=self._connect_worker, args=(token,), daemon=True).start()

    def _connect_worker(self, token):
        try:
            client = MoySkladClient(token)
            client.set_status_callback(
                lambda txt: self.root.after(0, self._api_status, txt)
            )
            client.test()
            folders = client.product_folders()
            self.client = client
            self._save_token(token)
            self._save_persistent_settings()
            self.log_action(f"МойСклад: подключение успешно, категорий {len(folders)}")
            self.root.after(0, self._populate_categories, folders)
        except Exception as e:
            self.root.after(0, self._connect_error, str(e))

    def _api_status(self, text):
        low = text.lower()
        if (
            "ограничил скорость" in low
            or "временно недоступен" in low
            or "повтор " in low
        ):
            self.log_action(text, "WARN")
        try:
            current = self.tabs.select()
            if current == str(self.catalog_tab):
                self.catalog_status.set(text)
            elif current == str(self.process_tab):
                self.process_status.set(text)
            elif current == str(self.restore_tab):
                self.restore_status.set(text)
            elif current == str(self.main_photo_tab):
                self.main_status.set(text)
            elif current == str(self.models_tab):
                self.model_status_var.set(text)
        except Exception:
            pass

    def _connect_error(self, msg):
        self.log_action(f"МойСклад: ошибка подключения: {msg}", "ERROR")
        self.connection_var.set("Ошибка")
        self.catalog_status.set("Не удалось подключиться.")
        messagebox.showerror("МойСклад", msg)

    def _populate_categories(self, folders):
        self.category_tree.delete(*self.category_tree.get_children())
        self.folder_by_item.clear()
        self.node_by_href.clear()

        for f in folders:
            href = (f.get("meta") or {}).get("href", "")
            parent_href = (f.get("productFolder") or {}).get("meta", {}).get("href")
            self.node_by_href[href] = FolderNode(
                id=f.get("id", ""),
                name=f.get("name", "(без имени)"),
                href=href,
                parent_href=parent_href,
            )

        roots = []
        for node in self.node_by_href.values():
            if node.parent_href and node.parent_href in self.node_by_href:
                self.node_by_href[node.parent_href].children.append(node)
            else:
                roots.append(node)

        def add(parent, node):
            processed = node.id in self.processed_category_ids
            item = self.category_tree.insert(
                parent,
                "end",
                text=node.name,
                values=("☐", "✓" if processed else "", "…", "…"),
                open=False
            )
            self.folder_by_item[item] = {
                "node": node,
                "selected": False,
                "processed": processed,
            }
            for child in sorted(node.children, key=lambda x: x.name.lower()):
                add(item, child)

        for root in sorted(roots, key=lambda x: x.name.lower()):
            add("", root)

        # Обновляем универсальный список категорий на вкладке «Модели».
        try:
            model_categories = sorted(
                {
                    node.name.strip()
                    for node in self.node_by_href.values()
                    if node.name and node.name.strip()
                },
                key=str.lower
            )
            self.model_category_combo["values"] = model_categories

            current = self.model_category_name.get().strip()
            if current not in model_categories:
                if "Процессоры" in model_categories:
                    self.model_category_name.set("Процессоры")
                elif model_categories:
                    self.model_category_name.set(model_categories[0])
        except Exception as e:
            self.log_action(
                f"Модели: не удалось обновить список категорий: {e}",
                "WARN"
            )

        self.connection_var.set(f"Подключено • {len(folders)} категорий")
        self.catalog_status.set("Категории готовы. Считаю товары в фоне — можно уже выбирать категории.")
        self.update_category_summary()

        threading.Thread(target=self._count_worker, daemon=True).start()

    def _count_worker(self):
        try:
            nodes = list(self.node_by_href.values())
            for idx, node in enumerate(nodes, 1):
                node.direct_products = self.client.count_products_in_folder(node.href)
                self.root.after(0, self._update_direct_count, node.href, node.direct_products, idx, len(nodes))
                time.sleep(0.10)

            roots = [n for n in nodes if not n.parent_href or n.parent_href not in self.node_by_href]

            def calc(node):
                total = int(node.direct_products or 0)
                for ch in node.children:
                    total += calc(ch)
                node.total_products = total
                return total

            for root in roots:
                calc(root)

            self.root.after(0, self._refresh_totals)
        except Exception as e:
            self.root.after(0, self.catalog_status.set, f"Не удалось досчитать товары: {e}")

    def _update_direct_count(self, href, count, idx, total):
        for item, data in self.folder_by_item.items():
            if data["node"].href == href:
                vals = list(self.category_tree.item(item, "values"))
                vals[2] = count
                self.category_tree.item(item, values=vals)
                break
        self.catalog_status.set(f"Считаю товары: {idx}/{total}")
        self.update_category_summary()

    def _refresh_totals(self):
        for item, data in self.folder_by_item.items():
            node = data["node"]
            vals = list(self.category_tree.item(item, "values"))
            vals[1] = "✓" if data.get("processed") else ""
            vals[2] = int(node.direct_products or 0)
            vals[3] = int(node.total_products or 0)
            self.category_tree.item(item, values=vals)

        total = sum(int(n.direct_products or 0) for n in self.node_by_href.values())
        self.catalog_status.set(f"Готово • всего товаров по категориям: {total}")
        self.update_category_summary()

    def _refresh_processed_category_marks(self):
        for item, data in self.folder_by_item.items():
            node = data["node"]
            processed = node.id in self.processed_category_ids
            data["processed"] = processed

            vals = list(self.category_tree.item(item, "values"))
            if len(vals) >= 2:
                vals[1] = "✓" if processed else ""
                self.category_tree.item(item, values=vals)

        self.update_category_summary()

    def _focused_category_data(self):
        item = self.category_tree.focus()
        if not item or item not in self.folder_by_item:
            return None, None
        return item, self.folder_by_item[item]

    def mark_focused_category_processed(self):
        item, data = self._focused_category_data()
        if not data:
            messagebox.showinfo("Категории", "Сначала выберите категорию.")
            return

        node = data["node"]
        self.processed_category_ids.add(node.id)
        self._save_persistent_settings()
        self._refresh_processed_category_marks()
        self.log_action(
            f"Категория вручную отмечена обработанной: {node.name} [{node.id}]"
        )

    def clear_processed_category_mark(self):
        item, data = self._focused_category_data()
        if not data:
            messagebox.showinfo("Категории", "Сначала выберите категорию.")
            return

        node = data["node"]
        if node.id not in self.processed_category_ids:
            return

        if not messagebox.askyesno(
            "Категории",
            f"Снять отметку «обработано» с категории:\n\n{node.name}?"
        ):
            return

        self.processed_category_ids.discard(node.id)
        self._save_persistent_settings()
        self._refresh_processed_category_marks()
        self.log_action(
            f"Снята отметка обработанной категории: {node.name} [{node.id}]"
        )

    def toggle_category(self, event=None):
        item = self.category_tree.focus()
        if not item or item not in self.folder_by_item:
            return

        data = self.folder_by_item[item]
        node = data["node"]

        # При попытке повторно выбрать уже обработанную категорию
        # программа явно предупреждает пользователя.
        if not data["selected"] and node.id in self.processed_category_ids:
            if not messagebox.askyesno(
                "Категория уже обработана",
                f"Категория уже была успешно обработана:\n\n{node.name}\n\n"
                "Выбрать её повторно?"
            ):
                return

        data["selected"] = not data["selected"]
        vals = list(self.category_tree.item(item, "values"))
        vals[0] = "☑" if data["selected"] else "☐"
        vals[1] = "✓" if node.id in self.processed_category_ids else ""
        self.category_tree.item(item, values=vals)
        self.update_category_summary()

    def expand_all(self, value):
        def walk(parent=""):
            for item in self.category_tree.get_children(parent):
                self.category_tree.item(item, open=value)
                walk(item)
        walk()

    def selected_nodes_with_descendants(self):
        selected = [d["node"] for d in self.folder_by_item.values() if d["selected"]]
        result = {}

        def add(node):
            result[node.href] = node
            for ch in node.children:
                add(ch)

        for node in selected:
            add(node)
        return list(result.values())

    def update_category_summary(self):
        selected = [d["node"] for d in self.folder_by_item.values() if d["selected"]]
        covered = self.selected_nodes_with_descendants() if selected else []

        known = bool(covered) and all(n.direct_products is not None for n in covered)
        products = sum(int(n.direct_products or 0) for n in covered) if known else None

        processed_count = sum(
            1 for d in self.folder_by_item.values()
            if d["node"].id in self.processed_category_ids
        )

        if not selected:
            text = f"Ничего не выбрано • уже обработано: {processed_count}"
        elif products is None:
            text = (
                f"Выбрано категорий: {len(selected)} • товаров: считаю… "
                f"• уже обработано: {processed_count}"
            )
        else:
            text = (
                f"Выбрано категорий: {len(selected)} • товаров: {products} "
                f"• уже обработано: {processed_count}"
            )
        self.category_summary.config(text=text)

    # =====================================================
    # 2. PROCESS
    # =====================================================

    def _load_photo_scan_cache(self):
        try:
            if self.photo_scan_cache_file.exists():
                data = json.loads(
                    self.photo_scan_cache_file.read_text(
                        encoding="utf-8"
                    )
                )
                if isinstance(data, dict):
                    images = data.get("images")
                    if isinstance(images, dict):
                        return {
                            "format_version": 1,
                            "images": images,
                        }
        except Exception as e:
            try:
                self.log_action(
                    f"Кэш фото: не удалось загрузить: {e}",
                    "WARN"
                )
            except Exception:
                pass

        return {
            "format_version": 1,
            "images": {},
        }

    def _save_photo_scan_cache(self):
        try:
            with self.photo_scan_cache_lock:
                tmp = self.photo_scan_cache_file.with_suffix(".tmp")
                tmp.write_text(
                    json.dumps(
                        self.photo_scan_cache,
                        ensure_ascii=False,
                        indent=2
                    ),
                    encoding="utf-8"
                )
                tmp.replace(self.photo_scan_cache_file)

            try:
                self.photo_cache_status_var.set(
                    f"Кэш проверки: "
                    f"{len(self.photo_scan_cache.get('images', {}))} фото"
                )
            except Exception:
                pass

        except Exception as e:
            self.log_action(
                f"Кэш фото: ошибка сохранения: {e}",
                "WARN"
            )

    @staticmethod
    def _photo_cache_identity(product_id, image_info, image_index):
        meta = (
            image_info.get("meta")
            if isinstance(image_info, dict)
            else {}
        ) or {}

        image_id = (
            image_info.get("id")
            or meta.get("id")
            or meta.get("href")
            or image_info.get("filename")
            or f"image_{image_index}"
        )

        return f"{product_id}|{image_id}"

    @staticmethod
    def _photo_cache_fingerprint(
        image_info,
        box_ratio,
        do_center,
        threshold
    ):
        meta = (
            image_info.get("meta")
            if isinstance(image_info, dict)
            else {}
        ) or {}

        # Не используем downloadHref: ссылка может содержать временные данные.
        payload = {
            "scanner": "logo-v1.3.3",
            "id": image_info.get("id"),
            "filename": image_info.get("filename"),
            "size": image_info.get("size"),
            "updated": image_info.get("updated"),
            "created": image_info.get("created"),
            "meta_href": meta.get("href"),
            "mediaType": image_info.get("mediaType"),
            "box_ratio": round(float(box_ratio), 4),
            "do_center": bool(do_center),
            "threshold": int(threshold),
        }

        raw = json.dumps(
            payload,
            sort_keys=True,
            ensure_ascii=False,
            default=str
        ).encode("utf-8")

        return hashlib.sha256(raw).hexdigest()

    def _get_photo_cache_entry(self, key):
        with self.photo_scan_cache_lock:
            entry = self.photo_scan_cache.get("images", {}).get(key)
            return dict(entry) if isinstance(entry, dict) else None

    def _set_photo_cache_entry(
        self,
        key,
        fingerprint,
        result,
        product_name,
        filename
    ):
        with self.photo_scan_cache_lock:
            self.photo_scan_cache.setdefault("images", {})[key] = {
                "fingerprint": fingerprint,
                "result": result,
                "product_name": product_name,
                "filename": filename,
                "checked_at": datetime.now().isoformat(
                    timespec="seconds"
                ),
            }

    def clear_photo_scan_cache(self):
        count = len(
            self.photo_scan_cache.get("images", {})
        )

        if not count:
            messagebox.showinfo(
                "Кэш проверки",
                "Кэш уже пуст."
            )
            return

        if not messagebox.askyesno(
            "Очистить кэш проверки?",
            f"В кэше сохранено результатов: {count}.\n\n"
            "После очистки при следующем прогоне программа "
            "снова скачает и проверит фотографии.\n\n"
            "Продолжить?"
        ):
            return

        with self.photo_scan_cache_lock:
            self.photo_scan_cache = {
                "format_version": 1,
                "images": {},
            }

        self._save_photo_scan_cache()
        self.log_action(
            f"Кэш проверки фотографий очищен: {count} записей"
        )

        messagebox.showinfo(
            "Кэш проверки",
            "Кэш очищен."
        )

    def _build_process(self):
        summary = ttk.LabelFrame(self.process_tab, text="Что будет обработано", padding=12)
        summary.pack(fill=X)

        ttk.Label(
            summary,
            text="Используются категории, выбранные на шаге 1."
        ).pack(anchor="w")

        ttk.Label(
            summary,
            text="Умный повторный прогон: неизменившиеся чистые фото берутся из кэша и не скачиваются; в список попадают только товары, которым нужны изменения."
        ).pack(anchor="w", pady=(4, 0))

        settings = ttk.LabelFrame(self.process_tab, text="Настройки", padding=12)
        settings.pack(fill=X, pady=(12, 0))

        ttk.Label(settings, text="Поиск старого логотипа MIX PC").grid(row=0, column=0, sticky="w")
        ttk.Spinbox(
            settings, from_=0.10, to=0.35, increment=0.01,
            textvariable=self.box_ratio, width=8
        ).grid(row=0, column=1, padx=(8, 24), sticky="w")

        ttk.Checkbutton(
            settings, text="Центрировать только если смещён", variable=self.center_var
        ).grid(row=0, column=2, sticky="w")

        ttk.Label(settings, text="Чувствительность").grid(row=0, column=3, padx=(24, 0), sticky="w")
        ttk.Spinbox(
            settings, from_=5, to=60, textvariable=self.threshold_var, width=8
        ).grid(row=0, column=4, padx=(8, 0), sticky="w")

        ttk.Label(settings, text="Товаров для предпросмотра").grid(row=1, column=0, sticky="w", pady=(10, 0))
        ttk.Spinbox(
            settings, from_=1, to=30, textvariable=self.preview_count, width=8
        ).grid(row=1, column=1, padx=(8, 24), pady=(10, 0), sticky="w")

        ttk.Button(
            settings, text="Предпросмотр До / После",
            command=self.start_preview
        ).grid(row=1, column=2, sticky="w", pady=(10, 0))

        ttk.Label(
            settings,
            textvariable=self.photo_cache_status_var,
            foreground="#666666"
        ).grid(
            row=2,
            column=0,
            columnspan=3,
            sticky="w",
            pady=(10, 0)
        )

        ttk.Button(
            settings,
            text="Сбросить кэш проверки",
            command=self.clear_photo_scan_cache
        ).grid(
            row=2,
            column=3,
            columnspan=2,
            sticky="e",
            pady=(10, 0)
        )

        backup = ttk.LabelFrame(self.process_tab, text="Резервная копия", padding=12)
        backup.pack(fill=X, pady=(12, 0))

        ttk.Entry(backup, textvariable=self.backup_root_var).grid(row=0, column=0, sticky="ew", padx=(0, 8))
        ttk.Button(backup, text="Выбрать папку", command=self.pick_backup_root).grid(row=0, column=1)
        backup.columnconfigure(0, weight=1)

        ttk.Label(
            backup,
            text="Оригиналы сохраняются ДО загрузки. Позже их можно восстановить на шаге 3."
        ).grid(row=1, column=0, columnspan=2, sticky="w", pady=(6, 0))

        actions = ttk.Frame(self.process_tab)
        actions.pack(fill=X, pady=(12, 0))

        self.prepare_btn = ttk.Button(
            actions, text="1. Подготовить пакет", style="Primary.TButton",
            command=self.start_prepare
        )
        self.prepare_btn.pack(side=LEFT)

        self.upload_btn = ttk.Button(
            actions, text="2. Загрузить в МойСклад", style="Primary.TButton",
            state="disabled", command=self.confirm_upload
        )
        self.upload_btn.pack(side=LEFT, padx=(8, 0))

        ttk.Label(
            actions,
            textvariable=self.process_elapsed_var,
            style="H2.TLabel"
        ).pack(side=RIGHT, padx=(8, 0))

        self.process_progress = ttk.Progressbar(self.process_tab, mode="indeterminate")
        self.process_progress.pack(fill=X, pady=(10, 0))

        box = ttk.LabelFrame(self.process_tab, text="Подготовленные товары", padding=10)
        box.pack(fill=BOTH, expand=True, pady=(10, 0))

        cols = ("selected", "category", "images", "status")
        self.prepared_tree = ttk.Treeview(box, columns=cols, show="tree headings")
        self.prepared_tree.heading("#0", text="Товар")
        self.prepared_tree.heading("selected", text="Загрузить")
        self.prepared_tree.heading("category", text="Категория")
        self.prepared_tree.heading("images", text="Фото")
        self.prepared_tree.heading("status", text="Статус")

        self.prepared_tree.column("#0", width=430)
        self.prepared_tree.column("selected", width=90, anchor="center")
        self.prepared_tree.column("category", width=190)
        self.prepared_tree.column("images", width=70, anchor="center")
        self.prepared_tree.column("status", width=180)
        self.prepared_scroll = ttk.Scrollbar(
            box,
            orient=VERTICAL,
            command=self.prepared_tree.yview
        )
        self.prepared_tree.configure(yscrollcommand=self.prepared_scroll.set)
        self.prepared_scroll.pack(side=RIGHT, fill=Y)
        self.prepared_tree.pack(side=LEFT, fill=BOTH, expand=True)
        self.prepared_tree.bind("<Double-1>", self.toggle_prepared)

        bottom = ttk.Frame(self.process_tab)
        bottom.pack(fill=X, pady=(8, 0))
        ttk.Button(bottom, text="Выбрать все", command=lambda: self.set_all_prepared(True)).pack(side=LEFT)
        ttk.Button(bottom, text="Снять все", command=lambda: self.set_all_prepared(False)).pack(side=LEFT, padx=(6, 0))

        self.prepared_summary = ttk.Label(bottom, text="Пакет ещё не подготовлен", style="H2.TLabel")
        self.prepared_summary.pack(side=RIGHT)

        self.process_status = StringVar(value="Сначала выберите категории на шаге 1.")
        ttk.Label(self.process_tab, textvariable=self.process_status).pack(anchor="w", pady=(6, 0))

    def pick_backup_root(self):
        p = filedialog.askdirectory(title="Папка для резервных копий")
        if p:
            self.backup_root_var.set(p)
            self._save_persistent_settings()

    def start_preview(self):
        if not self.client:
            messagebox.showinfo("MIX PC", "Сначала подключитесь к МойСклад.")
            return

        nodes = self.selected_nodes_with_descendants()
        if not nodes:
            messagebox.showinfo("MIX PC", "Выберите категории на шаге 1.")
            return

        count = max(1, min(30, int(self.preview_count.get())))
        self.begin_cancellable_operation("предпросмотр фотографий", self.process_status)
        self._start_process_timer()
        self.process_progress.start(10)
        self.process_status.set(f"Ищу {count} товаров с фотографиями…")

        threading.Thread(
            target=self._preview_worker,
            args=(nodes, count, float(self.box_ratio.get()), bool(self.center_var.get()), int(self.threshold_var.get())),
            daemon=True
        ).start()

    def _preview_worker(self, nodes, count, box_ratio, do_center, threshold):
        items = []
        product_count = 0
        try:
            for node in nodes:
                if product_count >= count:
                    break

                for product in self.client.products_in_folder(node.href):
                    if product_count >= count:
                        break

                    rows = ((product.get("images") or {}).get("rows") or [])
                    if not rows:
                        continue

                    product_items = []
                    for image_no, image_info in enumerate(rows, 1):
                        href = (image_info.get("meta") or {}).get("downloadHref")
                        if not href:
                            continue

                        raw = self.client.get_bytes(href)
                        with Image.open(io.BytesIO(raw)) as original:
                            original.load()
                            original = original.convert("RGBA" if original.mode == "RGBA" else "RGB")
                            processed = process_pil(original, box_ratio, do_center, threshold)

                            product_items.append(
                                PreviewItem(
                                    product_name=product.get("name", "(без имени)"),
                                    folder_name=node.name,
                                    filename=image_info.get("filename", "image"),
                                    image_no=image_no,
                                    image_total=len(rows),
                                    original=original.copy(),
                                    processed=processed.copy(),
                                )
                            )

                    if product_items:
                        product_count += 1
                        items.extend(product_items)
                        self.root.after(
                            0, self.process_status.set,
                            f"Предпросмотр: {product_count}/{count} товаров • {len(items)} фото"
                        )

            self.root.after(0, self._preview_done, items)
        except Exception as e:
            self.root.after(0, self._preview_error, str(e))

    def _preview_done(self, items):
        self.finish_cancellable_operation()
        elapsed = self._finish_process_timer()
        self.process_progress.stop()
        if not items:
            self.process_status.set("Фото не найдены.")
            messagebox.showinfo("MIX PC", "В выбранных категориях не найдено фотографий.")
            return

        self.process_status.set(
            f"Предпросмотр готов • {len(items)} фото • время {self.format_duration(elapsed)}"
        )
        PreviewWindow(self.root, items)

    def _preview_error(self, msg):
        self.finish_cancellable_operation()
        self._finish_process_timer()
        self.process_progress.stop()
        self.process_status.set("Ошибка предпросмотра.")
        messagebox.showerror("Предпросмотр", msg)

    @staticmethod
    def safe_name(name: str) -> str:
        bad = '<>:"/\\|?*'
        return ("".join("_" if c in bad else c for c in name).strip()[:120] or "product")

    def start_prepare(self):
        if not self.client:
            messagebox.showinfo("MIX PC", "Сначала подключитесь к МойСклад.")
            return

        nodes = self.selected_nodes_with_descendants()
        if not nodes:
            messagebox.showinfo("MIX PC", "Выберите категории на шаге 1.")
            return

        # Запоминаем все категории, реально покрываемые текущим запуском.
        # Отметка «обработано» будет поставлена только после успешной загрузки без ошибок.
        self.current_process_category_ids = {
            node.id for node in nodes if node.id
        }

        root = self.backup_root_var.get().strip()
        if not root:
            messagebox.showinfo("MIX PC", "Выберите папку для резервной копии.")
            return

        session = Path(root) / f"MIXPC_backup_{datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}"
        session.mkdir(parents=True, exist_ok=True)
        self.current_session_dir = session

        self.prepared_products = []
        self.prepared_by_item.clear()
        self.prepared_tree.delete(*self.prepared_tree.get_children())
        self.upload_btn.config(state="disabled")
        self.prepare_btn.config(state="disabled")

        self.begin_cancellable_operation("подготовка фотографий", self.process_status)
        self._start_process_timer()
        self.process_progress.start(10)
        self.process_status.set("Скачиваю оригиналы и готовлю обработанные версии…")

        threading.Thread(
            target=self._prepare_worker,
            args=(nodes, session, float(self.box_ratio.get()), bool(self.center_var.get()), int(self.threshold_var.get())),
            daemon=True
        ).start()

    def _prepare_worker(self, nodes, session, box_ratio, do_center, threshold):
        prepared = []
        seen = set()

        checked_images = 0
        downloaded_images = 0
        backup_downloads = 0
        cache_hits = 0
        changed_images = 0
        skipped_no_logo = 0
        centered_images = 0
        already_centered = 0
        cache_dirty = False

        try:
            for node in nodes:
                if self.operation_should_stop():
                    break

                for product in self.client.products_in_folder(node.href):
                    if self.operation_should_stop():
                        break

                    pid = product.get("id", "")
                    if not pid or pid in seen:
                        continue

                    seen.add(pid)

                    rows = (
                        (product.get("images") or {}).get("rows")
                        or []
                    )
                    if not rows:
                        continue

                    name = product.get(
                        "name",
                        "(без имени)"
                    )

                    # Сначала только определяем, нужен ли товару ремонт.
                    # Фото с подтверждённым статусом CLEAN и неизменившейся
                    # метаинформацией вообще не скачиваются.
                    analyzed = []
                    product_has_changes = False

                    for idx, image_info in enumerate(rows, 1):
                        if self.operation_should_stop():
                            break

                        meta = (
                            image_info.get("meta")
                            if isinstance(image_info, dict)
                            else {}
                        ) or {}

                        href = meta.get("downloadHref")
                        if not href:
                            continue

                        checked_images += 1

                        filename = self.safe_name(
                            image_info.get("filename")
                            or f"image_{idx}.png"
                        )
                        disk_name = f"{idx:02d}_{filename}"

                        cache_key = self._photo_cache_identity(
                            pid,
                            image_info,
                            idx
                        )
                        fingerprint = self._photo_cache_fingerprint(
                            image_info,
                            box_ratio,
                            do_center,
                            threshold
                        )
                        cached = self._get_photo_cache_entry(
                            cache_key
                        )

                        # Самый быстрый путь: фото уже проверялось,
                        # метаданные не изменились, результат был CLEAN.
                        if (
                            cached
                            and cached.get("fingerprint") == fingerprint
                            and cached.get("result") == "clean"
                        ):
                            cache_hits += 1
                            skipped_no_logo += 1

                            analyzed.append({
                                "idx": idx,
                                "image_info": image_info,
                                "filename": filename,
                                "disk_name": disk_name,
                                "href": href,
                                "raw": None,
                                "processed_bytes": b"",
                                "info": {
                                    "changed": False,
                                    "logo_found": False,
                                    "centered": False,
                                    "shift_x": 0,
                                    "shift_y": 0,
                                    "erase_box": None,
                                },
                                "cached_clean": True,
                            })

                            if (
                                checked_images == 1
                                or checked_images % 25 == 0
                            ):
                                self.root.after(
                                    0,
                                    self.process_status.set,
                                    (
                                        f"Проверено: {checked_images} • "
                                        f"из кэша: {cache_hits} • "
                                        f"скачано: {downloaded_images} • "
                                        f"требуют обработки: {changed_images}"
                                    )
                                )
                                self.root.after(
                                    0,
                                    self.update_unknown_progress,
                                    checked_images,
                                    "фото"
                                )
                            continue

                        # Новое/изменённое фото или раньше было проблемным:
                        # скачиваем и анализируем заново.
                        raw = self.client.get_bytes(href)
                        downloaded_images += 1

                        with Image.open(io.BytesIO(raw)) as original:
                            original.load()
                            original = original.convert(
                                "RGBA"
                                if original.mode == "RGBA"
                                else "RGB"
                            )

                            processed, info = process_pil_with_info(
                                original,
                                box_ratio,
                                do_center,
                                threshold
                            )

                            if info["changed"]:
                                processed_bytes = encode_image(
                                    processed,
                                    filename
                                )
                                product_has_changes = True
                                changed_images += 1

                                if info["centered"]:
                                    centered_images += 1
                                else:
                                    already_centered += 1

                                cache_result = "needs_change"
                            else:
                                processed_bytes = b""
                                skipped_no_logo += 1
                                cache_result = "clean"

                        self._set_photo_cache_entry(
                            cache_key,
                            fingerprint,
                            cache_result,
                            name,
                            filename
                        )
                        cache_dirty = True

                        analyzed.append({
                            "idx": idx,
                            "image_info": image_info,
                            "filename": filename,
                            "disk_name": disk_name,
                            "href": href,
                            "raw": raw,
                            "processed_bytes": processed_bytes,
                            "info": info,
                            "cached_clean": False,
                        })

                        if (
                            checked_images == 1
                            or checked_images % 5 == 0
                        ):
                            self.root.after(
                                0,
                                self.process_status.set,
                                (
                                    f"Проверено: {checked_images} • "
                                    f"из кэша: {cache_hits} • "
                                    f"скачано: {downloaded_images} • "
                                    f"требуют обработки: {changed_images}"
                                )
                            )
                            self.root.after(
                                0,
                                self.update_unknown_progress,
                                checked_images,
                                "фото"
                            )

                    # Если весь товар чистый, он НЕ попадает в рабочий список.
                    # И главное — его clean-фото из кэша не скачивались.
                    if not product_has_changes:
                        continue

                    product_dir = (
                        session
                        / self.safe_name(name)
                        / pid
                    )
                    orig_dir = product_dir / "original"
                    proc_dir = product_dir / "processed"
                    orig_dir.mkdir(
                        parents=True,
                        exist_ok=True
                    )
                    proc_dir.mkdir(
                        parents=True,
                        exist_ok=True
                    )

                    pimages = []
                    manifest_images = []

                    for item in analyzed:
                        idx = item["idx"]
                        image_info = item["image_info"]
                        filename = item["filename"]
                        disk_name = item["disk_name"]
                        raw = item["raw"]
                        processed_bytes = item["processed_bytes"]
                        info = item["info"]

                        # Только если у товара реально есть проблемное фото,
                        # догружаем ранее пропущенные clean-фото для полного backup.
                        if raw is None:
                            raw = self.client.get_bytes(
                                item["href"]
                            )
                            backup_downloads += 1

                        (orig_dir / disk_name).write_bytes(
                            raw
                        )

                        if info["changed"]:
                            (proc_dir / disk_name).write_bytes(
                                processed_bytes
                            )

                        pimages.append(
                            PreparedImage(
                                filename=filename,
                                original_bytes=raw,
                                processed_bytes=processed_bytes,
                                changed=bool(info["changed"]),
                                meta=image_info.get("meta"),
                                centered=bool(info["centered"]),
                                shift_x=int(info["shift_x"]),
                                shift_y=int(info["shift_y"]),
                            )
                        )

                        manifest_images.append({
                            "order": idx,
                            "filename": filename,
                            "backup_filename": disk_name,
                            "original_size": len(raw),
                            "processed_size": (
                                len(processed_bytes)
                                if info["changed"]
                                else None
                            ),
                            "changed": bool(info["changed"]),
                            "logo_found": bool(info["logo_found"]),
                            "centered": bool(info["centered"]),
                            "shift_x": int(info["shift_x"]),
                            "shift_y": int(info["shift_y"]),
                            "from_cache": bool(
                                item.get("cached_clean")
                            ),
                        })

                    manifest = {
                        "product_id": pid,
                        "product_name": name,
                        "category": node.name,
                        "images": manifest_images,
                    }
                    (
                        product_dir
                        / "manifest.json"
                    ).write_text(
                        json.dumps(
                            manifest,
                            ensure_ascii=False,
                            indent=2
                        ),
                        encoding="utf-8"
                    )

                    prepared.append(
                        PreparedProduct(
                            pid,
                            name,
                            node.name,
                            pimages
                        )
                    )

            global_manifest = {
                "format_version": 4,
                "created": datetime.now().isoformat(
                    timespec="seconds"
                ),
                "statistics": {
                    "checked_images": checked_images,
                    "cache_hits": cache_hits,
                    "downloaded_images": downloaded_images,
                    "backup_downloads": backup_downloads,
                    "changed_images": changed_images,
                    "skipped_no_logo": skipped_no_logo,
                    "centered_images": centered_images,
                    "already_centered": already_centered,
                },
                "products": [
                    {
                        "product_id": p.product_id,
                        "product_name": p.product_name,
                        "category": p.folder_name,
                    }
                    for p in prepared
                ]
            }

            (
                session
                / "manifest_all.json"
            ).write_text(
                json.dumps(
                    global_manifest,
                    ensure_ascii=False,
                    indent=2
                ),
                encoding="utf-8"
            )

            if cache_dirty:
                self._save_photo_scan_cache()

            self.root.after(
                0,
                self._prepare_done,
                prepared,
                changed_images,
                str(session),
                checked_images,
                skipped_no_logo,
                centered_images,
                already_centered,
                cache_hits,
                downloaded_images,
                backup_downloads,
            )

        except Exception as e:
            # Даже при ошибке сохраняем результаты уже успешно
            # проверенных фотографий.
            if cache_dirty:
                try:
                    self._save_photo_scan_cache()
                except Exception:
                    pass

            self.root.after(
                0,
                self._prepare_error,
                str(e)
            )


    def _prepare_done(
        self,
        prepared,
        changed_images,
        session,
        checked_images,
        skipped_no_logo,
        centered_images,
        already_centered,
        cache_hits,
        downloaded_images,
        backup_downloads,
    ):
        self.finish_cancellable_operation()
        elapsed = self._finish_process_timer()
        self.process_progress.stop()
        self.prepare_btn.config(state="normal")
        self.prepared_products = prepared

        for p in prepared:
            changed_count = sum(
                1 for img in p.images
                if img.changed
            )
            item = self.prepared_tree.insert(
                "",
                "end",
                text=p.product_name,
                values=(
                    "☑",
                    p.folder_name,
                    changed_count,
                    p.status,
                )
            )
            self.prepared_by_item[item] = p

        self.process_status.set(
            f"Готово • проверено {checked_images} • "
            f"из кэша {cache_hits} • скачано {downloaded_images} • "
            f"требуют обработки {len(prepared)} • "
            f"время {self.format_duration(elapsed)}"
        )

        self.update_prepared_summary()
        self.upload_btn.config(
            state="normal"
            if prepared
            else "disabled"
        )

        self.log_action(
            f"Обработка фото: проверено {checked_images}; "
            f"из кэша без скачивания {cache_hits}; "
            f"скачано для анализа {downloaded_images}; "
            f"догружено для backup {backup_downloads}; "
            f"изменяемых фото {changed_images}; "
            f"чистых/без логотипа {skipped_no_logo}; "
            f"центрировано {centered_images}; "
            f"товаров к загрузке {len(prepared)}; "
            f"время {self.format_duration(elapsed)}"
        )

        if prepared:
            result_text = (
                f"Товаров, требующих изменений: {len(prepared)}"
            )
        else:
            result_text = (
                "Все проверенные товары в норме.\n"
                "Список обработки оставлен пустым."
            )

        messagebox.showinfo(
            "Сканирование завершено",
            f"Всего проверено фото: {checked_images}\n"
            f"Пропущено из кэша без скачивания: {cache_hits}\n"
            f"Скачано для анализа: {downloaded_images}\n"
            f"Доп. скачано только для backup: {backup_downloads}\n\n"
            f"Фото, требующие обработки: {changed_images}\n"
            f"Чистых / без логотипа: {skipped_no_logo}\n"
            f"Потребовалось центрирование: {centered_images}\n\n"
            f"{result_text}\n\n"
            f"Время: {self.format_duration(elapsed)}"
        )


    def _prepare_error(self, msg):
        self.finish_cancellable_operation()
        self._finish_process_timer()
        self.process_progress.stop()
        self.prepare_btn.config(state="normal")
        self.process_status.set("Ошибка подготовки.")
        messagebox.showerror("Подготовка", msg)

    def toggle_prepared(self, event=None):
        item = self.prepared_tree.focus()
        if not item or item not in self.prepared_by_item:
            return
        p = self.prepared_by_item[item]
        p.selected = not p.selected
        vals = list(self.prepared_tree.item(item, "values"))
        vals[0] = "☑" if p.selected else "☐"
        self.prepared_tree.item(item, values=vals)
        self.update_prepared_summary()

    def set_all_prepared(self, value):
        for item, p in self.prepared_by_item.items():
            p.selected = value
            vals = list(self.prepared_tree.item(item, "values"))
            vals[0] = "☑" if value else "☐"
            self.prepared_tree.item(item, values=vals)
        self.update_prepared_summary()

    def update_prepared_summary(self):
        selected = [p for p in self.prepared_products if p.selected]
        images = sum(
            sum(1 for img in p.images if img.changed)
            for p in selected
        )
        self.prepared_summary.config(
            text=f"Выбрано: {len(selected)} товаров • {images} изменяемых фото"
        )

    def _save_upload_error_report(self):
        if not self.upload_errors:
            return None
        try:
            if getattr(self, "current_session_dir", None):
                report = Path(self.current_session_dir) / "upload_errors.txt"
            else:
                report = self.log_dir / f"upload_errors_{datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}.txt"

            lines = [
                "MIX PC Photo Cleaner — ошибки загрузки",
                f"Дата: {datetime.now().isoformat(timespec='seconds')}",
                ""
            ]
            for err in self.upload_errors:
                lines += [
                    f"Товар: {err['product_name']}",
                    f"ID: {err['product_id']}",
                    f"Ошибка: {err['error']}",
                    "-" * 80
                ]
            report.write_text("\n".join(lines), encoding="utf-8")
            return report
        except Exception as e:
            self.log_action(f"Не удалось сохранить отчёт ошибок: {e}", "ERROR")
            return None

    def _show_upload_error_summary(self):
        if not self.upload_errors:
            messagebox.showinfo("Ошибки загрузки", "Ошибок нет.")
            return

        preview = []
        for err in self.upload_errors[:10]:
            preview.append(f"• {err['product_name']}\n  {err['error']}")

        if len(self.upload_errors) > 10:
            preview.append(f"…и ещё {len(self.upload_errors) - 10} ошибок.")

        report = self._save_upload_error_report()
        tail = f"\n\nПолный отчёт:\n{report}" if report else ""
        messagebox.showerror("Ошибки загрузки", "\n\n".join(preview) + tail)

    def confirm_upload(self):
        selected = [p for p in self.prepared_products if p.selected]
        if not selected:
            messagebox.showinfo("MIX PC", "Не выбрано ни одного товара.")
            return

        images = sum(sum(1 for img in p.images if img.changed) for p in selected)
        if not messagebox.askyesno(
            "Подтверждение",
            f"Будут заменены изображения в МойСклад.\n\n"
            f"Товаров: {len(selected)}\nФото: {images}\n\n"
            "Оригиналы уже сохранены. Продолжить?"
        ):
            return

        if not messagebox.askyesno(
            "Последняя проверка",
            "Запустить запись в МойСклад?\n\n"
            "После операции при необходимости можно использовать вкладку «Восстановление»."
        ):
            return

        self.upload_errors = []
        self.upload_btn.config(state="disabled")
        self.prepare_btn.config(state="disabled")
        self.begin_cancellable_operation("загрузка фотографий", self.process_status)
        self._start_process_timer()
        self.process_progress.start(10)
        self.process_status.set("Загружаю изменения…")

        threading.Thread(target=self._upload_worker, args=(selected,), daemon=True).start()

    def _upload_worker(self, selected):
        ok = 0
        failed = 0

        self.root.after(
            0,
            self.set_operation_total,
            len(selected),
            "Загрузка фотографий"
        )

        for idx, p in enumerate(selected, 1):
            if self.operation_should_stop():
                break
            try:
                payload = []
                for img in p.images:
                    if img.changed:
                        payload.append({
                            "filename": img.filename,
                            "content": base64.b64encode(img.processed_bytes).decode("ascii")
                        })
                    elif img.meta:
                        payload.append({"meta": img.meta})
                    else:
                        payload.append({
                            "filename": img.filename,
                            "content": base64.b64encode(img.original_bytes).decode("ascii")
                        })

                self.client.replace_product_images(p.product_id, payload)
                p.status = "Загружено"
                ok += 1
                self.log_action(
                    f"Загрузка фото: успешно — {p.product_name}"
                )
                self.root.after(
                    0, self._set_prepared_status,
                    p.product_id, "Загружено"
                )

            except Exception as e:
                p.status = "Ошибка"
                failed += 1

                error_text = str(e).strip() or repr(e)
                short = error_text.replace("\n", " ")[:120]

                self.upload_errors.append({
                    "product_id": p.product_id,
                    "product_name": p.product_name,
                    "error": error_text,
                })

                self.log_action(
                    f"Загрузка фото: ОШИБКА — {p.product_name} "
                    f"[{p.product_id}] — {error_text}",
                    "ERROR"
                )

                self.root.after(
                    0, self._set_prepared_status,
                    p.product_id, f"⚠ {short}"
                )

            self.root.after(
                0, self.process_status.set,
                f"Загрузка {idx}/{len(selected)} • успешно {ok} • ошибок {failed}"
            )
            self.root.after(
                0,
                self.update_operation_progress,
                idx,
                len(selected),
                f"успешно {ok} • ошибок {failed}"
            )

        self.root.after(0, self._upload_done, ok, failed)

    def _set_prepared_status(self, pid, status):
        for item, p in self.prepared_by_item.items():
            if p.product_id == pid:
                vals = list(self.prepared_tree.item(item, "values"))
                vals[3] = status
                self.prepared_tree.item(item, values=vals)
                break

    def _upload_done(self, ok, failed):
        self.finish_cancellable_operation()
        elapsed = self._finish_process_timer()
        self.process_progress.stop()
        self.prepare_btn.config(state="normal")
        self.upload_btn.config(state="normal")

        report = self._save_upload_error_report() if failed else None

        self.process_status.set(
            f"Готово • успешно {ok} • ошибок {failed} • время {self.format_duration(elapsed)}"
        )

        self.log_action(
            f"Загрузка фото завершена — успешно {ok}, ошибок {failed}, "
            f"время {self.format_duration(elapsed)}"
            + (f", отчёт {report}" if report else "")
        )

        # Категории помечаем обработанными только если весь запуск завершился без ошибок.
        # Это защищает от ложной галочки при частично неуспешной загрузке.
        if failed == 0 and self.current_process_category_ids:
            self.processed_category_ids.update(self.current_process_category_ids)
            self._save_persistent_settings()
            self._refresh_processed_category_marks()

            names = [
                n.name for n in self.node_by_href.values()
                if n.id in self.current_process_category_ids
            ]
            self.log_action(
                "Категории автоматически отмечены обработанными: "
                + ", ".join(names[:30])
                + (" …" if len(names) > 30 else "")
            )

        if failed:
            show = messagebox.askyesno(
                "Готово с ошибками",
                f"Успешно: {ok}\n"
                f"Ошибок: {failed}\n"
                f"Время: {self.format_duration(elapsed)}\n\n"
                + (f"Отчёт:\n{report}\n\n" if report else "")
                + "Показать подробности ошибок?"
            )
            if show:
                self._show_upload_error_summary()
        else:
            messagebox.showinfo(
                "Готово",
                f"Успешно: {ok}\nОшибок: {failed}\n"
                f"Время: {self.format_duration(elapsed)}"
            )

    # =====================================================
    # 3. RESTORE
    # =====================================================

    def _build_restore(self):
        info = ttk.LabelFrame(self.restore_tab, text="Восстановить оригинальные фотографии", padding=12)
        info.pack(fill=X)

        ttk.Label(
            info,
            text="Выберите папку резервной копии вида MIXPC_backup_YYYY-MM-DD_HH-MM-SS."
        ).pack(anchor="w")

        row = ttk.Frame(info)
        row.pack(fill=X, pady=(10, 0))

        ttk.Entry(row, textvariable=self.restore_session_var).pack(side=LEFT, fill=X, expand=True, padx=(0, 8))
        ttk.Button(row, text="Выбрать копию", command=self.pick_restore_session).pack(side=LEFT)
        ttk.Button(row, text="Загрузить список", style="Primary.TButton", command=self.load_restore_session).pack(side=LEFT, padx=(8, 0))

        self.restore_session_info = StringVar(value="Резервная копия не выбрана.")
        ttk.Label(info, textvariable=self.restore_session_info, style="H2.TLabel").pack(anchor="w", pady=(8, 0))

        box = ttk.LabelFrame(self.restore_tab, text="Товары для восстановления", padding=10)
        box.pack(fill=BOTH, expand=True, pady=(12, 0))

        cols = ("selected", "category", "images", "status")
        self.restore_tree = ttk.Treeview(box, columns=cols, show="tree headings")
        self.restore_tree.heading("#0", text="Товар")
        self.restore_tree.heading("selected", text="Восстановить")
        self.restore_tree.heading("category", text="Категория")
        self.restore_tree.heading("images", text="Фото")
        self.restore_tree.heading("status", text="Статус")

        self.restore_tree.column("#0", width=430)
        self.restore_tree.column("selected", width=110, anchor="center")
        self.restore_tree.column("category", width=190)
        self.restore_tree.column("images", width=70, anchor="center")
        self.restore_tree.column("status", width=190)
        self.restore_scroll = ttk.Scrollbar(
            box,
            orient=VERTICAL,
            command=self.restore_tree.yview
        )
        self.restore_tree.configure(yscrollcommand=self.restore_scroll.set)
        self.restore_scroll.pack(side=RIGHT, fill=Y)
        self.restore_tree.pack(side=LEFT, fill=BOTH, expand=True)
        self.restore_tree.bind("<Double-1>", self.toggle_restore)

        controls = ttk.Frame(self.restore_tab)
        controls.pack(fill=X, pady=(10, 0))
        ttk.Button(controls, text="Выбрать все", command=lambda: self.set_all_restore(True)).pack(side=LEFT)
        ttk.Button(controls, text="Снять все", command=lambda: self.set_all_restore(False)).pack(side=LEFT, padx=(6, 0))

        self.restore_summary = ttk.Label(controls, text="Ничего не загружено", style="H2.TLabel")
        self.restore_summary.pack(side=LEFT, padx=18)

        self.restore_btn = ttk.Button(
            controls, text="ВОССТАНОВИТЬ ОРИГИНАЛЫ",
            style="Danger.TButton", state="disabled",
            command=self.confirm_restore
        )
        self.restore_btn.pack(side=RIGHT)

        self.restore_progress = ttk.Progressbar(self.restore_tab, mode="indeterminate")
        self.restore_progress.pack(fill=X, pady=(10, 0))

        self.restore_status = StringVar(value="Восстановление использует только сохранённые оригиналы.")
        ttk.Label(self.restore_tab, textvariable=self.restore_status).pack(anchor="w", pady=(6, 0))

    def pick_restore_session(self):
        p = filedialog.askdirectory(title="Выберите папку MIXPC_backup_...")
        if p:
            self.restore_session_var.set(p)

    def load_restore_session(self):
        session = Path(self.restore_session_var.get().strip())
        if not session.exists():
            messagebox.showinfo("MIX PC", "Выберите существующую папку резервной копии.")
            return

        manifest_all = session / "manifest_all.json"
        manifest_variants = session / "manifest_variants.json"
        if not manifest_all.exists() and not manifest_variants.exists():
            messagebox.showerror(
                "Не похоже на резервную копию",
                "В выбранной папке нет manifest_all.json или manifest_variants.json."
            )
            return

        self.restore_products = []
        self.restore_by_item.clear()
        self.restore_tree.delete(*self.restore_tree.get_children())

        try:
            products = []
            manifest_paths = list(session.rglob("manifest.json")) + list(session.rglob("manifest_variant.json"))
            for manifest_path in manifest_paths:
                data = json.loads(manifest_path.read_text(encoding="utf-8"))
                product_dir = manifest_path.parent
                images = data.get("images") or []
                entity_type = data.get("entity_type", "product")

                normalized = []
                for idx, img in enumerate(images, 1):
                    filename = img.get("filename") or f"image_{idx}.png"
                    backup_filename = img.get("backup_filename") or f"{idx:02d}_{self.safe_name(filename)}"
                    normalized.append({
                        "order": img.get("order") or idx,
                        "filename": filename,
                        "backup_filename": backup_filename,
                    })

                if entity_type == "variant":
                    entity_id = data.get("variant_id", "")
                    entity_name = data.get("variant_name", "(модификация)")
                    category = f"{data.get('product_name', '')} • {data.get('color', '')}".strip(" •")
                else:
                    entity_id = data.get("product_id", "")
                    entity_name = data.get("product_name", "(без имени)")
                    category = data.get("category", "")

                rp = RestoreProduct(
                    product_id=entity_id,
                    product_name=entity_name,
                    category=category,
                    product_dir=product_dir,
                    images=normalized,
                    entity_type=entity_type,
                )
                products.append(rp)

            products.sort(key=lambda p: p.product_name.lower())
            self.restore_products = products

            total_images = 0
            for p in products:
                total_images += len(p.images)
                item = self.restore_tree.insert(
                    "", "end", text=p.product_name,
                    values=("☑", p.category, len(p.images), p.status)
                )
                self.restore_by_item[item] = p

            self.restore_session_info.set(
                f"{session.name} • {len(products)} товаров • {total_images} фото"
            )
            self.restore_status.set("Резервная копия загружена. Выберите, что восстановить.")
            self.restore_btn.config(state="normal" if products else "disabled")
            self.update_restore_summary()

        except Exception as e:
            messagebox.showerror("Ошибка резервной копии", str(e))

    def toggle_restore(self, event=None):
        item = self.restore_tree.focus()
        if not item or item not in self.restore_by_item:
            return

        p = self.restore_by_item[item]
        p.selected = not p.selected
        vals = list(self.restore_tree.item(item, "values"))
        vals[0] = "☑" if p.selected else "☐"
        self.restore_tree.item(item, values=vals)
        self.update_restore_summary()

    def set_all_restore(self, value):
        for item, p in self.restore_by_item.items():
            p.selected = value
            vals = list(self.restore_tree.item(item, "values"))
            vals[0] = "☑" if value else "☐"
            self.restore_tree.item(item, values=vals)
        self.update_restore_summary()

    def update_restore_summary(self):
        selected = [p for p in self.restore_products if p.selected]
        images = sum(len(p.images) for p in selected)
        self.restore_summary.config(text=f"Выбрано: {len(selected)} товаров • {images} фото")

    def confirm_restore(self):
        if not self.client:
            messagebox.showinfo(
                "MIX PC",
                "Для восстановления сначала подключитесь к МойСклад на шаге 1."
            )
            self.tabs.select(self.catalog_tab)
            return

        selected = [p for p in self.restore_products if p.selected]
        if not selected:
            messagebox.showinfo("MIX PC", "Не выбрано ни одного товара.")
            return

        images = sum(len(p.images) for p in selected)

        if not messagebox.askyesno(
            "Восстановление",
            f"В МойСклад будут загружены ОРИГИНАЛЬНЫЕ фотографии из резервной копии.\n\n"
            f"Товаров: {len(selected)}\nФото: {images}\n\n"
            "Текущие фотографии этих товаров будут заменены. Продолжить?"
        ):
            return

        if not messagebox.askyesno(
            "Подтвердите откат",
            "Выполнить восстановление оригинальных фотографий?"
        ):
            return

        self.restore_btn.config(state="disabled")
        self.restore_progress.start(10)
        self.restore_status.set("Восстанавливаю оригиналы…")

        threading.Thread(target=self._restore_worker, args=(selected,), daemon=True).start()

    def _restore_worker(self, selected):
        ok = 0
        failed = 0

        self.root.after(
            0,
            self.set_operation_total,
            len(selected),
            "Восстановление"
        )

        for idx, p in enumerate(selected, 1):
            if self.operation_should_stop():
                break
            try:
                payload = []
                orig_dir = p.product_dir / "original"

                for image in sorted(p.images, key=lambda x: x["order"]):
                    path = orig_dir / image["backup_filename"]
                    if not path.exists():
                        raise FileNotFoundError(f"Не найден файл: {path.name}")

                    raw = path.read_bytes()
                    payload.append({
                        "filename": image["filename"],
                        "content": base64.b64encode(raw).decode("ascii")
                    })

                if p.entity_type == "variant":
                    self.client.replace_variant_images(p.product_id, payload)
                else:
                    self.client.replace_product_images(p.product_id, payload)
                p.status = "Восстановлено"
                ok += 1
                self.root.after(0, self._set_restore_status, p.product_id, "Восстановлено")

            except Exception:
                p.status = "Ошибка"
                failed += 1
                self.root.after(0, self._set_restore_status, p.product_id, "Ошибка")

            self.root.after(
                0, self.restore_status.set,
                f"Восстановление {idx}/{len(selected)} • успешно {ok} • ошибок {failed}"
            )
            self.root.after(
                0,
                self.update_operation_progress,
                idx,
                len(selected),
                f"успешно {ok} • ошибок {failed}"
            )

        self.root.after(0, self._restore_done, ok, failed)

    def _set_restore_status(self, pid, status):
        for item, p in self.restore_by_item.items():
            if p.product_id == pid:
                vals = list(self.restore_tree.item(item, "values"))
                vals[3] = status
                self.restore_tree.item(item, values=vals)
                break

    def _restore_done(self, ok, failed):
        self.finish_cancellable_operation()
        self.restore_progress.stop()
        self.restore_btn.config(state="normal")
        self.restore_status.set(f"Готово • восстановлено {ok} • ошибок {failed}")
        messagebox.showinfo(
            "Восстановление завершено",
            f"Восстановлено товаров: {ok}\nОшибок: {failed}"
        )



    # =====================================================
    # 5. НАЗВАНИЯ Б/у
    # =====================================================

    def _build_rename_tab(self):
        intro = ttk.LabelFrame(self.rename_tab, text="Нормализация названий Б/у", padding=12)
        intro.pack(fill=X)

        ttk.Label(
            intro,
            text="Замена вариантов «Б.У.» и «Б.У» → «Б/у». Остальные части названия не меняются."
        ).pack(anchor="w")

        ttk.Label(
            intro,
            text="Выделяйте нужные товары как в Проводнике: клик — одна строка, Ctrl — несколько, Shift — диапазон."
        ).pack(anchor="w", pady=(4, 0))

        top = ttk.Frame(self.rename_tab)
        top.pack(fill=X, pady=(12, 0))

        ttk.Button(
            top, text="Найти товары с Б.У.", style="Primary.TButton",
            command=self.start_rename_scan
        ).pack(side=LEFT)

        self.rename_apply_btn = ttk.Button(
            top, text="ПРИМЕНИТЬ К ВЫДЕЛЕННЫМ", style="Primary.TButton",
            state="disabled", command=self.confirm_rename_apply
        )
        self.rename_apply_btn.pack(side=LEFT, padx=(8, 0))

        self.rename_progress = ttk.Progressbar(self.rename_tab, mode="indeterminate")
        self.rename_progress.pack(fill=X, pady=(10, 0))

        box = ttk.LabelFrame(
            self.rename_tab,
            text="Предпросмотр — изменятся только выделенные строки",
            padding=10
        )
        box.pack(fill=BOTH, expand=True, pady=(10, 0))

        cols = ("old", "new", "status")
        self.rename_tree = ttk.Treeview(
            box, columns=cols, show="headings", selectmode="extended"
        )
        self.rename_tree.heading("old", text="Было")
        self.rename_tree.heading("new", text="Станет")
        self.rename_tree.heading("status", text="Статус")
        self.rename_tree.column("old", width=470)
        self.rename_tree.column("new", width=470)
        self.rename_tree.column("status", width=140, anchor="center")
        self.rename_scroll = ttk.Scrollbar(
            box,
            orient=VERTICAL,
            command=self.rename_tree.yview
        )
        self.rename_tree.configure(yscrollcommand=self.rename_scroll.set)
        self.rename_scroll.pack(side=RIGHT, fill=Y)
        self.rename_tree.pack(side=LEFT, fill=BOTH, expand=True)

        self.rename_tree.bind("<<TreeviewSelect>>", self.update_rename_summary)
        self.rename_tree.bind("<Delete>", self.delete_rename_row)

        controls = ttk.Frame(self.rename_tab)
        controls.pack(fill=X, pady=(8, 0))

        ttk.Button(
            controls, text="Выделить все",
            command=self.select_all_rename_rows
        ).pack(side=LEFT)

        ttk.Button(
            controls, text="Снять выделение",
            command=self.clear_rename_selection
        ).pack(side=LEFT, padx=(6, 0))

        ttk.Button(
            controls, text="Убрать выделенные из списка",
            command=self.delete_rename_row
        ).pack(side=LEFT, padx=(6, 0))

        self.rename_summary = ttk.Label(
            controls, text="Выделено: 0 товаров", style="H2.TLabel"
        )
        self.rename_summary.pack(side=RIGHT)

        backup = ttk.LabelFrame(self.rename_tab, text="Резервная копия названий", padding=12)
        backup.pack(fill=X, pady=(12, 0))

        ttk.Entry(backup, textvariable=self.rename_backup_dir).grid(
            row=0, column=0, sticky="ew", padx=(0, 8)
        )
        ttk.Button(
            backup, text="Выбрать папку",
            command=self.pick_rename_backup_dir
        ).grid(row=0, column=1)
        backup.columnconfigure(0, weight=1)

        ttk.Label(
            backup,
            text="Перед изменением создаётся JSON только по выделенным товарам."
        ).grid(row=1, column=0, columnspan=2, sticky="w", pady=(6, 0))

        self.rename_status = StringVar(
            value="Нажмите «Найти товары с Б.У.». После поиска ничего не выделяется автоматически."
        )
        ttk.Label(self.rename_tab, textvariable=self.rename_status).pack(
            anchor="w", pady=(6, 0)
        )

    def pick_rename_backup_dir(self):
        p = filedialog.askdirectory(title="Папка для резервной копии названий")
        if p:
            self.rename_backup_dir.set(p)
            self._save_persistent_settings()

    def start_rename_scan(self):
        if not self.client:
            messagebox.showinfo("MIX PC", "Сначала подключитесь к МойСклад.")
            return

        self.begin_cancellable_operation("поиск Б/у", self.rename_status)
        self.rename_progress.start(10)
        self.rename_status.set("Ищу товары с «Б.У.» или «Б.У»…")
        self.rename_items = []
        self.rename_by_item.clear()
        self.rename_tree.delete(*self.rename_tree.get_children())
        self.rename_apply_btn.config(state="disabled")
        self.log_action("Названия Б/у: старт поиска Б.У. и Б.У")

        threading.Thread(target=self._rename_scan_worker, daemon=True).start()

    def _rename_scan_worker(self):
        try:
            products = self.client.all_products()
            items = []

            self.root.after(
                0,
                self.set_operation_total,
                len(products),
                "Сканирование названий"
            )

            for product_index, p in enumerate(products, 1):
                if self.operation_should_stop():
                    break
                old_name = p.get("name") or ""

                # Поддерживаем оба варианта:
                # Б.У.  -> Б/у
                # Б.У   -> Б/у
                # (?=$|\s|[,;:()\[\]{}]) не даёт зацепить часть другого слова.
                pattern = r"Б\.У\.(?=$|\s|[,;:()\[\]{}])|Б\.У(?=$|\s|[,;:()\[\]{}])"
                new_name = re.sub(pattern, "Б/у", old_name)

                if new_name != old_name:
                    items.append(
                        RenameItem(
                            product_id=p.get("id", ""),
                            old_name=old_name,
                            new_name=new_name,
                            selected=False,
                        )
                    )

                if product_index == 1 or product_index % 25 == 0 or product_index == len(products):
                    self.root.after(
                        0,
                        self.update_operation_progress,
                        product_index,
                        len(products),
                        f"найдено {len(items)}"
                    )

            self.root.after(0, self._rename_scan_done, items, len(products))

        except Exception as e:
            self.root.after(0, self._rename_scan_error, str(e))

    def _rename_scan_done(self, items, total):
        self.finish_cancellable_operation()
        self.rename_progress.stop()
        self.rename_items = items

        for item in items:
            row = self.rename_tree.insert(
                "", "end",
                values=(item.old_name, item.new_name, item.status)
            )
            self.rename_by_item[row] = item

        # Важно: после поиска ничего не выбираем автоматически.
        self.rename_tree.selection_remove(self.rename_tree.selection())

        self.rename_status.set(
            f"Проверено: {total} • найдено: {len(items)} • выделите только нужные товары"
        )
        self.log_action(f"Названия Б/у: найдено {len(items)} товаров из {total}")
        self.update_rename_summary()

    def _rename_scan_error(self, msg):
        self.finish_cancellable_operation()
        self.rename_progress.stop()
        self.rename_status.set("Ошибка поиска.")
        self.log_action(f"Названия Б/у: ошибка поиска: {msg}", "ERROR")
        messagebox.showerror("Названия Б/у", msg)

    def _selected_rename_items(self):
        result = []
        for row in self.rename_tree.selection():
            item = self.rename_by_item.get(row)
            if item:
                result.append(item)
        return result

    def update_rename_summary(self, event=None):
        selected = self._selected_rename_items()
        self.rename_summary.config(text=f"Выделено: {len(selected)} товаров")
        self.rename_apply_btn.config(
            state="normal" if selected else "disabled"
        )

    def select_all_rename_rows(self):
        rows = self.rename_tree.get_children("")
        self.rename_tree.selection_set(rows)
        self.update_rename_summary()

    def clear_rename_selection(self):
        self.rename_tree.selection_remove(self.rename_tree.selection())
        self.update_rename_summary()

    def delete_rename_row(self, event=None):
        rows = list(self.rename_tree.selection())
        if not rows:
            return

        removed = 0
        for row in rows:
            item = self.rename_by_item.pop(row, None)
            if not item:
                continue

            try:
                self.rename_items.remove(item)
            except ValueError:
                pass

            self.rename_tree.delete(row)
            removed += 1
            self.log_action(
                f"Названия Б/у: строка убрана из очереди — {item.old_name}"
            )

        self.rename_status.set(
            f"Убрано из списка: {removed}. В МойСклад ничего не изменено."
        )
        self.update_rename_summary()

    # Для совместимости со старым кодом интерфейса
    def toggle_rename_item(self, event=None):
        self.update_rename_summary()

    def set_all_rename(self, value):
        if value:
            self.select_all_rename_rows()
        else:
            self.clear_rename_selection()

    def confirm_rename_apply(self):
        selected = self._selected_rename_items()

        if not selected:
            messagebox.showinfo(
                "MIX PC",
                "Выделите один или несколько товаров в таблице."
            )
            return

        backup_root = self.rename_backup_dir.get().strip()
        if not backup_root:
            messagebox.showinfo(
                "MIX PC",
                "Выберите папку для резервной копии."
            )
            return

        if not messagebox.askyesno(
            "Подтверждение",
            f"Будут изменены ТОЛЬКО ВЫДЕЛЕННЫЕ товары: {len(selected)}\n\n"
            "Замена: Б.У. / Б.У → Б/у\n\nПродолжить?"
        ):
            return

        backup_dir = Path(backup_root)
        backup_dir.mkdir(parents=True, exist_ok=True)
        backup_file = backup_dir / (
            f"MIXPC_names_backup_{datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}.json"
        )

        backup_file.write_text(
            json.dumps({
                "created": datetime.now().isoformat(timespec="seconds"),
                "replacement": {"from": ["Б.У.", "Б.У"], "to": "Б/у"},
                "products": [
                    {
                        "product_id": x.product_id,
                        "old_name": x.old_name,
                        "new_name": x.new_name
                    }
                    for x in selected
                ]
            }, ensure_ascii=False, indent=2),
            encoding="utf-8"
        )

        self.rename_progress.start(10)
        self.rename_apply_btn.config(state="disabled")
        self.begin_cancellable_operation("переименование Б/у", self.rename_status)
        self.rename_status.set(
            f"Переименовываю только выделенные товары: {len(selected)}…"
        )

        self.log_action(
            f"Названия Б/у: старт переименования выделенных товаров: {len(selected)}"
        )

        threading.Thread(
            target=self._rename_apply_worker,
            args=(selected, str(backup_file)),
            daemon=True
        ).start()

    def _rename_apply_worker(self, selected, backup_file):
        ok = 0
        failed = 0

        self.root.after(
            0,
            self.set_operation_total,
            len(selected),
            "Переименование"
        )

        for idx, item in enumerate(selected, 1):
            if self.operation_should_stop():
                break
            try:
                self.client.update_product_name(
                    item.product_id,
                    item.new_name
                )
                ok += 1
                self.log_action(
                    f"Названия Б/у: «{item.old_name}» → «{item.new_name}»"
                )
                self.root.after(
                    0, self._rename_remove_success, item.product_id
                )

            except Exception as e:
                failed += 1
                self.log_action(
                    f"Названия Б/у: ошибка — {item.old_name}: {e}",
                    "ERROR"
                )
                self.root.after(
                    0, self._rename_mark_error, item.product_id
                )

            self.root.after(
                0,
                self.rename_status.set,
                f"Переименование {idx}/{len(selected)} • успешно {ok} • ошибок {failed}"
            )
            self.root.after(
                0,
                self.update_operation_progress,
                idx,
                len(selected),
                f"успешно {ok} • ошибок {failed}"
            )

        self.root.after(
            0, self._rename_apply_done,
            ok, failed, backup_file
        )

    def _rename_remove_success(self, product_id):
        for row, item in list(self.rename_by_item.items()):
            if item.product_id == product_id:
                try:
                    self.rename_items.remove(item)
                except ValueError:
                    pass
                del self.rename_by_item[row]
                self.rename_tree.delete(row)
                break

        self.update_rename_summary()

    def _rename_mark_error(self, product_id):
        for row, item in self.rename_by_item.items():
            if item.product_id == product_id:
                vals = list(self.rename_tree.item(row, "values"))
                vals[2] = "⚠ Ошибка"
                self.rename_tree.item(row, values=vals)
                break

        self.update_rename_summary()

    def _rename_apply_done(self, ok, failed, backup_file):
        self.finish_cancellable_operation()
        self.rename_progress.stop()
        self.rename_status.set(
            f"Готово • успешно {ok} • ошибок {failed}"
        )

        self.log_action(
            f"Названия Б/у: завершено — успешно {ok}, ошибок {failed}"
        )

        messagebox.showinfo(
            "Названия Б/у",
            f"Успешно переименовано: {ok}\n"
            f"Ошибок: {failed}\n\n"
            f"Резервная копия:\n{backup_file}"
        )

    # =====================================================
    # 6. МОДЕЛИ ТОВАРОВ
    # =====================================================

    @staticmethod
    def _normalize_model_row(row):
        """
        Приводит разные варианты ответа МойСклад к единому dict:
        {"name": "...", "meta": {...}}

        На некоторых аккаунтах/справочниках API может вернуть:
        - обычный dict;
        - строку с названием;
        - dict, где значение лежит в value/name.
        """
        if isinstance(row, str):
            return {
                "name": row.strip(),
                "meta": None,
            }

        if not isinstance(row, dict):
            return None

        name = str(
            row.get("name")
            or row.get("value")
            or row.get("label")
            or ""
        ).strip()

        meta = row.get("meta")
        if not isinstance(meta, dict):
            meta = None

        return {
            **row,
            "name": name,
            "meta": meta,
        }

    @staticmethod
    def _normalize_model_text(text: str):
        text = (text or "").upper().replace("Ё", "Е")
        # Унифицируем разные типы тире и пробелы около дефиса.
        text = re.sub(r"[‐‑‒–—−]", "-", text)
        text = re.sub(r"\s*-\s*", "-", text)
        text = re.sub(r"\s+", " ", text).strip()
        return text

    @classmethod
    def _model_tokens(cls, text: str):
        normalized = cls._normalize_model_text(text)
        return re.findall(r"[A-ZА-Я0-9]+", normalized)

    @classmethod
    def _compact_model(cls, text: str):
        """
        Компактное представление модели без пробелов/дефисов/точек:
        Core i5-11400F -> COREI511400F
        Core i5 11400F -> COREI511400F
        FX-8320 -> FX8320
        FX8320 -> FX8320
        Xeon E3-1271V3 -> XEONE31271V3
        Xeon E3 1271 V3 -> XEONE31271V3
        """
        return "".join(cls._model_tokens(text))

    @classmethod
    def _model_in_product_name(cls, product_name: str, model_name: str):
        """
        Сравниваем компактную модель с КАЖДЫМ непрерывным окном токенов
        названия товара.

        Это позволяет считать одинаковыми:
          Core i5-11400F  / Core i5 11400F
          Xeon E3-1271V3 / Xeon E3 1271 V3
          FX-8320         / FX8320

        Но не даёт:
          5600 -> 5600G
          1271 -> 12710
        потому что окно должно совпасть целиком.
        """
        product_tokens = cls._model_tokens(product_name)
        target = cls._compact_model(model_name)

        if not product_tokens or not target:
            return False

        target_len = len(target)

        for start in range(len(product_tokens)):
            compact = ""
            for end in range(start, len(product_tokens)):
                compact += product_tokens[end]

                if len(compact) == target_len:
                    if compact == target:
                        return True
                    break

                if len(compact) > target_len:
                    break

        return False

    def _find_best_model_match(self, product_name: str):
        matches = []

        for raw_row in self.model_values:
            row = self._normalize_model_row(raw_row)
            if not row:
                continue

            name = str(row.get("name") or "").strip()
            if not name:
                continue

            if self._model_in_product_name(product_name, name):
                compact = self._compact_model(name)
                matches.append({
                    "row": row,
                    "compact_len": len(compact),
                    "has_digit": bool(re.search(r"\d", compact)),
                    "token_count": len(self._model_tokens(name)),
                })

        if not matches:
            return None, 0, "⚠ Не найдено"

        # Максимальная специфичность:
        # сначала модели с цифрами, затем самая длинная компактная модель,
        # затем большее количество смысловых токенов.
        matches.sort(
            key=lambda x: (
                1 if x["has_digit"] else 0,
                x["compact_len"],
                x["token_count"],
            ),
            reverse=True
        )

        best_info = matches[0]
        best = best_info["row"]

        # Общие значения вроде "Pentium", "Xeon", "Athlon" не записываем
        # автоматически — это семейство, а не конкретная модель.
        if not best_info["has_digit"]:
            return best, 55, "⚠ Слишком общее совпадение"

        # Если есть другой вариант той же специфичности — просим проверить.
        same_rank = [
            x for x in matches[1:]
            if (
                x["has_digit"] == best_info["has_digit"]
                and x["compact_len"] == best_info["compact_len"]
                and x["token_count"] == best_info["token_count"]
            )
        ]
        if same_rank:
            return best, 70, "⚠ Несколько совпадений"

        return best, 100, "✓ Точное совпадение"


    @staticmethod
    def _attribute_value_name(product, attribute_id: str):
        if not isinstance(product, dict):
            return ""

        attrs = product.get("attributes") or []
        if not isinstance(attrs, list):
            return ""

        for attr in attrs:
            if not isinstance(attr, dict):
                continue

            if str(attr.get("id", "")) != str(attribute_id):
                continue

            value = attr.get("value")

            if isinstance(value, dict):
                return str(
                    value.get("name")
                    or value.get("value")
                    or ""
                )

            return str(value or "")

        return ""

    def _sort_model_tree(self, column):
        """
        Сортировка таблицы моделей по клику на заголовок.
        Для «Статус» первый клик специально поднимает проблемы наверх.
        """
        reverse = self.model_sort_reverse.get(column, False)

        rows = list(self.model_tree.get_children(""))

        def status_rank(text):
            t = (text or "").lower()
            if "не найден" in t:
                return 0
            if "несколько" in t:
                return 1
            if "слишком общее" in t:
                return 2
            if "ошиб" in t:
                return 3
            if "точное" in t:
                return 10
            if "выбрано вручную" in t:
                return 11
            if "записано" in t:
                return 12
            return 8

        def key_for(row):
            item = self.model_by_item.get(row)

            if column == "#0":
                return (item.product_name if item else self.model_tree.item(row, "text")).lower()

            if not item:
                return ""

            if column == "selected":
                return 0 if item.selected else 1
            if column == "current":
                return (item.current_model or "").lower()
            if column == "proposed":
                return (item.proposed_model or "").lower()
            if column == "confidence":
                return item.confidence
            if column == "status":
                return (status_rank(item.status), item.status.lower())

            return ""

        # Для статуса первый клик = проблемы сверху.
        rows.sort(key=key_for, reverse=reverse)

        for index, row in enumerate(rows):
            self.model_tree.move(row, "", index)

        self.model_sort_reverse[column] = not reverse

    def _build_models_tab(self):
        info = ttk.LabelFrame(
            self.models_tab,
            text="Привязка модели к товару",
            padding=12
        )
        info.pack(fill=X)

        ttk.Label(
            info,
            text=(
                "Программа берёт допустимые значения прямо из дополнительного поля "
                "«Модель» в МойСклад и сопоставляет их с названием товара."
            )
        ).pack(anchor="w")

        ttk.Label(
            info,
            text=(
                "Выберите категорию. Программа сама найдёт поле вида "
                "«<Категория>. Модель», загрузит его справочник и сопоставит товары."
            )
        ).pack(anchor="w", pady=(4, 0))

        settings = ttk.Frame(self.models_tab)
        settings.pack(fill=X, pady=(12, 0))

        ttk.Label(settings, text="Категория:").pack(side=LEFT)
        self.model_category_combo = ttk.Combobox(
            settings,
            textvariable=self.model_category_name,
            state="readonly",
            width=30
        )
        self.model_category_combo.pack(side=LEFT, padx=(6, 14))

        ttk.Checkbutton(
            settings,
            text="Только товары с пустым полем «Модель»",
            variable=self.model_only_empty
        ).pack(side=LEFT)

        ttk.Button(
            settings,
            text="Загрузить и сопоставить",
            style="Primary.TButton",
            command=self.start_model_scan
        ).pack(side=RIGHT)

        self.model_progress = ttk.Progressbar(
            self.models_tab,
            mode="indeterminate"
        )
        self.model_progress.pack(fill=X, pady=(10, 0))

        box = ttk.LabelFrame(
            self.models_tab,
            text="Предпросмотр сопоставления",
            padding=10
        )
        box.pack(fill=BOTH, expand=True, pady=(10, 0))

        cols = ("selected", "current", "proposed", "confidence", "status")
        self.model_tree = ttk.Treeview(
            box,
            columns=cols,
            show="tree headings",
            selectmode="browse"
        )
        self.model_tree.heading("#0", text="Товар", command=lambda: self._sort_model_tree("#0"))
        self.model_tree.heading("selected", text="Записать", command=lambda: self._sort_model_tree("selected"))
        self.model_tree.heading("current", text="Сейчас", command=lambda: self._sort_model_tree("current"))
        self.model_tree.heading("proposed", text="Предлагаемая модель", command=lambda: self._sort_model_tree("proposed"))
        self.model_tree.heading("confidence", text="Точность", command=lambda: self._sort_model_tree("confidence"))
        self.model_tree.heading("status", text="Статус", command=lambda: self._sort_model_tree("status"))

        self.model_tree.column("#0", width=410)
        self.model_tree.column("selected", width=80, anchor="center")
        self.model_tree.column("current", width=160)
        self.model_tree.column("proposed", width=190)
        self.model_tree.column("confidence", width=80, anchor="center")
        self.model_tree.column("status", width=180)

        self.model_scroll = ttk.Scrollbar(
            box,
            orient=VERTICAL,
            command=self.model_tree.yview
        )
        self.model_tree.configure(yscrollcommand=self.model_scroll.set)
        self.model_scroll.pack(side=RIGHT, fill=Y)
        self.model_tree.pack(side=LEFT, fill=BOTH, expand=True)
        self.model_tree.bind("<Double-1>", self.toggle_model_item)
        self.model_tree.bind("<Delete>", self.delete_model_row)

        controls = ttk.Frame(self.models_tab)
        controls.pack(fill=X, pady=(8, 0))

        ttk.Button(
            controls,
            text="Выбрать точные",
            command=self.select_exact_models
        ).pack(side=LEFT)

        ttk.Button(
            controls,
            text="Снять все",
            command=lambda: self.set_all_model_items(False)
        ).pack(side=LEFT, padx=(6, 0))

        ttk.Button(
            controls,
            text="Выбрать модель вручную",
            command=self.manual_model_dialog
        ).pack(side=LEFT, padx=(6, 0))

        ttk.Button(
            controls,
            text="Выгрузить проблемные",
            command=self.export_problem_models
        ).pack(side=LEFT, padx=(6, 0))

        self.model_summary = ttk.Label(
            controls,
            text="Список ещё не загружен",
            style="H2.TLabel"
        )
        self.model_summary.pack(side=RIGHT)

        ttk.Label(
            self.models_tab,
            text="Подсказка: нажмите на заголовок столбца для сортировки; «Статус» поднимает проблемные строки наверх.",
            foreground="#666666"
        ).pack(anchor="w", pady=(6, 0))

        actions = ttk.Frame(self.models_tab)
        actions.pack(fill=X, pady=(10, 0))

        self.model_apply_btn = ttk.Button(
            actions,
            text="ЗАПИСАТЬ ВЫБРАННЫЕ МОДЕЛИ",
            style="Primary.TButton",
            state="disabled",
            command=self.confirm_apply_models
        )
        self.model_apply_btn.pack(side=RIGHT)

        ttk.Label(
            actions,
            textvariable=self.model_status_var
        ).pack(side=LEFT)

    def start_model_scan(self):
        if not self.client:
            messagebox.showinfo(
                "Модели",
                "Сначала подключитесь к МойСклад на вкладке «1. Категории»."
            )
            return

        self.begin_cancellable_operation("сопоставление моделей", self.model_status_var)
        self.model_progress.start(10)
        chosen_category = self.model_category_name.get().strip()
        if not chosen_category:
            self.finish_cancellable_operation()
            self.model_progress.stop()
            messagebox.showinfo("Модели", "Выберите категорию.")
            return

        self.model_status_var.set(
            f"Загружаю поле модели, справочник и товары категории «{chosen_category}»…"
        )
        self.model_apply_btn.config(state="disabled")
        self.model_tree.delete(*self.model_tree.get_children())
        self.model_items = []
        self.model_by_item.clear()

        threading.Thread(
            target=self._model_scan_worker,
            daemon=True
        ).start()

    @staticmethod
    def _extract_metadata_attributes(raw_attributes):
        """
        МойСклад в разных ответах/версиях может вернуть attributes как:
        1) обычный list[dict]
        2) объект вида {"rows": [...]}
        3) словарь, где сами атрибуты лежат значениями

        Приводим всё к list[dict].
        """
        if isinstance(raw_attributes, list):
            return [x for x in raw_attributes if isinstance(x, dict)]

        if isinstance(raw_attributes, dict):
            # Наиболее вероятный формат API: collection object с rows.
            rows = raw_attributes.get("rows")
            if isinstance(rows, list):
                return [x for x in rows if isinstance(x, dict)]

            # Иногда rows тоже может быть словарём.
            if isinstance(rows, dict):
                return [
                    x for x in rows.values()
                    if isinstance(x, dict)
                ]

            # Fallback: атрибуты могут быть значениями словаря.
            candidates = []
            for key, value in raw_attributes.items():
                if key in ("meta", "context", "size"):
                    continue
                if isinstance(value, dict):
                    # Сам объект уже похож на атрибут.
                    if any(k in value for k in ("name", "id", "type", "meta")):
                        candidates.append(value)
                    # Или внутри него лежат rows.
                    nested_rows = value.get("rows")
                    if isinstance(nested_rows, list):
                        candidates.extend(
                            x for x in nested_rows
                            if isinstance(x, dict)
                        )
                elif isinstance(value, list):
                    candidates.extend(
                        x for x in value
                        if isinstance(x, dict)
                    )

            return candidates

        return []

    @staticmethod
    def _collect_folder_and_descendants(folder: dict, all_folders: list[dict]):
        """
        Возвращает выбранную категорию + все её подпапки.
        МойСклад хранит processor-позиции в подпапках, поэтому запрос только
        по родителю может вернуть 0 товаров даже при сотнях товаров "с подпапками".
        """
        if not isinstance(folder, dict):
            return []

        root_meta = folder.get("meta") or {}
        root_href = root_meta.get("href") if isinstance(root_meta, dict) else None
        if not root_href:
            return [folder]

        by_parent = {}
        for f in all_folders:
            if not isinstance(f, dict):
                continue
            parent = f.get("productFolder") or {}
            parent_meta = parent.get("meta") if isinstance(parent, dict) else None
            parent_href = parent_meta.get("href") if isinstance(parent_meta, dict) else None
            if parent_href:
                by_parent.setdefault(parent_href, []).append(f)

        result = []
        stack = [folder]
        seen = set()

        while stack:
            cur = stack.pop()
            meta = cur.get("meta") or {}
            href = meta.get("href") if isinstance(meta, dict) else None
            if not href or href in seen:
                continue

            seen.add(href)
            result.append(cur)

            for child in by_parent.get(href, []):
                stack.append(child)

        return result

    def _model_scan_worker(self):
        stage = "старт"
        try:
            # 1. Метаданные дополнительных полей.
            # В вашем аккаунте product/metadata содержит только meta-ссылку
            # на отдельную коллекцию /metadata/attributes.
            stage = "загрузка метаданных дополнительных полей"
            attributes = self.client.product_attribute_metadata()

            if not attributes:
                raise RuntimeError(
                    "МойСклад вернул пустой список дополнительных полей товара."
                )

            self.log_action(
                f"Модели: получено дополнительных полей: {len(attributes)}"
            )

            stage = "поиск поля модели для выбранной категории"

            category_name = self.model_category_name.get().strip()
            category_lower = category_name.lower()

            # В МойСклад поля именуются с префиксом категории:
            # например "Процессоры. Модель", "Мониторы. Модель" и т.д.
            # Поэтому ищем в таком порядке:
            # 1) точное "<Категория>. Модель"
            # 2) любое поле, оканчивающееся на ". Модель" и начинающееся с нужной категории
            # 3) старый вариант "Модель" — для совместимости
            def norm_attr_name(a):
                return re.sub(
                    r"\s+",
                    " ",
                    str(a.get("name", "")).strip().lower()
                )

            exact_name = f"{category_lower}. модель"

            model_attr = next(
                (
                    a for a in attributes
                    if isinstance(a, dict)
                    and norm_attr_name(a) == exact_name
                ),
                None
            )

            if not model_attr:
                model_attr = next(
                    (
                        a for a in attributes
                        if isinstance(a, dict)
                        and norm_attr_name(a).startswith(category_lower + ".")
                        and norm_attr_name(a).endswith(". модель")
                    ),
                    None
                )

            if not model_attr:
                model_attr = next(
                    (
                        a for a in attributes
                        if isinstance(a, dict)
                        and norm_attr_name(a) == "модель"
                    ),
                    None
                )

            if not model_attr:
                matching = [
                    f"{a.get('name', '—')} [{a.get('type', '—')}]"
                    for a in attributes
                    if isinstance(a, dict)
                    and (
                        "модель" in norm_attr_name(a)
                        or norm_attr_name(a).startswith(category_lower + ".")
                    )
                ]

                raise RuntimeError(
                    f"Не найдено поле модели для категории «{category_name}».\n"
                    f"Похожие поля: {', '.join(matching[:50]) or 'нет'}"
                )

            self.log_action(
                f"Модели: найдено поле «{model_attr.get('name')}» "
                f"тип={model_attr.get('type')}"
            )

            field_type = str(model_attr.get("type") or "").lower()
            if field_type != "customentity":
                raise RuntimeError(
                    f"Поле «Модель» имеет тип {model_attr.get('type')!r}, "
                    "а ожидается пользовательский справочник (customentity)."
                )

            stage = "чтение ссылки справочника"
            custom_meta = model_attr.get("customEntityMeta") or {}

            if isinstance(custom_meta, str):
                custom_href = custom_meta
            elif isinstance(custom_meta, dict):
                custom_href = (
                    custom_meta.get("href")
                    or (custom_meta.get("meta") or {}).get("href")
                )
            else:
                custom_href = None

            if not custom_href:
                raise RuntimeError(
                    "У поля «Модель» нет корректной ссылки customEntityMeta."
                )

            # 2. Значения справочника.
            stage = "загрузка значений справочника «Модель»"
            self.log_action(

                f"Модели: customEntityMeta для поля «{model_attr.get('name')}»: {custom_href}"

            )

            values = self.client.custom_entity_rows(custom_href)

            if not isinstance(values, list):
                raise RuntimeError(
                    f"Справочник «Модель» вернул тип {type(values).__name__}, ожидался список."
                )

            normalized_values = []
            skipped_values = 0

            for raw_value in values:
                value = self._normalize_model_row(raw_value)
                if not value or not value.get("name"):
                    skipped_values += 1
                    continue
                normalized_values.append(value)

            if not normalized_values:
                raise RuntimeError(
                    "После нормализации справочник «Модель» оказался пуст."
                )

            self.model_attribute = model_attr
            self.model_values = normalized_values
            self.model_values_by_name = {
                self._normalize_model_text(v.get("name", "")): v
                for v in normalized_values
                if isinstance(v, dict) and v.get("name")
            }

            self.log_action(
                f"Модели: справочник — нормальных значений {len(normalized_values)}, "
                f"пропущено {skipped_values}"
            )

            # 3. Категория.
            stage = "загрузка категорий"
            folders = self.client.product_folders()
            if not isinstance(folders, list):
                raise RuntimeError(
                    f"Список категорий имеет тип {type(folders).__name__}, ожидался list."
                )

            wanted = self.model_category_name.get().strip().lower()

            folder = next(
                (
                    f for f in folders
                    if isinstance(f, dict)
                    and str(f.get("name", "")).strip().lower() == wanted
                ),
                None
            )

            if not folder:
                raise RuntimeError(
                    f"Категория «{self.model_category_name.get().strip()}» не найдена."
                )

            meta = folder.get("meta")
            if isinstance(meta, str):
                folder_href = meta
            elif isinstance(meta, dict):
                folder_href = meta.get("href")
            else:
                folder_href = None

            if not folder_href:
                raise RuntimeError("У категории нет корректного meta.href.")

            # 4. Товары.
            stage = "загрузка товаров категории и подпапок"

            target_folders = self._collect_folder_and_descendants(
                folder,
                folders
            )

            self.log_action(
                f"Модели: категория «{folder.get('name')}» + подпапки: "
                f"{len(target_folders)} папок"
            )

            raw_products = []
            seen_product_ids = set()

            for f in target_folders:
                if self.operation_should_stop():
                    break
                f_meta = f.get("meta") or {}
                f_href = f_meta.get("href") if isinstance(f_meta, dict) else None
                if not f_href:
                    continue

                for p in self.client.products_in_folder(f_href):
                    if not isinstance(p, dict):
                        raw_products.append(p)
                        continue

                    pid = str(p.get("id") or "")
                    if pid and pid in seen_product_ids:
                        continue

                    if pid:
                        seen_product_ids.add(pid)

                    raw_products.append(p)

            products = [
                p for p in raw_products
                if isinstance(p, dict)
            ]

            skipped_products = len(raw_products) - len(products)
            if skipped_products:
                self.log_action(
                    f"Модели: пропущено товаров неожиданного типа: {skipped_products}",
                    "WARN"
                )

            self.log_action(
                f"Модели: найдено товаров в «{folder.get('name')}» "
                f"с подпапками: {len(products)}"
            )

            items = []
            only_empty = bool(self.model_only_empty.get())
            attr_id = str(model_attr.get("id") or "")

            stage = "сопоставление моделей"
            self.root.after(
                0,
                self.set_operation_total,
                len(products),
                f"Категория «{category_name}»"
            )

            for product_index, product in enumerate(products, 1):
                if self.operation_should_stop():
                    break
                current = self._attribute_value_name(
                    product,
                    attr_id
                )

                if only_empty and current:
                    continue

                product_name = str(
                    product.get("name")
                    or "(без имени)"
                )

                best, confidence, status = self._find_best_model_match(
                    product_name
                )

                proposed_name = ""
                proposed_meta = None
                selected = False

                if isinstance(best, dict):
                    proposed_name = str(
                        best.get("name")
                        or ""
                    )
                    proposed_meta = best.get("meta")

                    selected = (
                        confidence == 100
                        and isinstance(proposed_meta, dict)
                        and proposed_name != current
                    )

                if current and proposed_name == current:
                    status = "Уже заполнено"
                    selected = False

                items.append(
                    ModelMatchItem(
                        product_id=str(product.get("id") or ""),
                        product_name=product_name,
                        current_model=current,
                        proposed_model=proposed_name,
                        proposed_meta=proposed_meta
                            if isinstance(proposed_meta, dict)
                            else None,
                        confidence=confidence,
                        status=status,
                        selected=selected,
                    )
                )

                if product_index == 1 or product_index % 10 == 0 or product_index == len(products):
                    self.root.after(
                        0,
                        self.update_operation_progress,
                        product_index,
                        len(products),
                        product_name[:45]
                    )

            self.root.after(
                0,
                self._model_scan_done,
                items,
                len(normalized_values),
                len(products)
            )

        except Exception as e:
            tb = traceback.format_exc()

            self.log_action(
                f"Модели: ошибка на этапе «{stage}»: {e}\n{tb}",
                "ERROR"
            )

            self.root.after(
                0,
                self._model_scan_error,
                f"Этап: {stage}\n\n{e}"
            )

    def _model_scan_done(self, items, model_count, product_count):
        self.finish_cancellable_operation()
        self.model_progress.stop()
        self.model_items = items

        for m in items:
            row = self.model_tree.insert(
                "",
                "end",
                text=m.product_name,
                values=(
                    "☑" if m.selected else "☐",
                    m.current_model or "—",
                    m.proposed_model or "—",
                    f"{m.confidence}%" if m.confidence else "—",
                    m.status,
                )
            )
            self.model_by_item[row] = m

        matched = sum(1 for x in items if x.confidence == 100)
        not_found = sum(1 for x in items if not x.proposed_model)

        self.model_status_var.set(
            f"Справочник: {model_count} моделей • "
            f"товаров с подпапками: {product_count} • "
            f"точно найдено: {matched} • не найдено: {not_found}"
        )

        self.log_action(
            f"Модели: справочник {model_count}, товаров {product_count}, "
            f"точных совпадений {matched}, не найдено {not_found}"
        )
        self.update_model_summary()

    def _model_scan_error(self, msg):
        self.finish_cancellable_operation()
        self.model_progress.stop()
        self.model_status_var.set("Ошибка загрузки моделей.")
        messagebox.showerror(
            "Модели",
            f"{msg}\n\n"
            "Полный traceback записан во вкладку «Журнал»."
        )

    def toggle_model_item(self, event=None):
        row = self.model_tree.focus()
        if not row or row not in self.model_by_item:
            return

        item = self.model_by_item[row]
        if not item.proposed_meta:
            return

        item.selected = not item.selected
        vals = list(self.model_tree.item(row, "values"))
        vals[0] = "☑" if item.selected else "☐"
        self.model_tree.item(row, values=vals)
        self.update_model_summary()

    def delete_model_row(self, event=None):
        row = self.model_tree.focus()
        if not row or row not in self.model_by_item:
            return

        item = self.model_by_item.pop(row)
        try:
            self.model_items.remove(item)
        except ValueError:
            pass
        self.model_tree.delete(row)
        self.update_model_summary()

    def select_exact_models(self):
        for row, item in self.model_by_item.items():
            item.selected = (
                item.confidence == 100
                and bool(item.proposed_meta)
                and item.proposed_model != item.current_model
            )
            vals = list(self.model_tree.item(row, "values"))
            vals[0] = "☑" if item.selected else "☐"
            self.model_tree.item(row, values=vals)
        self.update_model_summary()

    def set_all_model_items(self, value: bool):
        for row, item in self.model_by_item.items():
            if value and not item.proposed_meta:
                continue
            item.selected = value
            vals = list(self.model_tree.item(row, "values"))
            vals[0] = "☑" if value else "☐"
            self.model_tree.item(row, values=vals)
        self.update_model_summary()

    def update_model_summary(self):
        selected = [x for x in self.model_items if x.selected]
        exact = [x for x in self.model_items if x.confidence == 100]
        self.model_summary.config(
            text=(
                f"Строк: {len(self.model_items)} • "
                f"точных: {len(exact)} • к записи: {len(selected)}"
            )
        )
        self.model_apply_btn.config(
            state="normal" if selected else "disabled"
        )

    def export_problem_models(self):
        """
        Выгружает позиции, которые требуют ручной проверки:
        - модель не найдена;
        - найдено несколько вариантов;
        - совпадение слишком общее;
        - точность < 100%.

        Формат CSV с UTF-8 BOM и разделителем ; — удобно открывается в Excel.
        """
        problems = [
            item for item in self.model_items
            if (
                item.confidence < 100
                or not item.proposed_model
                or str(item.status).startswith("⚠")
            )
        ]

        if not problems:
            messagebox.showinfo(
                "Выгрузка моделей",
                "Проблемных позиций нет — выгружать нечего."
            )
            return

        category = self.model_category_name.get().strip() or "Категория"
        safe_category = re.sub(r'[<>:"/\\\\|?*]+', "_", category)
        default_name = (
            f"model_problem_{safe_category}_"
            f"{datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}.csv"
        )

        path = filedialog.asksaveasfilename(
            title="Сохранить проблемные позиции",
            defaultextension=".csv",
            initialfile=default_name,
            filetypes=[
                ("CSV для Excel", "*.csv"),
                ("Все файлы", "*.*"),
            ],
        )
        if not path:
            return

        try:
            with open(
                path,
                "w",
                newline="",
                encoding="utf-8-sig"
            ) as f:
                writer = csv.writer(
                    f,
                    delimiter=";",
                    quoting=csv.QUOTE_MINIMAL
                )

                writer.writerow([
                    "Категория",
                    "Товар",
                    "Текущая модель",
                    "Предлагаемая модель",
                    "Точность",
                    "Статус",
                    "ID товара",
                ])

                for item in problems:
                    writer.writerow([
                        category,
                        item.product_name,
                        item.current_model or "",
                        item.proposed_model or "",
                        f"{item.confidence}%",
                        item.status,
                        item.product_id,
                    ])

            self.log_action(
                f"Модели: выгружено проблемных позиций {len(problems)} → {path}"
            )

            messagebox.showinfo(
                "Выгрузка моделей",
                f"Готово.\n\n"
                f"Выгружено позиций: {len(problems)}\n"
                f"Файл:\n{path}"
            )

            try:
                os.startfile(str(Path(path).parent))
            except Exception:
                pass

        except Exception as e:
            self.log_action(
                f"Модели: ошибка выгрузки проблемных позиций: {e}",
                "ERROR"
            )
            messagebox.showerror(
                "Выгрузка моделей",
                f"Не удалось сохранить файл.\n\n{e}"
            )

    def manual_model_dialog(self):
        row = self.model_tree.focus()
        if not row or row not in self.model_by_item:
            messagebox.showinfo("Модели", "Сначала выберите товар в таблице.")
            return

        item = self.model_by_item[row]

        win = Toplevel(self.root)
        win.title("Выбор модели")
        win.geometry("640x420")
        win.transient(self.root)
        win.grab_set()

        ttk.Label(
            win,
            text=item.product_name,
            font=("Segoe UI", 10, "bold"),
            wraplength=600
        ).pack(anchor="w", padx=14, pady=(14, 8))

        ttk.Label(
            win,
            text="Начните вводить модель — список ниже будет фильтроваться автоматически:"
        ).pack(anchor="w", padx=14)

        search_var = StringVar(value=item.proposed_model or "")
        search = ttk.Entry(win, textvariable=search_var)
        search.pack(fill=X, padx=14, pady=(5, 8))
        search.focus_set()

        list_frame = ttk.Frame(win)
        list_frame.pack(fill=BOTH, expand=True, padx=14)

        result_list = Listbox(
            list_frame,
            exportselection=False,
            font=("Segoe UI", 10)
        )
        result_scroll = ttk.Scrollbar(
            list_frame,
            orient=VERTICAL,
            command=result_list.yview
        )
        result_list.configure(yscrollcommand=result_scroll.set)
        result_scroll.pack(side=RIGHT, fill=Y)
        result_list.pack(side=LEFT, fill=BOTH, expand=True)

        all_names = sorted(
            [
                str(v.get("name") or "")
                for v in self.model_values
                if isinstance(v, dict) and v.get("name")
            ],
            key=str.lower
        )

        def rank(name, query):
            if not query:
                return (3, len(name), name.lower())

            nq = self._normalize_model_text(query)
            nn = self._normalize_model_text(name)

            if nn.startswith(nq):
                return (0, len(name), name.lower())
            if nq in nn:
                return (1, len(name), name.lower())

            qtokens = self._model_tokens(query)
            ntokens = self._model_tokens(name)
            if qtokens and all(
                any(q in token for token in ntokens)
                for q in qtokens
            ):
                return (2, len(name), name.lower())

            return None

        def refresh(event=None):
            query = search_var.get().strip()
            scored = []
            for name in all_names:
                score = rank(name, query)
                if score is not None:
                    scored.append((score, name))

            scored.sort(key=lambda x: x[0])
            result_list.delete(0, END)
            for _, name in scored[:150]:
                result_list.insert(END, name)

            if result_list.size():
                result_list.selection_set(0)
                result_list.see(0)

        def apply_selected(event=None):
            sel = result_list.curselection()
            chosen = result_list.get(sel[0]).strip() if sel else search_var.get().strip()
            model = self.model_values_by_name.get(
                self._normalize_model_text(chosen)
            )
            if not model:
                messagebox.showerror(
                    "Модели",
                    "Выберите значение из предложенного списка."
                )
                return

            item.proposed_model = str(model.get("name") or "")
            item.proposed_meta = model.get("meta")
            item.confidence = 100
            item.status = "Выбрано вручную"
            item.selected = True

            vals = list(self.model_tree.item(row, "values"))
            vals[0] = "☑"
            vals[2] = item.proposed_model
            vals[3] = "100%"
            vals[4] = item.status
            self.model_tree.item(row, values=vals)
            self.update_model_summary()
            win.destroy()

        search.bind("<KeyRelease>", refresh)
        result_list.bind("<Double-1>", apply_selected)
        result_list.bind("<Return>", apply_selected)

        buttons = ttk.Frame(win)
        buttons.pack(fill=X, padx=14, pady=12)
        ttk.Button(
            buttons,
            text="Применить",
            style="Primary.TButton",
            command=apply_selected
        ).pack(side=RIGHT)

        refresh()


    def confirm_apply_models(self):
        selected = [x for x in self.model_items if x.selected]
        if not selected:
            messagebox.showinfo(
                "Модели",
                "Не выбрано ни одного товара."
            )
            return

        if not self.model_attribute:
            messagebox.showerror(
                "Модели",
                "Метаданные поля «Модель» не загружены."
            )
            return

        if not messagebox.askyesno(
            "Запись моделей",
            f"Будет записано моделей: {len(selected)}\n\n"
            "Изменяется только дополнительное поле «Модель».\n"
            "Названия и остальные поля товаров не меняются.\n\n"
            "Продолжить?"
        ):
            return

        self.begin_cancellable_operation("запись моделей", self.model_status_var)
        self.model_progress.start(10)
        self.model_apply_btn.config(state="disabled")
        self.model_status_var.set("Записываю модели в МойСклад…")

        threading.Thread(
            target=self._apply_models_worker,
            args=(selected,),
            daemon=True
        ).start()

    def _apply_models_worker(self, selected):
        ok = 0
        failed = 0
        attr_meta = self.model_attribute.get("meta")

        if not attr_meta:
            self.root.after(
                0,
                self._model_apply_done,
                0,
                len(selected),
                ["У поля «Модель» отсутствует meta."]
            )
            return

        errors = []

        self.root.after(
            0,
            self.set_operation_total,
            len(selected),
            "Запись моделей"
        )

        for idx, item in enumerate(selected, 1):
            if self.operation_should_stop():
                break
            try:
                if not item.proposed_meta:
                    raise RuntimeError("У модели отсутствует meta.")

                self.client.update_product_custom_attribute(
                    item.product_id,
                    attr_meta,
                    item.proposed_meta
                )

                item.current_model = item.proposed_model
                item.selected = False
                item.status = "Записано"
                ok += 1

                self.root.after(
                    0,
                    self._update_model_row_after_apply,
                    item.product_id,
                    True,
                    ""
                )
                self.log_action(
                    f"Модели: {item.product_name} → {item.proposed_model}"
                )

            except Exception as e:
                failed += 1
                error = str(e)
                errors.append(
                    f"{item.product_name}: {error}"
                )
                self.root.after(
                    0,
                    self._update_model_row_after_apply,
                    item.product_id,
                    False,
                    error
                )
                self.log_action(
                    f"Модели: ошибка {item.product_name}: {error}",
                    "ERROR"
                )

            self.root.after(
                0,
                self.model_status_var.set,
                f"Запись {idx}/{len(selected)} • успешно {ok} • ошибок {failed}"
            )
            self.root.after(
                0,
                self.update_operation_progress,
                idx,
                len(selected),
                f"успешно {ok} • ошибок {failed}"
            )

        self.root.after(
            0,
            self._model_apply_done,
            ok,
            failed,
            errors
        )

    def _update_model_row_after_apply(self, product_id, success, error):
        for row, item in self.model_by_item.items():
            if item.product_id != product_id:
                continue

            vals = list(self.model_tree.item(row, "values"))
            if success:
                vals[0] = "☐"
                vals[1] = item.current_model
                vals[4] = "Записано"
            else:
                vals[0] = "☐"
                vals[4] = "⚠ " + error.replace("\n", " ")[:110]
                item.selected = False

            self.model_tree.item(row, values=vals)
            break

        self.update_model_summary()

    def _model_apply_done(self, ok, failed, errors):
        self.finish_cancellable_operation()
        self.model_progress.stop()
        self.model_status_var.set(
            f"Готово • записано {ok} • ошибок {failed}"
        )
        self.update_model_summary()

        msg = (
            f"Моделей записано: {ok}\n"
            f"Ошибок: {failed}"
        )
        if errors:
            msg += "\n\nПервые ошибки:\n" + "\n".join(errors[:5])

        messagebox.showinfo("Модели", msg)

    # =====================================================
    # JOURNAL
    # =====================================================

    def _build_journal(self):
        top = ttk.Frame(self.journal_tab)
        top.pack(fill=X)

        ttk.Label(top, text="Журнал действий", style="Title.TLabel").pack(side=LEFT)
        ttk.Button(top, text="Открыть папку логов", command=self.open_log_folder).pack(side=RIGHT)
        ttk.Button(top, text="Очистить экран", command=self.clear_journal_screen).pack(side=RIGHT, padx=(0, 8))

        ttk.Label(self.journal_tab, text=f"Файл: {self.log_file}").pack(anchor="w", pady=(8, 10))

        self.journal_text = __import__("tkinter").Text(
            self.journal_tab, wrap="word", height=30, font=("Consolas", 10)
        )
        self.journal_text.pack(fill=BOTH, expand=True)

        try:
            if self.log_file.exists():
                tail = self.log_file.read_text(encoding="utf-8", errors="replace").splitlines()[-300:]
                if tail:
                    self.journal_text.insert(END, "\n".join(tail) + "\n")
                    self.journal_text.see(END)
        except Exception:
            pass

    def clear_journal_screen(self):
        self.journal_text.delete("1.0", END)
        self.log_action("Экран журнала очищен")

    def open_log_folder(self):
        try:
            os.startfile(str(self.log_dir))
        except Exception as e:
            messagebox.showerror("Журнал", f"Не удалось открыть папку логов:\n{e}")

    # =====================================================
    # 4. MAIN PHOTO — parent product -> variants by color
    # =====================================================

    def _build_main_photo(self):
        intro = ttk.LabelFrame(self.main_photo_tab, text="Замена главного фото модификаций", padding=12)
        intro.pack(fill=X)

        ttk.Label(
            intro,
            text="Логика: CPU + GPU находят родительскую сборку, а цвет из имени папки — нужные модификации."
        ).pack(anchor="w")
        ttk.Label(
            intro,
            text="RAM / SSD специально игнорируются: одно фото применяется ко всем модификациям выбранного цвета."
        ).pack(anchor="w", pady=(4, 0))

        source = ttk.LabelFrame(self.main_photo_tab, text="1. Папка с экспортом Figma", padding=12)
        source.pack(fill=X, pady=(12, 0))

        ttk.Entry(source, textvariable=self.main_root_var).grid(row=0, column=0, sticky="ew", padx=(0, 8))
        ttk.Button(source, text="Выбрать папку", command=self.pick_main_root).grid(row=0, column=1)
        ttk.Button(
            source, text="Сканировать и сопоставить", style="Primary.TButton",
            command=self.start_main_match
        ).grid(row=0, column=2, padx=(8, 0))
        source.columnconfigure(0, weight=1)

        ttk.Label(
            source,
            text="Пример: ИГРОВОЙ ПК_intel I5 14600KF + RTX 5070 Ti_белый"
        ).grid(row=1, column=0, columnspan=3, sticky="w", pady=(6, 0))

        table = ttk.LabelFrame(self.main_photo_tab, text="2. Проверка перед заменой", padding=10)
        table.pack(fill=BOTH, expand=True, pady=(12, 0))

        cols = ("local", "product", "color", "parent_color", "variants", "selected", "status")
        self.main_tree = ttk.Treeview(table, columns=cols, show="headings", selectmode="browse")
        self.main_tree.heading("local", text="Локальная папка")
        self.main_tree.heading("product", text="Родительский товар")
        self.main_tree.heading("color", text="Цвет фото")
        self.main_tree.heading("parent_color", text="Цвет родителя")
        self.main_tree.heading("variants", text="Модификаций")
        self.main_tree.heading("selected", text="Заменить")
        self.main_tree.heading("status", text="Статус")

        self.main_tree.column("local", width=260)
        self.main_tree.column("product", width=280)
        self.main_tree.column("color", width=90, anchor="center")
        self.main_tree.column("parent_color", width=110, anchor="center")
        self.main_tree.column("variants", width=100, anchor="center")
        self.main_tree.column("selected", width=90, anchor="center")
        self.main_tree.column("status", width=170)
        self.main_scroll = ttk.Scrollbar(
            table,
            orient=VERTICAL,
            command=self.main_tree.yview
        )
        self.main_tree.configure(yscrollcommand=self.main_scroll.set)
        self.main_scroll.pack(side=RIGHT, fill=Y)
        self.main_tree.pack(side=LEFT, fill=BOTH, expand=True)
        self.main_tree.bind("<Double-1>", self.toggle_main_match)
        self.main_tree.bind("<Delete>", self.delete_main_row)

        ttk.Label(
            table,
            text="Подсказка: выделите строку одним кликом и нажмите Delete, чтобы убрать её из текущего списка."
        ).pack(anchor="w", pady=(6, 0))

        bar = ttk.Frame(self.main_photo_tab)
        bar.pack(fill=X, pady=(8, 0))
        ttk.Button(bar, text="Выбрать родителя вручную", command=self.manual_pick_main_product).pack(side=LEFT)
        ttk.Button(bar, text="Выбрать все готовые", command=self.select_all_exact_main).pack(side=LEFT, padx=(6, 0))
        ttk.Button(bar, text="Снять все", command=lambda: self.set_all_main(False)).pack(side=LEFT, padx=(6, 0))

        self.main_summary = ttk.Label(bar, text="Сопоставление ещё не выполнено", style="H2.TLabel")
        self.main_summary.pack(side=RIGHT)

        optimize = ttk.LabelFrame(self.main_photo_tab, text="3. Оптимизация главного фото", padding=12)
        optimize.pack(fill=X, pady=(12, 0))

        ttk.Label(optimize, text="Максимальный вес, КБ").grid(row=0, column=0, sticky="w")
        ttk.Spinbox(
            optimize, from_=150, to=1500, increment=50,
            textvariable=self.main_target_kb, width=8
        ).grid(row=0, column=1, sticky="w", padx=(8, 24))

        ttk.Label(optimize, text="Максимальная сторона, px").grid(row=0, column=2, sticky="w")
        ttk.Spinbox(
            optimize, from_=800, to=3000, increment=100,
            textvariable=self.main_max_side, width=8
        ).grid(row=0, column=3, sticky="w", padx=(8, 0))

        ttk.Label(
            optimize,
            text="Фото автоматически сохраняется как оптимизированный JPEG. По умолчанию лимит ≈100 КБ."
        ).grid(row=1, column=0, columnspan=4, sticky="w", pady=(6, 0))

        backup = ttk.LabelFrame(self.main_photo_tab, text="4. Резервная копия", padding=12)
        backup.pack(fill=X, pady=(12, 0))
        ttk.Entry(backup, textvariable=self.main_backup_var).grid(row=0, column=0, sticky="ew", padx=(0, 8))
        ttk.Button(backup, text="Выбрать папку", command=self.pick_main_backup).grid(row=0, column=1)
        backup.columnconfigure(0, weight=1)

        ttk.Label(
            backup,
            text="Перед заменой сохраняются все текущие фото каждой затрагиваемой модификации."
        ).grid(row=1, column=0, columnspan=2, sticky="w", pady=(6, 0))

        actions = ttk.Frame(self.main_photo_tab)
        actions.pack(fill=X, pady=(12, 0))
        self.main_upload_btn = ttk.Button(
            actions, text="ЗАМЕНИТЬ ГЛАВНЫЕ ФОТО", style="Primary.TButton",
            state="disabled", command=self.confirm_main_upload
        )
        self.main_upload_btn.pack(side=RIGHT)

        self.main_stop_btn = ttk.Button(
            actions, text="СТОП", style="Danger.TButton",
            state="disabled", command=self.stop_main_process
        )
        self.main_stop_btn.pack(side=RIGHT, padx=(8, 0))

        self.main_resume_btn = ttk.Button(
            actions, text="ВОЗОБНОВИТЬ", style="Primary.TButton",
            command=self.resume_main_process
        )

        ttk.Label(actions, textvariable=self.main_elapsed_var, style="H2.TLabel").pack(
            side=RIGHT, padx=(12, 8)
        )

        self.main_progress = ttk.Progressbar(actions, mode="indeterminate")
        self.main_progress.pack(side=LEFT, fill=X, expand=True, padx=(0, 12))

        self.main_status = StringVar(
            value="Выберите категорию со сборками на шаге 1 и папку с экспортом Figma."
        )
        ttk.Label(self.main_photo_tab, textvariable=self.main_status).pack(anchor="w", pady=(6, 0))

    def pick_main_root(self):
        p = filedialog.askdirectory(title="Корневая папка с экспортом главных фото")
        if p:
            self.main_root_var.set(p)
            self._save_persistent_settings()

    def pick_main_backup(self):
        p = filedialog.askdirectory(title="Папка для резервной копии главных фото")
        if p:
            self.main_backup_var.set(p)
            self._save_persistent_settings()

    @staticmethod
    def _normalize_component_text(text: str) -> str:
        s = text.lower().replace("ё", "е")
        replacements = {
            "_": " ", "-": " ", "intel": " ", "amd": " ",
            "игровой пк": " ", "gaming pc": " ",
        }
        for a, b in replacements.items():
            s = s.replace(a, b)

        s = re.sub(r"\bryzen\s*([3579])\b", r"r\1", s)
        s = re.sub(r"\br\s*([3579])\b", r"r\1", s)
        s = re.sub(r"\bi\s*([3579])\b", r"i\1", s)
        s = re.sub(r"\brtx\s*", "rtx", s)
        s = re.sub(r"\s+", " ", s).strip()
        return s

    @classmethod
    def _extract_hw_key(cls, text: str):
        s = cls._normalize_component_text(text)
        cpu = None
        gpu = None

        m = re.search(r"\b(i[3579])\s*([0-9]{4,5})([a-z]{0,3})\b", s)
        if m:
            cpu = f"{m.group(1)}{m.group(2)}{m.group(3)}"
        else:
            m = re.search(r"\b(r[3579])\s*([0-9]{4})([a-z0-9]{0,4})\b", s)
            if m:
                cpu = f"{m.group(1)}{m.group(2)}{m.group(3)}"

        m = re.search(r"\brtx\s*([0-9]{4})\s*(ti|super)?\b", s)
        if not m:
            m = re.search(r"\brtx([0-9]{4})(ti|super)?\b", s)
        if m:
            gpu = f"rtx{m.group(1)}{m.group(2) or ''}"

        if not cpu or not gpu:
            return None
        return f"{cpu}|{gpu}"

    @staticmethod
    def _normalize_color(value: str | None):
        if not value:
            return None
        s = value.lower().replace("ё", "е").strip()
        white = ("белый", "белая", "белое", "white")
        black = ("черный", "черная", "черное", "black")
        if any(x in s for x in white):
            return "Белый"
        if any(x in s for x in black):
            return "Черный"
        return value.strip()

    @classmethod
    def _extract_folder_color(cls, text: str):
        return cls._normalize_color(text)

    @classmethod
    def _variant_color(cls, variant: dict):
        chars = variant.get("characteristics") or []
        # Сначала строго ищем характеристику "Цвет".
        for ch in chars:
            if (ch.get("name") or "").strip().lower().replace("ё", "е") == "цвет":
                return cls._normalize_color(ch.get("value"))
        # Ничего не угадываем по другим характеристикам.
        return None

    @staticmethod
    def _local_main_image(folder: Path):
        supported = {".png", ".jpg", ".jpeg", ".webp"}
        files = [p for p in folder.iterdir() if p.is_file() and p.suffix.lower() in supported]
        if not files:
            return None

        def rank(p):
            n = p.stem.lower()
            preferred = int(any(x in n for x in ("main", "глав", "01", "1")))
            return (-preferred, p.name.lower())

        return sorted(files, key=rank)[0]

    def _compress_main_photo(self, image_path: Path):
        """
        Оптимизирует главное фото под web/marketplace:
        - JPEG;
        - белый фон для прозрачности;
        - ограничение максимальной стороны;
        - адаптивное качество до целевого веса.
        """
        target_bytes = max(100, int(self.main_target_kb.get())) * 1024
        max_side = max(600, int(self.main_max_side.get()))

        with Image.open(image_path) as im:
            im.load()

            if im.mode == "RGBA":
                bg = Image.new("RGB", im.size, (255, 255, 255))
                bg.paste(im, mask=im.getchannel("A"))
                img = bg
            else:
                img = im.convert("RGB")

            # Не увеличиваем маленькие изображения.
            if max(img.size) > max_side:
                img.thumbnail((max_side, max_side), Image.Resampling.LANCZOS)

            # Сначала пробуем без дополнительного уменьшения.
            scale_steps = [1.0, 0.92, 0.84, 0.76, 0.68, 0.60, 0.52, 0.46]
            quality_steps = [84, 80, 76, 72, 68, 64, 60, 56, 52, 48]

            best = None
            best_size = None
            original_work = img.copy()

            for scale in scale_steps:
                if scale == 1.0:
                    work_img = original_work
                else:
                    w = max(1, int(original_work.width * scale))
                    h = max(1, int(original_work.height * scale))
                    work_img = original_work.resize((w, h), Image.Resampling.LANCZOS)

                for quality in quality_steps:
                    buf = io.BytesIO()
                    work_img.save(
                        buf,
                        format="JPEG",
                        quality=quality,
                        optimize=True,
                        progressive=True,
                        subsampling=2,
                    )
                    data = buf.getvalue()

                    best = data
                    best_size = work_img.size

                    if len(data) <= target_bytes:
                        return data, "Главное.jpg", best_size, quality

            # Если даже после всех шагов цель не достигнута — возвращаем самый лёгкий вариант.
            return best, "Главное.jpg", best_size, quality_steps[-1]

    @staticmethod
    def _attribute_id_from_meta(attr: dict):
        meta = attr.get("meta") or {}
        href = meta.get("href") or ""
        if "/attributes/" in href:
            return href.rsplit("/attributes/", 1)[-1].split("?", 1)[0].strip("/")
        return attr.get("id")

    @classmethod
    def _attribute_value_text(cls, value):
        if value is None:
            return None
        if isinstance(value, str):
            return value
        if isinstance(value, (int, float, bool)):
            return str(value)
        if isinstance(value, dict):
            for key in ("name", "value", "displayName"):
                if value.get(key) is not None:
                    return str(value.get(key))
        return str(value)

    @classmethod
    def _parent_product_color(cls, product: dict, attr_names: dict):
        for attr in product.get("attributes") or []:
            attr_id = cls._attribute_id_from_meta(attr)
            name = attr.get("name") or attr_names.get(attr_id, "")
            n = str(name).lower().replace("ё", "е").replace("_", " ").strip()
            if not (n == "сборки. цвет" or n == "сборки цвет" or ("сборки" in n and n.endswith("цвет"))):
                continue
            raw = cls._attribute_value_text(attr.get("value"))
            return cls._normalize_color(raw)
        return None

    def start_main_match(self):
        if not self.client:
            messagebox.showinfo("MIX PC", "Сначала подключитесь к МойСклад на вкладке «1. Категории».")
            return

        nodes = self.selected_nodes_with_descendants()
        if not nodes:
            messagebox.showinfo(
                "MIX PC",
                "На вкладке «1. Категории» выберите категорию, где находятся родительские карточки сборок."
            )
            return

        root = Path(self.main_root_var.get().strip())
        if not root.exists():
            messagebox.showinfo("MIX PC", "Выберите существующую локальную папку.")
            return

        self.main_progress.start(10)
        self.log_action(f"Главное фото: старт сопоставления, папка {root}")
        self.main_status.set("Ищу родительские товары, модификации и цвета…")
        self.main_upload_btn.config(state="disabled")
        threading.Thread(target=self._main_match_worker, args=(nodes, root), daemon=True).start()

    def _main_match_worker(self, nodes, root):
        try:
            products = []
            seen = set()
            for node in nodes:
                if self.operation_should_stop():
                    break
                for p in self.client.products_in_folder(node.href):
                    pid = p.get("id", "")
                    if pid and pid not in seen:
                        seen.add(pid)
                        p["_folder_name"] = node.name
                        products.append(p)

            self.main_products_cache = products
            attr_names = self.client.product_attribute_metadata()
            by_key = {}
            for p in products:
                key = self._extract_hw_key(p.get("name", ""))
                if key:
                    by_key.setdefault(key, []).append(p)

            matches = []
            folders = [
                p for p in root.iterdir()
                if p.is_dir() and p.name not in self.main_ignored_folders
            ]

            self.root.after(
                0,
                self.set_operation_total,
                len(folders),
                "Сопоставление папок"
            )

            for pos, folder in enumerate(sorted(folders, key=lambda p: p.name.lower()), 1):
                if self.operation_should_stop():
                    break
                image = self._local_main_image(folder)
                if not image:
                    continue

                key = self._extract_hw_key(folder.name)
                color = self._extract_folder_color(folder.name)

                m = MainPhotoMatch(
                    folder_name=folder.name,
                    folder_path=folder,
                    local_image=image,
                    key=key or "",
                    color=color,
                )

                if not key:
                    m.match_status = "Не распознан CPU/GPU"
                    matches.append(m)
                    continue
                if color not in ("Белый", "Черный"):
                    m.match_status = "Не распознан цвет"
                    matches.append(m)
                    continue

                candidates = by_key.get(key, [])
                m.candidates = candidates

                if len(candidates) != 1:
                    m.match_status = "Родитель не найден" if not candidates else "Несколько родителей"
                    matches.append(m)
                    continue

                parent = candidates[0]
                m.matched_product_id = parent.get("id")
                m.matched_product_name = parent.get("name")
                m.matched_category = parent.get("_folder_name", "")

                full_parent = self.client.get_json(f"/entity/product/{m.matched_product_id}")
                m.parent_color = self._parent_product_color(full_parent, attr_names)

                variants = self.client.variants_for_product(m.matched_product_id)
                color_variants = [v for v in variants if self._variant_color(v) == color]
                no_color = [v for v in variants if self._variant_color(v) is None]

                m.variants = color_variants

                if not color_variants:
                    m.match_status = "Нет модификаций цвета"
                    m.confidence = 0
                    m.selected = False
                else:
                    m.confidence = 100
                    m.selected = True
                    notes = []
                    if no_color:
                        notes.append(f"без цвета: {len(no_color)}")
                    if m.parent_color not in ("Белый", "Черный"):
                        notes.append("нет цвета родителя")
                    m.match_status = "Готово" if not notes else "Готово • " + " • ".join(notes)

                self.root.after(
                    0, self.main_status.set,
                    f"Сопоставляю {pos}/{len(folders)} • {folder.name}"
                )
                self.root.after(
                    0,
                    self.update_operation_progress,
                    pos,
                    len(folders),
                    folder.name[:45]
                )
                matches.append(m)

            self.root.after(0, self._main_match_done, matches, len(products))

        except Exception as e:
            self.root.after(0, self._main_match_error, str(e))

    def _main_match_done(self, matches, product_count):
        self.finish_cancellable_operation()
        self.main_progress.stop()
        self.main_matches = matches
        self.main_by_item.clear()
        self.main_tree.delete(*self.main_tree.get_children())

        for m in matches:
            item = self.main_tree.insert(
                "", "end",
                values=(
                    m.folder_name,
                    m.matched_product_name or "—",
                    m.color or "—",
                    m.parent_color or "—",
                    len(m.variants),
                    "☑" if m.selected else "☐",
                    m.match_status,
                )
            )
            self.main_by_item[item] = m

        ready = sum(1 for m in matches if m.selected)
        variants = sum(len(m.variants) for m in matches if m.selected)
        problems = len(matches) - ready
        self.main_status.set(
            f"Папок: {len(matches)} • готово: {ready} • модификаций к замене: {variants} • проверить: {problems}"
        )
        self.log_action(
            f"Главное фото: сопоставление завершено — папок {len(matches)}, "
            f"готово {ready}, модификаций {variants}, проблем {problems}"
        )
        self.update_main_summary()

    def _main_match_error(self, msg):
        self.finish_cancellable_operation()
        self.main_progress.stop()
        self.main_status.set("Ошибка сопоставления.")
        messagebox.showerror("Главное фото", msg)

    def toggle_main_match(self, event=None):
        item = self.main_tree.focus()
        if not item or item not in self.main_by_item:
            return
        m = self.main_by_item[item]
        if not m.matched_product_id or not m.variants:
            messagebox.showinfo(
                "Строка не готова",
                "Для этой строки нет однозначного родителя и модификаций нужного цвета."
            )
            return
        m.selected = not m.selected
        vals = list(self.main_tree.item(item, "values"))
        vals[5] = "☑" if m.selected else "☐"
        self.main_tree.item(item, values=vals)
        self.update_main_summary()

    def delete_main_row(self, event=None):
        """
        Убирает выбранную строку только из рабочего списка программы.
        Ничего не удаляет из локальной папки и МойСклад.
        До перезапуска программы эта папка не появится снова при повторном сканировании.
        """
        item = self.main_tree.focus()
        if not item or item not in self.main_by_item:
            return

        match = self.main_by_item.pop(item)

        self.main_ignored_folders.add(match.folder_name)

        try:
            self.main_matches.remove(match)
        except ValueError:
            pass

        self.main_tree.delete(item)
        self.log_action(f"Главное фото: строка убрана вручную — {match.folder_name}")
        self.update_main_summary()
        self.main_status.set(
            f"Убрано из списка: {match.folder_name}. "
            "Локальные файлы и МойСклад не изменены."
        )

    def set_all_main(self, value):
        for item, m in self.main_by_item.items():
            m.selected = bool(value and m.matched_product_id and m.variants)
            vals = list(self.main_tree.item(item, "values"))
            vals[5] = "☑" if m.selected else "☐"
            self.main_tree.item(item, values=vals)
        self.update_main_summary()

    def select_all_exact_main(self):
        self.set_all_main(True)

    def update_main_summary(self):
        selected = [m for m in self.main_matches if m.selected and m.variants]
        variants = sum(len(m.variants) for m in selected)
        self.main_summary.config(text=f"К замене: {len(selected)} фото → {variants} модификаций")
        self.main_upload_btn.config(state="normal" if selected else "disabled")

    def manual_pick_main_product(self):
        item = self.main_tree.focus()
        if not item or item not in self.main_by_item:
            messagebox.showinfo("MIX PC", "Выберите строку в таблице.")
            return

        match = self.main_by_item[item]
        products = match.candidates if match.candidates else self.main_products_cache

        win = Toplevel(self.root)
        win.title("Выбор родительского товара")
        win.geometry("700x520")
        frm = ttk.Frame(win, padding=12)
        frm.pack(fill=BOTH, expand=True)

        ttk.Label(frm, text=f"{match.folder_name} • цвет: {match.color or 'не определён'}", style="H2.TLabel").pack(anchor="w")
        search_var = StringVar()
        ttk.Entry(frm, textvariable=search_var).pack(fill=X, pady=(10, 8))
        listbox = Listbox(frm)
        listbox.pack(fill=BOTH, expand=True)
        mapping = []

        def refresh(*_):
            q = search_var.get().strip().lower()
            listbox.delete(0, END)
            mapping.clear()
            for p in products:
                name = p.get("name", "")
                if not q or q in name.lower():
                    listbox.insert(END, name)
                    mapping.append(p)

        def choose():
            sel = listbox.curselection()
            if not sel:
                return
            if match.color not in ("Белый", "Черный"):
                messagebox.showerror(
                    "Цвет не определён",
                    "В имени локальной папки должен быть указан Белый или Черный."
                )
                return

            p = mapping[sel[0]]
            match.matched_product_id = p.get("id")
            match.matched_product_name = p.get("name")
            match.matched_category = p.get("_folder_name", "")
            match.candidates = [p]

            try:
                attr_names = self.client.product_attribute_metadata()
                full_parent = self.client.get_json(f"/entity/product/{match.matched_product_id}")
                match.parent_color = self._parent_product_color(full_parent, attr_names)
                variants = self.client.variants_for_product(match.matched_product_id)
                match.variants = [v for v in variants if self._variant_color(v) == match.color]
            except Exception as e:
                messagebox.showerror("МойСклад", str(e))
                return

            match.selected = bool(match.variants)
            match.confidence = 100 if match.variants else 0
            match.match_status = "Выбрано вручную" if match.variants else "Нет модификаций цвета"

            vals = list(self.main_tree.item(item, "values"))
            vals[1] = match.matched_product_name
            vals[2] = match.color
            vals[3] = match.parent_color or "—"
            vals[4] = len(match.variants)
            vals[5] = "☑" if match.selected else "☐"
            vals[6] = match.match_status
            self.main_tree.item(item, values=vals)
            self.update_main_summary()
            win.destroy()

        search_var.trace_add("write", refresh)
        refresh()
        ttk.Button(frm, text="Выбрать", style="Primary.TButton", command=choose).pack(anchor="e", pady=(8, 0))
        listbox.bind("<Double-1>", lambda e: choose())

    def confirm_main_upload(self):
        if not self.client:
            messagebox.showinfo("MIX PC", "Сначала подключитесь к МойСклад.")
            return

        selected = [m for m in self.main_matches if m.selected and m.variants]
        if not selected:
            return

        backup_root = self.main_backup_var.get().strip()
        if not backup_root:
            messagebox.showinfo("MIX PC", "Выберите папку для резервной копии.")
            return

        # Одна модификация не должна попасть сразу под два локальных фото.
        ids = []
        for m in selected:
            ids.extend(v.get("id") for v in m.variants if v.get("id"))
        dup = {x for x in ids if ids.count(x) > 1}
        if dup:
            messagebox.showerror(
                "Конфликт",
                "Одна и та же модификация попала сразу под несколько локальных фотографий.\n"
                "Загрузка остановлена — проверьте цвета и сопоставление."
            )
            return

        variant_count = sum(len(m.variants) for m in selected)
        grouped_parents = {}
        for m in selected:
            if m.matched_product_id:
                grouped_parents.setdefault(m.matched_product_id, []).append(m)
        parent_count = 0
        parent_skipped = 0
        for rows in grouped_parents.values():
            parent_color = rows[0].parent_color
            if parent_color in ("Белый", "Черный") and any(m.color == parent_color for m in rows):
                parent_count += 1
            else:
                parent_skipped += 1

        if not messagebox.askyesno(
            "Проверка перед загрузкой",
            f"Локальных главных фото: {len(selected)}\n"
            f"Родительских товаров будет обновлено: {parent_count}\n"
            f"Родителей будет пропущено из-за цвета: {parent_skipped}\n"
            f"Модификаций будет обновлено: {variant_count}\n\n"
            "У модификаций заменится только первое фото.\n"
            "У родителя главное фото выбирается по полю «Сборки. Цвет».\n"
            "Черный → черное фото, Белый → белое фото.\n"
            "Если цвет родителя пустой/не распознан или нужного локального фото нет — родитель пропускается.\n\n"
            f"Фото будут оптимизированы примерно до {int(self.main_target_kb.get())} КБ.\n"
            "Перед записью будут сохранены все текущие фото. Продолжить?"
        ):
            return

        self.main_progress.start(10)
        self.main_upload_btn.config(state="disabled")
        self.main_stop_btn.config(state="normal")
        self.main_resume_btn.pack_forget()
        self.main_pause_event.set()
        self._start_main_timer()
        self.main_status.set("Сохраняю оригиналы и заменяю главные фото модификаций…")

        session = Path(backup_root) / f"MIXPC_variant_mainphoto_backup_{datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}"
        session.mkdir(parents=True, exist_ok=True)
        self.log_action(
            f"Главное фото: старт загрузки — локальных фото {len(selected)}, "
            f"модификаций {variant_count}, родителей к обновлению {parent_count}, "
            f"лимит {int(self.main_target_kb.get())} КБ, backup {session}"
        )
        threading.Thread(
            target=self._main_upload_worker, args=(selected, session), daemon=True
        ).start()

    def _main_upload_worker(self, selected, session):
        ok = 0
        failed = 0
        parent_ok = 0
        parent_failed = 0
        all_manifest = []

        try:
            # Оптимизируем каждую локальную картинку один раз.
            compressed_by_folder = {}
            for m in selected:
                if self.operation_should_stop():
                    break
                self._main_checkpoint()
                data, filename, out_size, quality = self._compress_main_photo(m.local_image)
                compressed_by_folder[m.folder_name] = {
                    "bytes": data,
                    "filename": filename,
                    "size": out_size,
                    "quality": quality,
                    "weight_kb": round(len(data) / 1024, 1),
                }

            # -------------------------------------------------
            # 1) Родительские товары
            # -------------------------------------------------
            # Родитель получает фото строго по доп. полю "Сборки. Цвет".
            by_parent = {}
            for m in selected:
                if m.matched_product_id:
                    by_parent.setdefault(m.matched_product_id, []).append(m)

            parent_source = {}
            parent_skipped_no_color = 0
            for parent_id, rows in by_parent.items():
                parent_color = rows[0].parent_color
                if parent_color not in ("Белый", "Черный"):
                    parent_skipped_no_color += 1
                    continue
                matching = [m for m in rows if m.color == parent_color]
                if not matching:
                    parent_skipped_no_color += 1
                    continue
                parent_source[parent_id] = matching[0]

            for parent_index, (parent_id, m) in enumerate(parent_source.items(), 1):
                self._main_checkpoint()
                try:
                    product = self.client.get_json(
                        f"/entity/product/{parent_id}",
                        {"expand": "images"}
                    )
                    current_images = ((product.get("images") or {}).get("rows") or [])

                    parent_dir = (
                        session
                        / "_PARENTS"
                        / self.safe_name(m.matched_product_name or "parent")
                        / parent_id
                    )
                    orig_dir = parent_dir / "original"
                    orig_dir.mkdir(parents=True, exist_ok=True)

                    manifest_images = []
                    for image_no, image_info in enumerate(current_images, 1):
                        href = (image_info.get("meta") or {}).get("downloadHref")
                        if not href:
                            continue

                        raw = self.client.get_bytes(href)
                        filename = image_info.get("filename") or f"image_{image_no}.png"
                        backup_filename = f"{image_no:02d}_{self.safe_name(filename)}"
                        (orig_dir / backup_filename).write_bytes(raw)

                        manifest_images.append({
                            "order": image_no,
                            "filename": filename,
                            "backup_filename": backup_filename,
                        })

                    parent_manifest = {
                        "entity_type": "product",
                        "product_id": parent_id,
                        "product_name": m.matched_product_name,
                        "category": m.matched_category,
                        "source_folder": m.folder_name,
                        "source_color": m.color,
                        "images": manifest_images,
                    }

                    (parent_dir / "manifest.json").write_text(
                        json.dumps(parent_manifest, ensure_ascii=False, indent=2),
                        encoding="utf-8"
                    )

                    optimized = compressed_by_folder[m.folder_name]
                    self.client.replace_main_product_image(
                        parent_id,
                        optimized["filename"],
                        optimized["bytes"],
                        current_images
                    )
                    parent_ok += 1
                    self.log_action(
                        f"Главное фото: родитель обновлён — {m.matched_product_name} "
                        f"({m.parent_color}), {optimized['weight_kb']} КБ"
                    )

                except Exception as exc:
                    parent_failed += 1
                    self.log_action(
                        f"Главное фото: ошибка родителя — {m.matched_product_name}: {exc}",
                        "ERROR"
                    )

                self.root.after(
                    0,
                    self.main_status.set,
                    f"Родители {parent_index}/{len(parent_source)} • "
                    f"успешно {parent_ok} • ошибок {parent_failed}"
                )

            # -------------------------------------------------
            # 2) Модификации
            # -------------------------------------------------
            tasks = [(m, v) for m in selected for v in m.variants]
            per_match = {id(m): {"total": len(m.variants), "ok": 0, "failed": 0} for m in selected}

            for idx, (m, variant) in enumerate(tasks, 1):
                self._main_checkpoint()
                variant_id = variant.get("id")
                variant_name = variant.get("name") or variant_id

                try:
                    fresh = self.client.get_variant(variant_id)
                    current_images = ((fresh.get("images") or {}).get("rows") or [])

                    product_dir = session / self.safe_name(m.matched_product_name or "parent")
                    variant_dir = product_dir / self.safe_name(variant_name) / variant_id
                    orig_dir = variant_dir / "original"
                    orig_dir.mkdir(parents=True, exist_ok=True)

                    manifest_images = []
                    for image_no, image_info in enumerate(current_images, 1):
                        href = (image_info.get("meta") or {}).get("downloadHref")
                        if not href:
                            continue

                        raw = self.client.get_bytes(href)
                        filename = image_info.get("filename") or f"image_{image_no}.png"
                        backup_filename = f"{image_no:02d}_{self.safe_name(filename)}"
                        (orig_dir / backup_filename).write_bytes(raw)

                        manifest_images.append({
                            "order": image_no,
                            "filename": filename,
                            "backup_filename": backup_filename,
                        })

                    optimized = compressed_by_folder[m.folder_name]

                    manifest = {
                        "entity_type": "variant",
                        "variant_id": variant_id,
                        "variant_name": variant_name,
                        "product_id": m.matched_product_id,
                        "product_name": m.matched_product_name,
                        "category": m.matched_category,
                        "color": m.color,
                        "source_folder": m.folder_name,
                        "source_main_image": m.local_image.name,
                        "uploaded_filename": optimized["filename"],
                        "uploaded_weight_kb": optimized["weight_kb"],
                        "uploaded_size": optimized["size"],
                        "jpeg_quality": optimized["quality"],
                        "images": manifest_images,
                    }

                    (variant_dir / "manifest_variant.json").write_text(
                        json.dumps(manifest, ensure_ascii=False, indent=2),
                        encoding="utf-8"
                    )
                    all_manifest.append(manifest)

                    self.client.replace_main_variant_image(
                        variant_id,
                        optimized["filename"],
                        optimized["bytes"],
                        current_images
                    )

                    ok += 1
                    per_match[id(m)]["ok"] += 1
                    self.log_action(
                        f"Главное фото: модификация обновлена — {variant_name} "
                        f"({m.color}), {optimized['weight_kb']} КБ"
                    )

                except Exception as exc:
                    failed += 1
                    per_match[id(m)]["failed"] += 1
                    m.upload_status = f"⚠ Ошибка: {str(exc)[:80]}"
                    self.log_action(
                        f"Главное фото: ошибка модификации — {variant_name}: {exc}",
                        "ERROR"
                    )

                self.root.after(
                    0,
                    self.main_status.set,
                    f"Модификации {idx}/{len(tasks)} • успешно {ok} • ошибок {failed}"
                )

            (session / "manifest_variants.json").write_text(
                json.dumps({
                    "format_version": 4,
                    "type": "variant_and_parent_main_photo_replacement",
                    "created": datetime.now().isoformat(timespec="seconds"),
                    "parents_ok": parent_ok,
                    "parents_failed": parent_failed,
                    "variants": all_manifest,
                }, ensure_ascii=False, indent=2),
                encoding="utf-8"
            )

            # Строка считается полностью успешной, если её модификации обновились.
            # Ошибка родителя показывается отдельно в финальном сообщении,
            # поскольку один родитель может обслуживать сразу несколько цветовых строк.
            for m in selected:
                stats = per_match[id(m)]
                if stats["failed"] == 0 and stats["ok"] == stats["total"]:
                    self.root.after(0, self._remove_successful_main_row, m.folder_name)
                else:
                    msg = f"⚠ Ошибка • {stats['failed']} из {stats['total']}"
                    self.root.after(0, self._mark_main_row_error, m.folder_name, msg)

            self.root.after(
                0,
                self._main_upload_done_v073,
                ok,
                failed,
                parent_ok,
                parent_failed,
                parent_skipped_no_color,
                str(session),
                compressed_by_folder,
            )

        except Exception as e:
            self.root.after(0, self._main_upload_fatal, str(e))

    def _main_upload_done_v073(self, ok, failed, parent_ok, parent_failed, parent_skipped, session, compressed):
        self.finish_cancellable_operation()
        elapsed = self._finish_main_timer()
        self.main_pause_event.set()

        self.main_progress.stop()
        self.main_upload_btn.config(state="normal")

        self.main_stop_btn.config(state="disabled")
        self.main_stop_btn.pack_forget()
        self.main_resume_btn.pack_forget()
        self.main_stop_btn.pack(side=RIGHT, padx=(8, 0))

        weights = [v["weight_kb"] for v in compressed.values()]
        avg_weight = round(sum(weights) / len(weights), 1) if weights else 0

        self.main_status.set(
            f"Готово • родители: {parent_ok} успешно / {parent_failed} ошибок / {parent_skipped} пропущено • "
            f"модификации {ok}/{ok + failed} • средний вес ≈ {avg_weight} КБ • "
            f"время {self.format_duration(elapsed)}"
        )

        self.log_action(
            f"Главное фото: завершено — родители {parent_ok} успешно / {parent_failed} ошибок / "
            f"{parent_skipped} пропущено; модификации {ok} успешно / {failed} ошибок; "
            f"средний вес {avg_weight} КБ; время {self.format_duration(elapsed)}; backup {session}"
        )

        messagebox.showinfo(
            "Главные фото",
            f"Родителей обновлено: {parent_ok}\n"
            f"Ошибок родителей: {parent_failed}\n"
            f"Родителей пропущено по цвету: {parent_skipped}\n\n"
            f"Модификаций обновлено: {ok}\n"
            f"Ошибок модификаций: {failed}\n\n"
            f"Средний вес загружаемого главного фото: ≈ {avg_weight} КБ\n"
            f"Время: {self.format_duration(elapsed)}\n\n"
            "Успешно обновлённые строки убраны из списка.\n"
            "Строки с ошибками остались со значком ⚠.\n\n"
            f"Резервная копия:\n{session}"
        )


    def _remove_successful_main_row(self, folder_name):
        """
        Успешно обработанная строка исчезает из рабочего списка автоматически.
        Она также не вернётся при повторном сканировании до перезапуска программы.
        """
        for item, match in list(self.main_by_item.items()):
            if match.folder_name == folder_name:
                self.main_ignored_folders.add(match.folder_name)
                try:
                    self.main_matches.remove(match)
                except ValueError:
                    pass
                del self.main_by_item[item]
                self.main_tree.delete(item)
                break

        self.update_main_summary()

    def _mark_main_row_error(self, folder_name, message):
        """
        Ошибочная строка остаётся в списке и получает явный предупреждающий статус.
        """
        for item, match in self.main_by_item.items():
            if match.folder_name == folder_name:
                match.upload_status = message
                match.selected = False
                vals = list(self.main_tree.item(item, "values"))
                vals[5] = "☐"
                vals[6] = message
                self.main_tree.item(item, values=vals)
                break

        self.update_main_summary()


    def _main_upload_done(self, ok, failed, session):
        self.finish_cancellable_operation()
        self.main_progress.stop()
        self.main_upload_btn.config(state="normal")
        self.main_status.set(f"Готово • модификаций изменено {ok} • ошибок {failed}")
        messagebox.showinfo(
            "Главные фото",
            f"Изменено модификаций: {ok}\nОшибок: {failed}\n\n"
            "Успешно обновлённые строки автоматически убраны из списка.\n"
            "Строки с ошибками остались со значком ⚠.\n\n"
            f"Резервная копия:\n{session}"
        )

    def _main_upload_fatal(self, msg):
        self.finish_cancellable_operation()
        elapsed = self._finish_main_timer()
        self.main_pause_event.set()
        self.main_progress.stop()
        self.main_upload_btn.config(state="normal")

        self.main_stop_btn.config(state="disabled")
        self.main_stop_btn.pack_forget()
        self.main_resume_btn.pack_forget()
        self.main_stop_btn.pack(side=RIGHT, padx=(8, 0))

        self.main_status.set("Ошибка.")
        self.log_action(
            f"Главное фото: критическая ошибка после {self.format_duration(elapsed)}: {msg}",
            "ERROR"
        )
        messagebox.showerror(
            "Главное фото",
            f"{msg}\n\nВремя до остановки: {self.format_duration(elapsed)}"
        )



    # =====================================================
    # ONLINE UPDATER v1.3.2
    # =====================================================

    ONLINE_UPDATE_MANIFEST = "https://update.boulland.ru/version.json"

    @staticmethod
    def _online_version_tuple(value: str):
        nums = re.findall(r"\d+", str(value or ""))
        return tuple(int(x) for x in nums[:4]) or (0,)

    def check_for_updates(self, silent=False):
        """
        Проверка обновлений через собственный сервер MIX PC.
        Не использует GitHub на клиентском ПК и не требует VPN.
        """
        try:
            self.update_status_var.set("Обновления: проверяю…")
            if hasattr(self, "update_btn"):
                self.update_btn.config(
                    text="Проверяю…",
                    state="disabled"
                )
        except Exception:
            pass

        threading.Thread(
            target=self._online_check_worker,
            args=(silent,),
            daemon=True
        ).start()

    def _online_check_worker(self, silent=False):
        try:
            response = requests.get(
                self.ONLINE_UPDATE_MANIFEST,
                timeout=15,
                headers={
                    "Cache-Control": "no-cache",
                    "User-Agent": "MIX-PC-Photo-Cleaner-Updater"
                }
            )
            response.raise_for_status()
            manifest = response.json()

            remote_version = str(manifest.get("version") or "").strip()
            package_url = str(
                manifest.get("package_url")
                or manifest.get("url")
                or ""
            ).strip()
            sha256 = str(manifest.get("sha256") or "").strip().lower()
            notes = str(manifest.get("notes") or "").strip()

            if not remote_version:
                raise RuntimeError("В version.json отсутствует version")

            current = self._online_version_tuple(self.app_version)
            remote = self._online_version_tuple(remote_version)

            if remote > current:
                if not package_url:
                    raise RuntimeError(
                        "Для новой версии не указан package_url"
                    )

                self.update_info = {
                    "version": remote_version,
                    "package_url": package_url,
                    "sha256": sha256,
                    "notes": notes,
                }
                self.root.after(
                    0,
                    self._online_update_available,
                    silent
                )
            else:
                self.update_info = None
                self.root.after(
                    0,
                    self._online_no_update,
                    silent
                )

        except Exception as e:
            self.root.after(
                0,
                self._online_update_error,
                silent,
                str(e)
            )

    def _online_update_available(self, silent=False):
        version = self.update_info.get("version", "?")
        self.update_status_var.set(
            f"Обновления: доступна v{version}"
        )

        if hasattr(self, "update_btn"):
            self.update_btn.config(
                text=f"Установить v{version}",
                state="normal",
                command=self.install_online_update
            )

        self.log_action(
            f"Обновления: доступна версия {version}"
        )

        # При фоновой автопроверке не мешаем работе.
        # Пользователь увидит кнопку в шапке.
        if not silent:
            notes = self.update_info.get("notes") or "Доступна новая версия."
            if messagebox.askyesno(
                "Обновление MIX PC Photo Cleaner",
                f"Доступна версия {version}.\n\n"
                f"{notes}\n\n"
                "Скачать и установить сейчас?"
            ):
                self.install_online_update()

    def _online_no_update(self, silent=False):
        self.update_status_var.set("Обновления: актуальная версия")
        if hasattr(self, "update_btn"):
            self.update_btn.config(
                text="Проверить обновления",
                state="normal",
                command=lambda: self.check_for_updates(silent=False)
            )

        if not silent:
            messagebox.showinfo(
                "Обновления",
                "Установлена актуальная версия."
            )

    def _online_update_error(self, silent, error_text):
        self.update_status_var.set("Обновления: сервер недоступен")
        if hasattr(self, "update_btn"):
            self.update_btn.config(
                text="Проверить обновления",
                state="normal",
                command=lambda: self.check_for_updates(silent=False)
            )

        self.log_action(
            f"Обновления: ошибка проверки: {error_text}",
            "WARN"
        )

        if not silent:
            messagebox.showerror(
                "Обновления",
                "Не удалось проверить обновления.\n\n"
                f"{error_text}"
            )

    def install_online_update(self):
        if not self.update_info:
            self.check_for_updates(silent=False)
            return

        if hasattr(self, "update_btn"):
            self.update_btn.config(
                text="Скачиваю…",
                state="disabled"
            )

        self.update_status_var.set("Обновления: скачиваю пакет…")

        threading.Thread(
            target=self._online_download_worker,
            daemon=True
        ).start()

    def _online_download_worker(self):
        try:
            info = dict(self.update_info or {})
            package_url = info["package_url"]
            expected_sha = str(info.get("sha256") or "").lower()

            app_data = (
                Path(os.environ.get("LOCALAPPDATA") or Path.home())
                / "MIX PC Photo Cleaner"
            )
            updates_dir = app_data / "Updates"
            updates_dir.mkdir(parents=True, exist_ok=True)

            package_path = updates_dir / "latest.zip"

            h = hashlib.sha256()
            with requests.get(
                package_url,
                stream=True,
                timeout=(15, 120),
                headers={
                    "Cache-Control": "no-cache",
                    "User-Agent": "MIX-PC-Photo-Cleaner-Updater"
                }
            ) as response:
                response.raise_for_status()
                total = int(response.headers.get("content-length") or 0)
                downloaded = 0

                with open(package_path, "wb") as f:
                    for chunk in response.iter_content(256 * 1024):
                        if not chunk:
                            continue
                        f.write(chunk)
                        h.update(chunk)
                        downloaded += len(chunk)

                        if total > 0:
                            pct = int(downloaded * 100 / total)
                            self.root.after(
                                0,
                                self.update_status_var.set,
                                f"Обновления: скачивание {pct}%"
                            )

            actual_sha = h.hexdigest().lower()

            if expected_sha and actual_sha != expected_sha:
                raise RuntimeError(
                    "Контрольная сумма обновления не совпадает.\n"
                    f"Ожидалось: {expected_sha}\n"
                    f"Получено: {actual_sha}"
                )

            stage = updates_dir / "stage"
            if stage.exists():
                shutil.rmtree(stage, ignore_errors=True)
            stage.mkdir(parents=True, exist_ok=True)

            with zipfile.ZipFile(package_path, "r") as z:
                z.extractall(stage)

            new_source = stage / "MIX_PC_Photo_Cleaner.pyw"
            if not new_source.exists():
                raise RuntimeError(
                    "В пакете обновления отсутствует MIX_PC_Photo_Cleaner.pyw"
                )

            self.root.after(
                0,
                self._online_launch_rebuilder,
                stage,
                info.get("version", "")
            )

        except Exception as e:
            self.root.after(
                0,
                self._online_update_error,
                False,
                f"Ошибка установки: {e}"
            )

    def _online_install_root(self):
        """
        Full installer layout:
          ROOT/
            MIX_PC_Photo_Cleaner.pyw
            dist/
              MIX PC Photo Cleaner/
                MIX PC Photo Cleaner.exe
        """
        if getattr(sys, "frozen", False):
            exe = Path(sys.executable).resolve()
            # .../ROOT/dist/MIX PC Photo Cleaner/MIX PC Photo Cleaner.exe
            candidate = exe.parent.parent.parent
            if (candidate / "MIX_PC_Photo_Cleaner.pyw").exists():
                return candidate
            return exe.parent

        return Path(__file__).resolve().parent

    def _online_launch_rebuilder(self, stage: Path, version: str):
        try:
            root = self._online_install_root()
            new_source = stage / "MIX_PC_Photo_Cleaner.pyw"

            # PowerShell script is generated outside the installation directory,
            # waits for this process to exit, replaces the source, rebuilds EXE,
            # then starts the new version. LOCALAPPDATA is untouched.
            script_path = stage.parent / "apply_update.ps1"

            root_q = str(root).replace("'", "''")
            stage_q = str(stage).replace("'", "''")
            exe_path = root / "dist" / "MIX PC Photo Cleaner" / "MIX PC Photo Cleaner.exe"
            exe_q = str(exe_path).replace("'", "''")

            script = f"""$ErrorActionPreference = 'Stop'
Start-Sleep -Seconds 3

$root = '{root_q}'
$stage = '{stage_q}'
$exe = '{exe_q}'

Set-Location $root

Copy-Item -LiteralPath (Join-Path $stage 'MIX_PC_Photo_Cleaner.pyw') `
    -Destination (Join-Path $root 'MIX_PC_Photo_Cleaner.pyw') -Force

python -m pip install --quiet --upgrade pyinstaller requests certifi Pillow

if (Test-Path (Join-Path $root 'build')) {{
    Remove-Item (Join-Path $root 'build') -Recurse -Force
}}
if (Test-Path (Join-Path $root 'dist')) {{
    Remove-Item (Join-Path $root 'dist') -Recurse -Force
}}
$spec = Join-Path $root 'MIX PC Photo Cleaner.spec'
if (Test-Path $spec) {{
    Remove-Item $spec -Force
}}

python -m PyInstaller --noconfirm --clean --windowed `
    --name 'MIX PC Photo Cleaner' `
    --collect-data certifi `
    --hidden-import certifi `
    'MIX_PC_Photo_Cleaner.pyw'

$newExe = Join-Path $root 'dist\\MIX PC Photo Cleaner\\MIX PC Photo Cleaner.exe'
if (-not (Test-Path $newExe)) {{
    throw 'Updated EXE was not created.'
}}

# Recreate shortcut because the target path remains stable.
$ws = New-Object -ComObject WScript.Shell
$desktop = $ws.SpecialFolders.Item('Desktop')
$lnk = Join-Path $desktop 'MIX PC Photo Cleaner.lnk'
$sc = $ws.CreateShortcut($lnk)
$sc.TargetPath = $newExe
$sc.WorkingDirectory = Split-Path -Parent $newExe
$sc.IconLocation = $newExe + ',0'
$sc.Description = 'MIX PC Photo Cleaner'
$sc.Save()

Start-Process -FilePath $newExe
"""

            script_path.write_text(
                script,
                encoding="utf-8-sig"
            )

            self.update_status_var.set(
                f"Обновления: устанавливаю v{version}…"
            )
            self.log_action(
                f"Обновления: запуск установки версии {version}"
            )

            subprocess.Popen(
                [
                    "powershell.exe",
                    "-NoProfile",
                    "-ExecutionPolicy", "Bypass",
                    "-File", str(script_path)
                ],
                cwd=str(root),
                creationflags=getattr(
                    subprocess,
                    "CREATE_NEW_PROCESS_GROUP",
                    0
                )
            )

            messagebox.showinfo(
                "Обновление",
                "Обновление скачано.\n\n"
                "Программа сейчас закроется, пересоберёт новую версию "
                "и автоматически запустится снова.\n\n"
                "Токен и настройки сохранятся."
            )

            self.root.after(250, self.root.destroy)

        except Exception as e:
            self._online_update_error(
                False,
                f"Не удалось запустить установщик обновления: {e}"
            )


def main():
    root = Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
